import type { RouteQuery, RouteQueryCodec } from "./route-query";

/** Consumer-owned, versioned filter snapshot. Store only this codec's owned keys. */
export interface CollectionFilterPreset {
  readonly id: string;
  readonly label: string;
  readonly description?: string;
  readonly query: RouteQuery;
}

export interface CollectionFilterPresetActions {
  apply(id: string): Promise<void>;
  save(label: string): Promise<void>;
  update(id: string, label: string): Promise<void>;
  remove(id: string): Promise<void>;
}

/** Normalize through the consumer's codec; never capture unrelated URL parameters. */
export function snapshotCollectionFilters<T>(codec: RouteQueryCodec<T>, value: T): RouteQuery {
  const normalized = codec.serialize(codec.parse(codec.serialize(value)));
  return Object.freeze(Object.fromEntries(codec.ownedKeys.filter(key => normalized[key] !== undefined).map(key => {
    const value = normalized[key];
    return [key, Array.isArray(value) ? Object.freeze([...value]) : value];
  })));
}

/** Compare canonical snapshots, including explicit empty arrays with nonempty defaults. */
export function equalCollectionFilters(a: RouteQuery, b: RouteQuery): boolean {
  const fingerprint = (query: RouteQuery) => JSON.stringify(Object.keys(query).sort().map(key => [key, query[key]]));
  return fingerprint(a) === fingerprint(b);
}
