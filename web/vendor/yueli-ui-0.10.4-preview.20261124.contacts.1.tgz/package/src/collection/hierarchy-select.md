# 多级选择

interaction.19 可选`locateSelected={label:(path)=>string}`：已选标签旁显示独立定位图标按钮，标签原有移除行为保持；从关闭菜单定位时打开并进入该叶节点父级，清空查询、恢复搜索焦点，保留全部选择和草稿。label使用完整路径供屏幕阅读器区分同名项，当前叶节点保持选中。未知/禁用/父节点ID不提供定位入口；不是远程未知节点解析。默认不显示，与breadcrumbs独立。共享CollectionMultiSelect的可选locate回调决定按钮文案和是否出现，locate事件仅给出ID，导航由包装/消费者拥有。

导入 `CollectionHierarchySelect` 自 `@yueli/ui/collection/pattern`，Nuxt 自动注册 `YCollectionHierarchySelect`。nodes 为静态树，节点沿用 value/label/icon/trailingIcon/keywords/disabled，children 为子节点。全树搜索的 description 自动使用祖先标题路径，调用方不用拼接完整标题；父节点右箭头表示进入，叶节点 trailingIcon 为装饰。value 在整棵树唯一，区分数字/字符串；重复 ID 或循环抛 TypeError。children 空数组视为叶节点。indexCollectionHierarchy 可从 `@yueli/ui/collection` 单独使用。

数组 v-model 保存叶节点 ID。父节点整行进入下一级，不修改选择、不关闭菜单；上级及根级按钮返回，焦点恢复搜索框。搜索遍历全树叶节点的标题/路径/关键词，同名叶标题用祖先路径辅助区分；清空搜索回到之前浏览的层级，关闭再打开保留浏览层级。父节点不选中整个子树，没有隐含级联。禁用父节点使后代均禁用，已保存值仍保留，可移除。缺失 ID 用 missing 回显，不静默清除。

```vue
<CollectionHierarchySelect v-model="ids" :nodes="tree" label="板块" placeholder="选择板块" :messages="messages" />
```

messages 包含共享 CollectionMultiSelectMessages，并增加 root/back/searchResults/enter（屏幕阅读器进入提示）。disabled=false，visibleLimit=2；size/ui 使用原生 Nuxt UI 配置。沿用共享摘要、折叠、移除、清空及焦点，不另造选择列表。

静态树更新后当前节点被移除或不再有子节点，导航回根级；已选 ID 保持消费者决定。模型应提供叶 ID；不能把父 ID 当“全选后代”。消费者负责权限、空选择查询语义及业务提交。默认导航模式不隐含父子勾选传播；本组件不提供远程懒加载、无限分页或保存方案；这些需要独立业务数据合同。平铺少量选项继续用 CollectionMultiSelect，现有消费者无需迁移。

## 可选本组全选（interaction.17）

`groupSelection={label:(name,total)=>string,summary:(selected,total)=>string}` 开启当前父分组的独立复选框；默认不显示。父节点仍只导航，不改为嵌套按钮或复选框。进入父分组后，只操作该组完整静态树的可用后代叶节点，包括更深层后代；根级和全树搜索中不显示，避免“当前搜索结果”与整个隐藏分组混淆。

未选/全选/部分选择使用原生Checkbox false/true/indeterminate。部分状态再次勾选补齐全部，取消仅移除本组可用叶节点；组外/未知ID、已有禁用ID保持不变。继承禁用的后代不参与数量或全选；无可用叶节点时禁用。`disabled`阻止组操作。组更新一次数组模型，不自动提交业务请求，使用方明确应用并重置分页。

数组仍只保存实际叶节点ID，不能存父ID代表后代。这是一次明确快照，不是永久“订阅此分组”：树后续新增叶节点不自动选中，状态转为部分选择。完整树由消费者保证；懒加载/权限未完全加载的树不能套此选项，否则缺页会被误认为已全选。重复ID等仍遵循索引验证。

无新组件或新版本属性；同版包含配置、用途与迁移文档。头部复选框隔离Space/Enter冒泡，不让Combobox拦截选择当前叶节点；Space操作保持原生复选框，Escape关闭回到触发器。`collectionHierarchyGroup`与`toggleCollectionHierarchyGroup`从collection导出，可独立做静态分组计算。

## 可选祖先路径导航（interaction.18）

`breadcrumbs=true` 将当前层级标题单独显示，下面仅显示根级与可点击的祖先路径，避免重复当前标题；默认false保留原版返回按钮与路径摘要。适合深层板块、目录筛选，少量平铺选项无需开启。路径按ID而非标题导航，同名祖先不会混淆；祖先按钮的title提供完整路径。路径允许换行，按钮沿用原生size/ui及主题，不强制缩小控件。

点击任意祖先或根级只改变浏览位置、清空查询并恢复搜索框焦点；保留叶节点选择、组外选择和消费者草稿，不发业务请求。搜索时显示全树搜索结果标题并隐藏祖先路径，清空搜索恢复之前位置。可与groupSelection独立组合，当前分组变化后全选范围也随之变化。当前节点失效仍回根级。未提供ui.content时使用原生可用视口高度，避免路径栏挤占原生菜单默认高度；提供ui.content时原样保留调用方配置（包括类替换函数）。

展开菜单无障碍限制：Nuxt UI 4.11.2/4.11.3的SelectMenu在listbox内渲染带tabindex的FocusScope，完整弹层Axe会报告aria-required-children；增强关闭区域和单独控件检查通过不代表整个弹层通过。该上游结构问题尚未解决，不通过修改运行时DOM或忽略规则掩盖。

## 紧凑层级浏览（interaction.20）

当前层级浏览只显示节点标题，祖先上下文放在导航区；全树搜索仍提供完整祖先辅助路径，已选标签和定位文案保留完整路径。breadcrumbs 返回按钮使用图标并保留可访问名称，当前标题只显示一次；根级没有重复根路径。本组复选框与数量摘要并排，窄屏必要时换行。没有修改模型、搜索范围、全选范围或新增必填属性；消费者可直接升级，groupSelection 文案仍由消费者提供，建议短标签配合数量摘要。
