import type { CollectionControlValue } from "./panel";
import type { CollectionMultiSelectOption } from "./multi-select";
export interface CollectionHierarchyNode extends CollectionMultiSelectOption {
  readonly children?: readonly CollectionHierarchyNode[];
}
export interface CollectionHierarchyEntry extends CollectionMultiSelectOption {
  readonly parent: CollectionControlValue | null;
  readonly children: readonly CollectionControlValue[];
  readonly path: readonly string[];
}
/** IDs are global, stable and type-sensitive; disabled ancestors disable descendants. */
export function indexCollectionHierarchy(
  nodes: readonly CollectionHierarchyNode[],
) {
  const entries = new Map<CollectionControlValue, CollectionHierarchyEntry>();
  function visit(
    node: CollectionHierarchyNode,
    parent: CollectionControlValue | null,
    path: readonly string[],
    disabled: boolean,
  ) {
    if (entries.has(node.value))
      throw new TypeError(`Duplicate hierarchy ID: ${node.value}`);
    const nextPath = [...path, node.label];
    const blocked = disabled || !!node.disabled;
    entries.set(node.value, {
      value: node.value,
      label: node.label,
      icon: node.icon,
      trailingIcon: node.trailingIcon,
      keywords: node.keywords,
      disabled: blocked,
      parent,
      path: nextPath,
      description: path.join(" / "),
      children: node.children?.map((child) => child.value) ?? [],
    });
    for (const child of node.children ?? [])
      visit(child, node.value, nextPath, blocked);
  }
  for (const node of nodes) visit(node, null, [], false);
  return { entries, roots: nodes.map((node) => node.value) };
}

/** Complete static tree only: disabled descendants are excluded; unknown IDs stay consumer-owned. */
export function collectionHierarchyGroup(index: ReturnType<typeof indexCollectionHierarchy>, branch: CollectionControlValue, selected: readonly CollectionControlValue[]) {
 const leaves: CollectionControlValue[]=[];
 function visit(value: CollectionControlValue) {
  const item=index.entries.get(value);if(!item || item.disabled)return;
  if(!item.children.length)leaves.push(item.value);else for(const child of item.children)visit(child);
 }
 const root=index.entries.get(branch);
 if(root?.children.length)visit(branch);
 const chosen=new Set(selected), count=leaves.filter(id=>chosen.has(id)).length;
 const state: boolean | "indeterminate"=count===0?false:count===leaves.length?true:"indeterminate";
 return {leaves,count,total:leaves.length,state};
}
export function toggleCollectionHierarchyGroup(selected: readonly CollectionControlValue[], leaves: readonly CollectionControlValue[], checked: boolean) {
 const scope=new Set(leaves);
 return checked ? [...new Set([...selected,...leaves])] : selected.filter(value=>!scope.has(value));
}
