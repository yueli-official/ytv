<script setup lang="ts">
import type { ButtonProps } from "@nuxt/ui";
import { computed, ref, watch } from "vue";
import type { CollectionControl, CollectionControlValue } from "../panel";
import CollectionTableToolbar from "./CollectionTableToolbar.vue";
import CollectionViewToggle from "./CollectionViewToggle.vue";
import CollectionMultiSelect from "./CollectionMultiSelect.vue";
import CollectionFilterSurface, {
  type CollectionFilterPresentation,
} from "./CollectionFilterSurface.vue";
import type {
  CollectionMultiSelectControl,
  CollectionFilterApply,
} from "../multi-select";
const props = withDefaults(
  defineProps<{
    label: string;
    size?: ButtonProps["size"];
    searchPlaceholder: string;
    searchId?: string;
    searchable?: boolean;
    externalControls?: boolean;
    selectionCount?: number;
    controls?: readonly CollectionControl[];
    multiControls?: readonly CollectionMultiSelectControl[];
    filterPresentation?: CollectionFilterPresentation;
    sortControls?: readonly CollectionControl[];
    filterCount?: number;
    filterLabel?: string;
    sortLabel?: string;
    sortBy?: string;
    sortOrder?: "asc" | "desc";
    sortOptions?: readonly { label: string; value: string }[];
    view?: "list" | "grid" | "tree" | "table";
    viewItems?: readonly {
      key: "list" | "grid" | "tree" | "table";
      label: string;
      icon: string;
    }[];
  }>(),
  { searchable: true, filterLabel: "筛选", sortLabel: "排序" },
);
const search = defineModel<string>("search", { default: "" });
const emit = defineEmits<{
  controlChange: [id: string, value: CollectionControlValue];
  search: [value: string];
  filters: [values: Record<string, CollectionControlValue>];
  filterApply: [snapshot: CollectionFilterApply];
  sort: [by: string, order: "asc" | "desc"];
  "update:view": [value: "list" | "grid" | "tree" | "table"];
}>();
const filters = computed(() =>
  (props.controls ?? []).filter((c) => c.kind === "select"),
);
const filtersOpen = defineModel<boolean>("filtersOpen", { default: false });
const sortOpen = ref(false);
const draft = ref<Record<string, CollectionControlValue>>({});
const multiDraft = ref<Record<string, CollectionControlValue[]>>({});
const controlSortDraft = ref<Record<string, CollectionControlValue>>({});
const sortDraft = ref("");
const directionDraft = ref<"asc" | "desc">("desc");
watch(
  filtersOpen,
  (open) => {
    if (!open) return;
    draft.value = Object.fromEntries(filters.value.map((c) => [c.id, c.value]));
    multiDraft.value = Object.fromEntries(
      (props.multiControls ?? []).map((c) => [c.id, [...c.value]]),
    );
  },
  { immediate: true, flush: "sync" },
);
function openSort() {
  controlSortDraft.value = Object.fromEntries(
    (props.sortControls ?? []).map((c) => [c.id, c.value]),
  );
  sortDraft.value = props.sortBy ?? "";
  directionDraft.value = props.sortOrder ?? "desc";
  sortOpen.value = true;
}
function applyFilters() {
  const snapshot: CollectionFilterApply = {
    values: { ...draft.value },
    multiValues: Object.fromEntries(
      Object.entries(multiDraft.value).map(([id, value]) => [id, [...value]]),
    ),
  };
  emit("filters", { ...draft.value });
  for (const control of filters.value) {
    if (draft.value[control.id] !== control.value)
      emit("controlChange", control.id, draft.value[control.id]!);
  }
  emit("filterApply", snapshot);
  filtersOpen.value = false;
}
function applySort() {
  if (props.sortControls?.length) {
    for (const control of props.sortControls) {
      if (controlSortDraft.value[control.id] !== control.value)
        emit("controlChange", control.id, controlSortDraft.value[control.id]!);
    }
  } else emit("sort", sortDraft.value, directionDraft.value);
  sortOpen.value = false;
}
</script>
<template>
  <UTheme
    :props="{
      button: { size },
      input: { size },
      select: { size },
      selectMenu: { size },
      pagination: { size },
    }"
  >
    <CollectionTableToolbar
      v-model:search="search"
      presentation="header"
      :size="size"
      :searchable="searchable"
      :external-controls="externalControls"
      :selection-count="selectionCount"
      :search-id="searchId"
      :label="label"
      :search-placeholder="searchPlaceholder"
      :filter-label="filterLabel"
      :filter-count="filterCount"
      @search="emit('search', $event)"
    >
      <template #utilities>
        <CollectionFilterSurface
          v-if="filters.length || multiControls?.length"
          v-model:open="filtersOpen"
          :presentation="filterPresentation"
          :title="filterLabel"
          :size="size"
          :label="filterCount ? `${filterLabel} · ${filterCount}` : filterLabel"
        >
          <template #body
            ><div class="grid gap-4">
              <UFormField
                v-for="control in filters"
                :key="control.id"
                :label="control.label"
              >
                <USelectMenu
                  v-if="
                    control.searchPlaceholder || control.options.length > 10
                  "
                  v-model="draft[control.id]"
                  :items="[...control.options]"
                  value-key="value"
                  :aria-label="control.label"
                  :search-input="
                    control.searchPlaceholder
                      ? { placeholder: control.searchPlaceholder }
                      : undefined
                  "
                  class="w-full"
                >
                  <template #item-trailing="{ item, ui }"
                    ><UIcon
                      v-if="item.trailingIcon"
                      :name="item.trailingIcon"
                      :class="ui.itemTrailingIcon()"
                      aria-hidden="true"
                  /></template>
                </USelectMenu>
                <USelect
                  v-else
                  v-model="draft[control.id]"
                  :items="[...control.options]"
                  value-key="value"
                  :aria-label="control.label"
                  class="w-full"
                >
                  <template #item-trailing="{ item, ui }"
                    ><UIcon
                      v-if="item.trailingIcon"
                      :name="item.trailingIcon"
                      :class="ui.itemTrailingIcon()"
                      aria-hidden="true"
                  /></template>
                </USelect>
              </UFormField>
              <UFormField
                v-for="control in multiControls"
                :key="`multi:${control.id}`"
                :label="control.label"
              >
                <CollectionMultiSelect
                  v-model="multiDraft[control.id]"
                  :options="control.options"
                  :label="control.label"
                  :placeholder="control.placeholder"
                  :messages="control.messages"
                  :disabled="control.disabled"
                  :size="size"
                  :visible-limit="control.visibleLimit"
                  :selected-first="control.selectedFirst"
                  :search-fields="control.searchFields"
                  :virtualize="control.virtualize"
                />
              </UFormField></div
          ></template>
          <template #footer
            ><UButton
              label="取消"
              color="neutral"
              variant="outline"
              @click="void (filtersOpen = false)" /><UButton
              label="应用筛选"
              @click="applyFilters"
          /></template>
        </CollectionFilterSurface>
        <UButton
          v-if="sortOptions?.length || sortControls?.length"
          color="neutral"
          variant="outline"
          icon="i-tabler-sort-descending"
          :label="sortLabel"
          @click="openSort"
        />
        <CollectionViewToggle
          v-if="viewItems?.length"
          appearance="surface"
          :model-value="view ?? 'list'"
          :items="[...viewItems]"
          @update:model-value="emit('update:view', $event)"
        />
        <slot name="view" />
        <slot name="utilities" />
      </template>
      <template v-if="$slots.actions" #actions><slot name="actions" /></template>
      <template v-if="$slots['active-filters']" #active-filters>
        <slot name="active-filters" />
      </template>
      <template v-if="$slots.selection" #selection>
        <slot name="selection" />
      </template>
    </CollectionTableToolbar>
    <UModal
      v-model:open="sortOpen"
      :title="sortLabel"
      :ui="{ content: 'max-w-sm', footer: 'justify-end' }"
    >
      <template #body
        ><div class="grid gap-5">
          <template v-if="sortControls?.length">
            <UFormField
              v-for="control in sortControls"
              :key="control.id"
              :label="control.label"
            >
              <USelect
                v-if="control.kind === 'select'"
                v-model="controlSortDraft[control.id]"
                :items="[...control.options]"
                value-key="value"
                class="w-full"
              >
                <template #item-trailing="{ item, ui }"
                  ><UIcon
                    v-if="item.trailingIcon"
                    :name="item.trailingIcon"
                    :class="ui.itemTrailingIcon()"
                    aria-hidden="true"
                /></template>
              </USelect>
              <URadioGroup
                v-else
                :model-value="String(controlSortDraft[control.id])"
                @update:model-value="controlSortDraft[control.id] = $event"
                :items="[
                  { label: '升序', value: 'asc' },
                  { label: '降序', value: 'desc' },
                ]"
              />
            </UFormField>
          </template>
          <template v-else
            ><UFormField label="排序依据"
              ><URadioGroup
                v-model="sortDraft"
                :items="[...(sortOptions ?? [])]"
            /></UFormField>
            <UFormField label="顺序"
              ><URadioGroup
                v-model="directionDraft"
                :items="[
                  { label: '升序', value: 'asc' },
                  { label: '降序', value: 'desc' },
                ]" /></UFormField
          ></template></div
      ></template>
      <template #footer
        ><UButton
          label="取消"
          color="neutral"
          variant="outline"
          @click="void (sortOpen = false)" /><UButton
          label="应用排序"
          @click="applySort"
      /></template>
    </UModal>
  </UTheme>
</template>
