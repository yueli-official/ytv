<script setup lang="ts">
import { computed, nextTick, ref, watch } from "vue";
import UCheckbox from "@nuxt/ui/components/Checkbox.vue";
import UButton from "@nuxt/ui/components/Button.vue";
import type { SelectMenuProps } from "@nuxt/ui";
import CollectionMultiSelect from "./CollectionMultiSelect.vue";
import {
  indexCollectionHierarchy,
  collectionHierarchyGroup,
  toggleCollectionHierarchyGroup,
  type CollectionHierarchyNode,
} from "../hierarchy";
import type { CollectionControlValue } from "../panel";
import type { CollectionMultiSelectMessages } from "../multi-select";
const props = withDefaults(
  defineProps<{
    nodes: readonly CollectionHierarchyNode[];
    label: string;
    placeholder: string;
    messages: CollectionMultiSelectMessages & {
      root: string;
      back: string;
      searchResults: string;
      enter: (label: string) => string;
    };
    /** Explicit selection of enabled descendants in a complete static tree. */
    groupSelection?: { label: (name: string, total: number) => string; summary: (selected: number, total: number) => string };
    /** Show clickable ancestors and a separate current-level title. */
    breadcrumbs?: boolean;
    /** Locate an enabled selected leaf in its parent without changing selection. */
    locateSelected?: { label: (name: string) => string };
    disabled?: boolean;
    visibleLimit?: number;
    size?: SelectMenuProps["size"];
    ui?: SelectMenuProps["ui"];
  }>(),
  { disabled: false, visibleLimit: 2, breadcrumbs: false },
);
const model = defineModel<CollectionControlValue[]>({ default: () => [] });
const menuUi = computed(() => props.breadcrumbs ? {
  ...props.ui,
  // Let the native collision boundary size the menu; extra navigation must not
  // consume the small default menu budget. Consumer classes retain precedence.
  content: props.ui?.content ?? "max-h-(--reka-combobox-content-available-height)",
} : props.ui);
const menu = ref<{ focusSearch: () => void; openSearch: () => Promise<void> } | null>(null);
function locateLabel(option: {value: CollectionControlValue; label: string}) {
  const item=index.value.entries.get(option.value);
  return props.locateSelected && item && !item.disabled && !item.children.length
    ? props.locateSelected.label(item.path.join(' / ')) : undefined;
}
async function locate(value: CollectionControlValue) {
  const item=index.value.entries.get(value);
  if(!props.locateSelected || props.disabled || !item || item.disabled || item.children.length) return;
  await navigate(item.parent);
  await menu.value?.openSearch();
}
const current = ref<CollectionControlValue | null>(null);
const query = ref("");
const index = computed(() => indexCollectionHierarchy(props.nodes));
const parent = computed(() =>
  current.value === null ? undefined : index.value.entries.get(current.value),
);
const group = computed(() => current.value === null ? undefined : collectionHierarchyGroup(index.value,current.value,model.value));
const ancestors = computed(() => {
  const result = [];
  let id = parent.value?.parent ?? null;
  while (id !== null) {
    const entry = index.value.entries.get(id);
    if (!entry) break;
    result.unshift(entry);
    id = entry.parent;
  }
  return result;
});
function toggleGroup(checked: boolean | "indeterminate") {
  if(props.disabled || !props.groupSelection || !group.value?.total) return;
  model.value=toggleCollectionHierarchyGroup(model.value,group.value.leaves,checked === true);
}
const searching = computed(() => !!query.value.trim());
const all = computed(() => [...index.value.entries.values()]);
const options = computed(() => {
  if (searching.value) {
    const term = query.value.trim().toLowerCase();
    return all.value.filter(
      (item) =>
        item.children.length === 0 &&
        `${item.path.join(" / ")} ${item.keywords ?? ""}`
          .toLowerCase()
          .includes(term),
    );
  }
  return (parent.value?.children ?? index.value.roots).map((id) => {
    const entry = index.value.entries.get(id)!;
    // Browsing already provides the ancestor context in the navigation.
    // Keep full paths for global search and selected-item metadata only.
    const item = { ...entry, ui: { itemDescription: "hidden" } };
    return item.children.length
      ? {
          ...item,
          trailingIcon: "i-tabler-chevron-right",
          onSelect: (event: Event) => {
            event.preventDefault();
            void navigate(item.value);
          },
        }
      : item;
  });
});
async function navigate(value: CollectionControlValue | null) {
  current.value = value;
  query.value = "";
  await nextTick();
  menu.value?.focusSearch();
}
watch(index, (value) => {
  if (
    current.value !== null &&
    !value.entries.get(current.value)?.children.length
  )
    current.value = null;
});
</script>
<template>
  <CollectionMultiSelect
    ref="menu"
    v-model="model"
    v-model:search-term="query"
    :options="options"
    :selected-options="all"
    :label="label"
    :placeholder="placeholder"
    :messages="messages"
    :disabled="disabled"
    :visible-limit="visibleLimit"
    :size="size"
    :ui="menuUi"
    ignore-filter
    :selected-first="false"
    :locate="locateSelected ? locateLabel : undefined"
    @locate="locate"
  >
    <template #item-label="{ item }">
      {{ item.label
      }}<span
        v-if="index.entries.get(item.value)?.children.length"
        class="sr-only"
      >
        {{ messages.enter(item.label) }}</span
      >
    </template>
    <template #content-top>
      <div v-if="breadcrumbs" class="space-y-1 border-b border-default p-2" data-hierarchy-breadcrumbs>
        <div class="flex min-w-0 items-center gap-2">
          <UButton v-if="parent && !searching" :aria-label="messages.back" :title="messages.back" icon="i-tabler-arrow-left" color="neutral" variant="ghost" :size="size" @keydown.enter.stop @keydown.space.stop @click="navigate(parent.parent)" />
          <span class="min-w-0 break-words text-sm font-medium" role="status" aria-current="page" data-hierarchy-current>{{ searching ? messages.searchResults : parent?.label ?? messages.root }}</span>
        </div>
        <nav v-if="parent || searching" :aria-label="messages.root" class="flex flex-wrap items-center gap-1 text-xs text-muted">
          <UButton :label="messages.root" icon="i-tabler-home" color="neutral" variant="ghost" :size="size" @keydown.enter.stop @keydown.space.stop @click="navigate(null)" />
          <template v-if="!searching">
            <template v-for="ancestor in ancestors" :key="ancestor.value">
              <span aria-hidden="true">/</span>
              <UButton :label="ancestor.label" :title="ancestor.path.join(' / ')" color="neutral" variant="ghost" :size="size" class="max-w-full" :ui="{ label: 'truncate' }" @keydown.enter.stop @keydown.space.stop @click="navigate(ancestor.value)" />
            </template>
          </template>
        </nav>
      </div>
      <div v-else
        class="flex items-center gap-2 border-b border-default p-2"
        data-hierarchy-navigation
      >
        <UButton
          v-if="parent"
          :label="messages.back"
          icon="i-tabler-arrow-left"
          color="neutral"
          variant="ghost"
          :size="size"
          @click="navigate(parent.parent)"
        />
        <UButton
          :label="messages.root"
          icon="i-tabler-home"
          color="neutral"
          variant="ghost"
          :size="size"
          @click="navigate(null)"
        />
        <span
          class="min-w-0 truncate text-sm text-muted"
          role="status"
          :title="parent?.path.join(' / ')"
          >{{
            searching ? messages.searchResults : parent?.path.join(" / ")
          }}</span
        >
      </div>
      <div v-if="groupSelection && parent && group && !searching" class="flex flex-wrap items-center justify-between gap-x-3 gap-y-1 border-b border-default p-2" data-hierarchy-group>
        <UCheckbox class="min-w-0 flex-1" :model-value="group.state" :label="groupSelection.label(parent.label,group.total)" :disabled="disabled || !group.total" :size="size" @keydown.space.stop @keydown.enter.stop @update:model-value="toggleGroup" />
        <p class="shrink-0 text-xs text-muted" role="status">{{ groupSelection.summary(group.count,group.total) }}</p>
      </div>
    </template>
  </CollectionMultiSelect>
</template>
