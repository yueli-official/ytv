# 数值区间与常用范围

NumericRangeFilter 从 `@yueli/ui/admin-platform` 导出，Nuxt 自动注册 `YNumericRangeFilter`。使用场景包括回复数量、订单金额、阅读数与文件大小；单位、边界与数据过滤语义由消费者拥有。日期范围涉及时区、日界线及相对时间，不能直接拿数值区间代替。

## 配置

modelValue 是 `{ min?: number, max?: number }`。空边界表示不限，0 是有效值；floor、ceiling、integer 控制校验，parseNumericRange 拒绝非有限数、不安全数、倒置及越界值。typing 只编辑草稿，apply 完整返回一次范围；既有 update:modelValue 同时保留，**只监听 apply 触发列表请求**，避免两个事件重复请求。

presets 是 `{id,label,value,disabled?}` 数组，ID 在列表内唯一；没有 presets 时保留手输入口。默认 presetApply=false，点选填入草稿并标记匹配范围，仍需“应用区间”；true 则点选直接应用一次。按钮选中表示输入草稿匹配，已应用状态由消费者的活动筛选标签和结果列表显示，不把草稿误当成列表已更新。shortcut 值使用同一解析器，非法配置不改变已应用范围。

disabled 同时禁用输入、快捷项、提交和清空；size/ui 使用 Nuxt UI 原生合同（ui 作用于输入框）。未指定 size 时保留输入原生尺寸和旧动作 xs；指定时输入及动作采用同一 size。messages 可配置 apply/clear/unlimited/shortcuts 文案；解析器沿用既有中文错误合同。错误关联输入并恢复焦点，保留草稿供修正；表单使用 novalidate 交给共享解析器呈现错误，避免浏览器气泡与字段消息重复。

## 集成

```vue
<NumericRangeFilter
  :model-value="query.replies"
  label="回复数量" unit="条" :floor="0" integer
  :presets="[{id:'none',label:'0 条回复',value:{min:0,max:0}}]"
  @apply="range => applyQuery({ ...query, replies: range, page: 1 })"
/>
```

放在集合工具栏的筛选区域或独立面板，与搜索、结果、活动筛选及分页配套。组件本身是 form，**不嵌入另一个 form**；通过筛选容器 body slot 单独放置，或使用独立区域。清除区间发出一次不限范围，消费方更新结果和页码。数值存储精度、金额最小单位、范围是否包含边界与远端请求由产品明确；示例使用包含 min/max 的本地静态内容数据，不代表后端接入。

## 迁移

interaction.14 为既有 NumericRangeFilter 增量配置，不新建重复实现。旧 model/update/apply 语义保持；新增 ceiling 仅显式配置时生效，presets 默认无，presetApply 默认不自动应用。空范围、零值、开区间和反序错误均需保留。组件说明随包版本/AI catalog 分发，不另维护组件内部 SemVer。
