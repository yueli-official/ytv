<script setup lang="ts">
import { computed, nextTick, ref, useId, useTemplateRef, watch } from "vue";
import type { InputProps } from "@nuxt/ui";
import { parseNumericRange, type NumericRange, type NumericRangePreset } from "../numeric-range";
const props = defineProps<{
  modelValue: NumericRange;
  label: string;
  unit?: string;
  floor?: number;
  ceiling?: number;
  integer?: boolean;
  presets?: readonly NumericRangePreset[];
  /** False: shortcut fills the draft; true: shortcut applies exactly once. */
  presetApply?: boolean;
  disabled?: boolean;
  size?: InputProps["size"];
  ui?: InputProps["ui"];
  messages?: { apply?: string; clear?: string; unlimited?: string; shortcuts?: string };
}>();
const emit = defineEmits<{
  "update:modelValue": [value: NumericRange];
  apply: [value: NumericRange];
}>();
const lower = ref("");
const upper = ref("");
const error = ref("");
const errorId = `numeric-range-${useId()}`;
const lowerInput = useTemplateRef<{ inputRef: HTMLInputElement | null }>("lowerInput");
const upperInput = useTemplateRef<{ inputRef: HTMLInputElement | null }>("upperInput");
const messages = computed(() => ({ apply: "应用区间", clear: "清除区间", unlimited: "不限", shortcuts: "常用范围", ...props.messages }));
watch(
  () => props.modelValue,
  (value) => {
    lower.value = value.min === undefined ? "" : String(value.min);
    upper.value = value.max === undefined ? "" : String(value.max);
    error.value = "";
  },
  { immediate: true, deep: true },
);
async function showError(reason: unknown) {
  error.value = reason instanceof Error ? reason.message : "请输入有效范围";
  let target = lowerInput;
  try { parseNumericRange(lower.value, undefined, props); }
  catch { await nextTick(); target.value?.inputRef?.focus(); return; }
  try { parseNumericRange(undefined, upper.value, props); }
  catch { target = upperInput; }
  await nextTick();
  target.value?.inputRef?.focus();
}
function apply() {
  if (props.disabled) return;
  try {
    const value = parseNumericRange(lower.value, upper.value, props);
    error.value = "";
    emit("update:modelValue", value);
    emit("apply", value);
  } catch (reason) {
    void showError(reason);
  }
}
function clear() {
  if (props.disabled) return;
  lower.value = "";
  upper.value = "";
  apply();
}
function isPreset(preset: NumericRangePreset) {
  try {
    const draft = parseNumericRange(lower.value, upper.value, props);
    return draft.min === preset.value.min && draft.max === preset.value.max;
  } catch { return false; }
}
function choose(preset: NumericRangePreset) {
  if (props.disabled || preset.disabled) return;
  try {
    const value = parseNumericRange(preset.value.min, preset.value.max, props);
    lower.value = value.min === undefined ? "" : String(value.min);
    upper.value = value.max === undefined ? "" : String(value.max);
    error.value = "";
    if (props.presetApply) apply();
  } catch (reason) { void showError(reason); }
}
</script>
<template>
  <form
    novalidate
    class="grid min-w-0 gap-2"
    :aria-label="`${label}区间`"
    @submit.prevent="apply"
  >
    <strong class="text-xs font-semibold text-highlighted"
      >{{ label
      }}<span v-if="unit" class="font-normal text-muted"
        >（{{ unit }}）</span
      ></strong
    >
    <div v-if="presets?.length" role="group" :aria-label="messages.shortcuts" class="flex flex-wrap gap-2">
      <UButton v-for="preset in presets" :key="preset.id" :label="preset.label" :aria-pressed="isPreset(preset)" :color="isPreset(preset) ? 'primary' : 'neutral'" variant="soft" :size="size ?? 'xs'" :disabled="disabled || preset.disabled" @click="choose(preset)" />
    </div>
    <div class="flex min-w-0 items-center gap-2">
      <UInput
        ref="lowerInput"
        :disabled="disabled"
        :size="size"
        :ui="ui"
        :max="ceiling"
        :aria-invalid="!!error"
        :aria-describedby="error ? errorId : undefined"
        :model-value="lower"
        type="number"
        @update:model-value="lower = String($event ?? '')"
        :step="integer ? 1 : 'any'"
        :min="floor"
        :aria-label="`${label}下限`"
        :placeholder="messages.unlimited"
        class="min-w-0 flex-1"
      />
      <span class="text-muted" aria-hidden="true">~</span>
      <UInput
        ref="upperInput"
        :disabled="disabled"
        :size="size"
        :ui="ui"
        :max="ceiling"
        :aria-invalid="!!error"
        :aria-describedby="error ? errorId : undefined"
        :model-value="upper"
        type="number"
        @update:model-value="upper = String($event ?? '')"
        :step="integer ? 1 : 'any'"
        :min="floor"
        :aria-label="`${label}上限`"
        :placeholder="messages.unlimited"
        class="min-w-0 flex-1"
      />
    </div>
    <p v-if="error" :id="errorId" role="alert" class="text-xs text-error">{{ error }}</p>
    <div class="flex gap-2">
      <UButton
        type="submit"
        :label="messages.apply"
        :size="size ?? 'xs'"
        :disabled="disabled"
        variant="soft"
      /><UButton
        v-if="lower || upper"
        :label="messages.clear"
        :size="size ?? 'xs'"
        :disabled="disabled"
        color="neutral"
        variant="ghost"
        @click="clear"
      />
    </div>
  </form>
</template>
