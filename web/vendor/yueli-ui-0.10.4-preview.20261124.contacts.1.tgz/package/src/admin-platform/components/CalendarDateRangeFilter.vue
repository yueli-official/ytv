<script setup lang="ts">
import { computed, nextTick, ref, useId, useTemplateRef, watch } from "vue";
import type { InputProps } from "@nuxt/ui";
import { parseCalendarDateRange, type CalendarDateRange, type CalendarDatePreset } from "../date-range";
const props = defineProps<{
  modelValue: CalendarDateRange;
  label: string;
  /** Visible business timezone context; dates remain inclusive strings. */
  timeZoneLabel?: string;
  presets?: readonly CalendarDatePreset[];
  /** False: shortcut fills the draft; true: shortcut applies exactly once. */
  presetApply?: boolean;
  disabled?: boolean;
  size?: InputProps["size"];
  ui?: InputProps["ui"];
  messages?: { apply?: string; clear?: string; unlimited?: string; shortcuts?: string };
}>();
const emit = defineEmits<{
  "update:modelValue": [value: CalendarDateRange];
  apply: [value: CalendarDateRange];
}>();
const lower = ref("");
const upper = ref("");
const error = ref("");
const errorId = `calendar-range-${useId()}`;
const lowerInput = useTemplateRef<{ inputRef: HTMLInputElement | null }>("lowerInput");
const upperInput = useTemplateRef<{ inputRef: HTMLInputElement | null }>("upperInput");
const messages = computed(() => ({ apply: "应用日期", clear: "清除日期", unlimited: "不限", shortcuts: "常用日期", ...props.messages }));
watch(
  () => props.modelValue,
  (value) => {
    lower.value = value.start === undefined ? "" : String(value.start);
    upper.value = value.end === undefined ? "" : String(value.end);
    error.value = "";
  },
  { immediate: true, deep: true },
);
async function showError(reason: unknown) {
  error.value = reason instanceof Error ? reason.message : "请输入有效范围";
  let target = upperInput.value?.inputRef?.validity.badInput ? upperInput : lowerInput;
  try { parseCalendarDateRange(lower.value, undefined); }
  catch { await nextTick(); target.value?.inputRef?.focus(); return; }
  try { parseCalendarDateRange(undefined, upper.value); }
  catch { target = upperInput; }
  await nextTick();
  target.value?.inputRef?.focus();
}
function apply() {
  if (props.disabled) return;
  try {
    if (lowerInput.value?.inputRef?.validity.badInput || upperInput.value?.inputRef?.validity.badInput) throw new Error("请补全日期");
    const value = parseCalendarDateRange(lower.value, upper.value);
    error.value = "";
    emit("update:modelValue", value);
    emit("apply", value);
  } catch (reason) {
    void showError(reason);
  }
}
function clear() {
  if (props.disabled) return;
  lower.value = "";
  upper.value = "";
  apply();
}
function isPreset(preset: CalendarDatePreset) {
  try {
    const draft = parseCalendarDateRange(lower.value, upper.value);
    return draft.start === preset.value.start && draft.end === preset.value.end;
  } catch { return false; }
}
function choose(preset: CalendarDatePreset) {
  if (props.disabled || preset.disabled) return;
  try {
    const value = parseCalendarDateRange(preset.value.start, preset.value.end);
    lower.value = value.start === undefined ? "" : String(value.start);
    upper.value = value.end === undefined ? "" : String(value.end);
    error.value = "";
    if (props.presetApply) apply();
  } catch (reason) { void showError(reason); }
}
</script>
<template>
  <form
    novalidate
    class="grid min-w-0 gap-2"
    :aria-label="`${label}区间`"
    @submit.prevent="apply"
  >
    <strong class="text-xs font-semibold text-highlighted"
      >{{ label
      }}<span v-if="timeZoneLabel" class="font-normal text-muted"
        >（{{ timeZoneLabel }}）</span
      ></strong
    >
    <div v-if="presets?.length" role="group" :aria-label="messages.shortcuts" class="flex flex-wrap gap-2">
      <UButton v-for="preset in presets" :key="preset.id" :label="preset.label" :aria-pressed="isPreset(preset)" :color="isPreset(preset) ? 'primary' : 'neutral'" variant="soft" :size="size ?? 'xs'" :disabled="disabled || preset.disabled" @click="choose(preset)" />
    </div>
    <div class="flex min-w-0 items-center gap-2">
      <UInput
        ref="lowerInput"
        :disabled="disabled"
        :size="size"
        :ui="ui"

        :aria-invalid="!!error"
        :aria-describedby="error ? errorId : undefined"
        :model-value="lower"
        type="date"
        @update:model-value="lower = String($event ?? '')"


        :aria-label="`${label}开始日期`"
        :placeholder="messages.unlimited"
        class="min-w-0 flex-1"
      />
      <span class="text-muted" aria-hidden="true">~</span>
      <UInput
        ref="upperInput"
        :disabled="disabled"
        :size="size"
        :ui="ui"

        :aria-invalid="!!error"
        :aria-describedby="error ? errorId : undefined"
        :model-value="upper"
        type="date"
        @update:model-value="upper = String($event ?? '')"


        :aria-label="`${label}结束日期`"
        :placeholder="messages.unlimited"
        class="min-w-0 flex-1"
      />
    </div>
    <p v-if="error" :id="errorId" role="alert" class="text-xs text-error">{{ error }}</p>
    <div class="flex gap-2">
      <UButton
        type="submit"
        :label="messages.apply"
        :size="size ?? 'xs'"
        :disabled="disabled"
        variant="soft"
      /><UButton
        v-if="lower || upper"
        :label="messages.clear"
        :size="size ?? 'xs'"
        :disabled="disabled"
        color="neutral"
        variant="ghost"
        @click="clear"
      />
    </div>
  </form>
</template>
