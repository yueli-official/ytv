# CalendarDateRangeFilter 日期范围

从 `@yueli/ui/admin-platform` 导入，Nuxt 注册 `YCalendarDateRangeFilter`。用于内容更新日、订单日期等日历日期筛选，首尾均包含。模型 `{start?: "YYYY-MM-DD", end?: "YYYY-MM-DD"}`，空端不限，同日合法，非法日期和反向范围拒绝。不是时间戳范围。

`presets: CalendarDatePreset[]` 由消费者提供。默认点选只填草稿；`presetApply=true` 一次应用。`recentCalendarDays(today,days)` 包含参考日，today 必须由消费者按业务时区生成；不要在 SSR/客户端各自推导今天。相对日期保存为具体日期快照；需要滚动相对范围的产品另定义查询合同。

`timeZoneLabel` 仅显示上下文，不做时间转换。过滤时间戳时，消费者将开始日和结束日次日分别转换成指定时区的日界线，使用左闭右开；不得加固定24小时处理夏令时，不要把日期字符串当 UTC 午夜直接发到后端。

`label` 必填；`disabled`、原生 Input size/ui、messages 配置可选。无 nested form。只监听 apply 发查询并重置分页，update:modelValue 用于模型绑定；取消/重置由使用方更改模型，组件会同步草稿。实际服务、URL codec、存储、时区转换和权限由消费者拥有。

默认使用 Nuxt UI UInput 的原生 date 编辑；日历系统界面由浏览器提供，不承诺跨平台弹出面板一致。需要品牌日历时组合原生 UCalendar，不重做日历网格。原有 NumericRangeFilter 不受影响。

参考：[Nuxt UI Calendar](https://ui.nuxt.com/docs/components/calendar)、[InputDate](https://ui.nuxt.com/docs/components/input-date)。
