import { lifecycleOf } from "./lifecycle.mjs";
import { createHash } from "node:crypto";
import { readFile, realpath, lstat, stat } from "node:fs/promises";
import { dirname, resolve, relative, isAbsolute } from "node:path";
import { fileURLToPath } from "node:url";
import { gunzipSync } from "node:zlib";
import { spawnSync } from "node:child_process";
import { parseDocument } from "yaml";
import semver from "semver";

const ownRoot = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
const name = "@yueli/ui";
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
const exists = async (path) => {
  try {
    await stat(path);
    return true;
  } catch (e) {
    if (e.code === "ENOENT") return false;
    throw e;
  }
};
const json = async (path) => JSON.parse(await readFile(path, "utf8"));
export class DiscoveryError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}
const fail = (code, message) => {
  throw new DiscoveryError(code, message);
};
const bounded = (value, fallback, max) => {
  const n = value === undefined ? fallback : Number(value);
  if (!Number.isInteger(n) || n < 0 || n > max)
    fail("invalid_argument", `Expected integer between 0 and ${max}.`);
  return n;
};
async function ancestor(start, file) {
  let path = start;
  while (true) {
    if (await exists(resolve(path, file))) return resolve(path, file);
    if (dirname(path) === path) return null;
    path = dirname(path);
  }
}

// Only read package metadata from bounded tar archives; never extract or execute.
export async function readArtifact(path, expectedName = name) {
  const bytes = await readFile(path);
  if (bytes.length > 32 * 1024 * 1024)
    fail("artifact_too_large", "Artifact exceeds 32 MiB.");
  const tar = gunzipSync(bytes, { maxOutputLength: 64 * 1024 * 1024 });
  const files = new Map();
  for (let offset = 0; offset + 512 <= tar.length;) {
    const header = tar.subarray(offset, offset + 512);
    if (header.every((v) => v === 0)) break;
    const file = header.subarray(0, 100).toString().split("\0")[0];
    const prefix = header.subarray(345, 500).toString().split("\0")[0];
    const key = prefix ? `${prefix}/${file}` : file;
    const size =
      Number.parseInt(
        header.subarray(124, 136).toString().replace(/\0/g, "").trim(),
        8,
      ) || 0;
    if (offset + 512 + size > tar.length)
      fail("invalid_artifact", "Truncated archive.");
    const type = header[156];
    if (
      (type === 0 || type === 48) &&
      key.startsWith("package/") &&
      !key.includes("\\") &&
      !key.split("/").includes("..")
    )
      files.set(key.slice(8), tar.subarray(offset + 512, offset + 512 + size));
    offset += 512 + Math.ceil(size / 512) * 512;
  }
  const pkg = JSON.parse(files.get("package.json")?.toString() ?? "null");
  if (pkg?.name !== expectedName)
    fail("invalid_artifact", `Not an ${expectedName} package archive.`);
  return {
    path: resolve(path),
    version: pkg.version,
    manifest: pkg,
    sha256: hash(bytes),
    bytes,
    files,
  };
}

async function lockedIdentity(project) {
  const path = await ancestor(project, "pnpm-lock.yaml");
  if (!path) return { status: "unknown", reason: "pnpm-lock.yaml not found" };
  const document = parseDocument(await readFile(path, "utf8"), {
    uniqueKeys: true,
  });
  if (document.errors.length)
    fail("invalid_lock", "Cannot parse pnpm lockfile.");
  const lock = document.toJS({ maxAliasCount: 100 });
  const importer =
    relative(dirname(path), project).replaceAll("\\", "/") || ".";
  const spec = lock.importers?.[importer];
  const dep =
    spec?.dependencies?.[name] ??
    spec?.devDependencies?.[name] ??
    spec?.optionalDependencies?.[name];
  if (!dep)
    return {
      status: "unknown",
      path,
      importer,
      reason: "No matching importer dependency",
    };
  const locked = {
    status: "known",
    path,
    importer,
    specifier: dep.specifier,
    resolution: dep.version,
  };
  const key = `${name}@${String(dep.version).split("(")[0]}`;
  const record = lock.packages?.[key];
  const reference =
    record?.resolution?.tarball ??
    (String(dep.version).startsWith("file:")
      ? String(dep.version).split("(")[0]
      : null);
  if (reference?.startsWith("file:") && reference.endsWith(".tgz")) {
    const artifactPath = resolve(dirname(path), reference.slice(5));
    if (await exists(artifactPath)) {
      const artifact = await readArtifact(artifactPath);
      locked.version = artifact.version;
      locked.artifact = { path: artifact.path, sha256: artifact.sha256 };
      if (record?.resolution?.integrity) {
        const expected = record.resolution.integrity;
        const actual = `sha512-${createHash("sha512").update(artifact.bytes).digest("base64")}`;
        locked.integrity = actual === expected ? "verified" : "conflict";
      }
    } else locked.reason = "Locked artifact is unavailable";
  } else {
    const version = String(dep.version).split("(")[0];
    if (semver.valid(version)) locked.version = version;
    else
      locked.reason =
        "Source/workspace lock reference has no immutable package version";
  }
  return locked;
}

export async function inspect({ project = ownRoot } = {}) {
  project = await realpath(resolve(project));
  if (!(await exists(resolve(project, "package.json"))))
    fail(
      "project_required",
      "Point --project at a directory containing package.json (for sites, usually web/).",
    );
  const consumer = await json(resolve(project, "package.json"));
  const declared =
    consumer.dependencies?.[name] ??
    consumer.devDependencies?.[name] ??
    consumer.optionalDependencies?.[name] ??
    null;
  const locked = await lockedIdentity(project);
  const packagePath =
    consumer.name === name
      ? project
      : await ancestor(project, "node_modules/@yueli/ui/package.json");
  if (!packagePath)
    return {
      project,
      declared,
      locked,
      resolved: null,
      sourceOverrides: [],
      warnings: ["package_not_installed"],
      runtimeResolution: "unverified",
    };
  const logicalRoot = consumer.name === name ? project : dirname(packagePath);
  const packageRoot = await realpath(logicalRoot);
  const pkg = await json(resolve(packageRoot, "package.json"));
  if (pkg.name !== name)
    fail(
      "invalid_package",
      "Resolved package metadata has an unexpected name.",
    );
  const isSource = !packageRoot
    .replaceAll("\\", "/")
    .split("/")
    .includes("node_modules");
  const linked = (await lstat(logicalRoot)).isSymbolicLink();
  const sourceOverrides = isSource
    ? [{ kind: linked ? "source-link" : "source-checkout", path: packageRoot }]
    : [];
  let source = null;
  if (isSource) {
    const revision = spawnSync("git", ["rev-parse", "HEAD"], {
      cwd: packageRoot,
      encoding: "utf8",
      windowsHide: true,
      timeout: 3000,
    });
    const status = spawnSync("git", ["status", "--porcelain", "--", "."], {
      cwd: packageRoot,
      encoding: "utf8",
      windowsHide: true,
      timeout: 3000,
    });
    source = {
      commit: revision.status === 0 ? revision.stdout.trim() : null,
      dirty: status.status === 0 ? Boolean(status.stdout.trim()) : null,
    };
  }
  const warnings = [];
  if (declared && locked.specifier && declared !== locked.specifier)
    warnings.push("declared_locked_specifier_mismatch");
  if (isSource) warnings.push("source_override");
  if (source?.dirty) warnings.push("source_modified");
  if (locked.version && locked.version !== pkg.version)
    warnings.push("locked_resolved_version_mismatch");
  if (locked.integrity === "conflict")
    warnings.push("artifact_integrity_conflict");
  const configs = [];
  for (const file of [
    "nuxt.config.ts",
    "nuxt.config.js",
    "nuxt.config.mjs",
    "vite.config.ts",
    "vite.config.js",
    "vite.config.mjs",
  ]) {
    if (await exists(resolve(project, file))) configs.push(file);
  }
  // Config files can contain dynamic code, plugins and environment-dependent aliases.
  // The filesystem resolution is evidence, never proof of the final browser bundle.
  if (configs.length) warnings.push("runtime_config_unverified");
  let artifactContent = "unverified";
  if (locked.artifact && !isSource && locked.integrity !== "conflict") {
    const artifact = await readArtifact(locked.artifact.path);
    artifactContent = "verified";
    for (const [file, bytes] of artifact.files) {
      if (file === "package.json") continue; // pnpm normalizes package metadata.
      const target = resolve(packageRoot, file);
      if (
        !(await exists(target)) ||
        hash(await readFile(target)) !== hash(bytes)
      ) {
        artifactContent = "conflict";
        break;
      }
    }
    if (artifactContent === "conflict")
      warnings.push("installed_artifact_content_conflict");
  }
  return {
    project,
    declared,
    locked,
    resolved: {
      name,
      version: pkg.version,
      packageRoot,
      logicalRoot,
      linked,
      verification: isSource
        ? "source"
        : artifactContent === "verified"
          ? "artifact"
          : "installed",
      artifactContent,
      source,
    },
    sourceOverrides,
    runtimeResolution: configs.length ? "unknown" : "node-package",
    configEvidence: configs,
    warnings,
  };
}

export async function loadCatalog(root, artifact = null) {
  const path = resolve(root, "ai/catalog.json");
  if (artifact ? !artifact.files.has("ai/catalog.json") : !(await exists(path)))
    fail(
      "catalog_unavailable",
      `No discovery catalog in the actual package at ${root}. Do not substitute latest documentation.`,
    );
  const catalog = artifact
    ? JSON.parse(artifact.files.get("ai/catalog.json").toString())
    : await json(path);
  if (catalog.schemaVersion !== 1)
    fail("unsupported_schema", "Unsupported discovery catalog schema.");
  const pkg = artifact
    ? JSON.parse(artifact.files.get("package.json").toString())
    : await json(resolve(root, "package.json"));
  if (catalog.package?.name !== name || catalog.package.version !== pkg.version)
    fail(
      "catalog_version_mismatch",
      "Catalog is not bound to this package version. Regenerate before querying.",
    );
  const { contentSha256, ...payload } = catalog;
  for (const key of ["exports", "peerDependencies"]) {
    if (JSON.stringify(catalog.package[key]) !== JSON.stringify(pkg[key]))
      fail(
        "catalog_package_mismatch",
        `Catalog ${key} differ from the actual package metadata.`,
      );
  }
  if (contentSha256 !== hash(JSON.stringify(payload)))
    fail(
      "catalog_integrity_conflict",
      "Catalog content checksum does not match.",
    );
  if (
    !Array.isArray(catalog.entries) ||
    !catalog.sourceHashes ||
    !catalog.entries.every(
      (e) =>
        typeof e.id === "string" &&
        Array.isArray(e.aliases) &&
        Array.isArray(e.capabilities) &&
        Array.isArray(e.api) &&
        e.sections,
    )
  )
    fail("invalid_catalog", "Catalog entries are malformed.");
  for (const [file, expected] of Object.entries(catalog.sourceHashes)) {
    const path = resolve(root, file);
    const rel = relative(root, path);
    if (isAbsolute(rel) || rel.startsWith(".."))
      fail(
        "invalid_catalog",
        "Catalog source paths must stay inside the package.",
      );
    const bytes = artifact
      ? artifact.files.get(file)
      : (await exists(path))
        ? await readFile(path)
        : null;
    if (!bytes || hash(bytes) !== expected)
      fail(
        "catalog_source_mismatch",
        `Catalog snapshot does not match ${file}. Regenerate before querying.`,
      );
  }
  return catalog;
}
async function current(options) {
  const identity = await inspect(options);
  if (!identity.resolved)
    fail("package_not_installed", "No installed @yueli/ui package was found.");
  if (identity.warnings.some((w) => w.includes("conflict")))
    fail(
      "identity_conflict",
      "Resolve artifact integrity conflicts before querying documentation.",
    );
  return {
    identity,
    catalog: await loadCatalog(identity.resolved.packageRoot),
  };
}
const binding = (identity, catalog) => ({
  package: { name: catalog.package.name, version: catalog.package.version },
  contentSha256: catalog.contentSha256,
  verification: identity.resolved.verification,
  warnings: identity.warnings,
});

export async function search(options = {}) {
  const { identity, catalog } = await current(options);
  const terms = String(options.query ?? "")
    .toLowerCase()
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  const limit = bounded(options.limit, 5, 20),
    offset = bounded(options.offset, 0, 10000);
  const kind = options.kind ?? "module";
  const lifecycle = options.lifecycle ?? "active";
  if (
    !["module", "component"].includes(kind) ||
    !["active", "deprecated", "removed", "all"].includes(lifecycle)
  )
    fail("invalid_filter", "Invalid kind or lifecycle filter.");
  const pool =
    kind === "component" ? (catalog.components ?? []) : catalog.entries;
  const results = pool
    .map((entry) => ({
      ...entry,
      lifecycle: lifecycleOf(entry, catalog.package.version),
    }))
    .filter(
      (entry) => lifecycle === "all" || entry.lifecycle.state === lifecycle,
    )
    .map((entry) => {
      const fields = [
        entry.id,
        entry.entrypoint,
        entry.responsibility ?? entry.name,
        ...entry.aliases,
        ...(entry.capabilities ?? []).map((c) => c.id),
      ];
      const matched = terms.filter((term) =>
        fields.some((f) => f.toLowerCase().includes(term)),
      );
      return { entry, matched, score: matched.length };
    })
    .filter(
      ({ entry, score }) =>
        (!terms.length || score > 0) &&
        (!options.capability ||
          (entry.capabilities ?? []).some((c) => c.id === options.capability)),
    )
    .sort((a, b) => b.score - a.score || a.entry.id.localeCompare(b.entry.id));
  return {
    ...binding(identity, catalog),
    total: results.length,
    offset,
    nextOffset:
      offset + limit < results.length && limit > 0 ? offset + limit : null,
    results: results
      .slice(offset, offset + limit)
      .map(({ entry, matched }) => ({
        id: entry.id,
        entrypoint: entry.entrypoint,
        kind,
        status: entry.status ?? entry.lifecycle.state,
        lifecycle: entry.lifecycle,
        available: entry.available ?? entry.lifecycle.state !== "removed",
        purpose: entry.responsibility ?? entry.name,
        ...(kind === "component"
          ? { name: entry.name, source: entry.source, exports: entry.exports }
          : { symbols: entry.symbols ?? [] }),
        matchReason: matched,
        capabilities: entry.capabilities ?? [],
      })),
  };
}

export async function docs(options = {}) {
  const { identity, catalog } = await current(options);
  const entry = [...catalog.entries, ...(catalog.components ?? [])].find(
    (e) => e.id === options.id,
  );
  if (!entry) fail("module_not_found", `Unknown public module: ${options.id}`);
  const section = options.section ?? "usage";
  const value = entry.sections[section];
  if (!value)
    fail(
      "section_unavailable",
      `Section ${section} is unavailable. Available: ${Object.keys(entry.sections).join(", ")}.`,
    );
  const offset = bounded(options.offset, 0, 10000000),
    limit = bounded(options.limit, 6000, 12000);
  return {
    ...binding(identity, catalog),
    id: entry.id,
    entrypoint: entry.entrypoint,
    lifecycle: lifecycleOf(entry, catalog.package.version),
    available: entry.available ?? entry.lifecycle?.state !== "removed",
    section,
    source: value.source,
    totalCharacters: value.content.length,
    content: value.content.slice(offset, offset + limit),
    offset,
    nextOffset:
      offset + limit < value.content.length && limit > 0
        ? offset + limit
        : null,
  };
}

export async function upgradePlan(options = {}) {
  if (!options.target)
    fail(
      "target_required",
      "--target must be an explicit @yueli/ui package directory or tarball, not a guessed release version.",
    );
  const identity = await inspect(options);
  if (!identity.resolved)
    fail("package_not_installed", "The current package is not installed.");
  if (identity.warnings.some((w) => w.includes("conflict")))
    fail(
      "identity_conflict",
      "Resolve current integrity conflicts before planning an upgrade.",
    );
  let catalog = null;
  try {
    catalog = await loadCatalog(identity.resolved.packageRoot);
  } catch (error) {
    if (error.code !== "catalog_unavailable") throw error;
  }
  const targetRoot = await realpath(resolve(options.target));
  const artifact = (await stat(targetRoot)).isFile()
    ? await readArtifact(targetRoot)
    : null;
  const target = await loadCatalog(targetRoot, artifact);
  const from = catalog?.package.version ?? identity.resolved.version,
    to = target.package.version;
  if (!semver.valid(from) || !semver.valid(to))
    fail("invalid_version", "Both package versions must be SemVer.");
  let decision = "review-required";
  if (!catalog) decision = "manual-baseline-required";
  else if (from === to)
    decision =
      catalog.contentSha256 === target.contentSha256
        ? "no-change"
        : "integrity-conflict";
  else if (semver.gt(from, to)) decision = "downgrade-review";
  if (
    catalog &&
    decision !== "integrity-conflict" &&
    (identity.sourceOverrides.length ||
      identity.runtimeResolution === "unknown")
  )
    decision = "baseline-required";
  const changes = [];
  for (const entry of catalog?.entries ?? []) {
    const next = target.entries.find((e) => e.id === entry.id);
    if (!next) changes.push({ id: entry.id, kind: "removed", breaking: true });
    else {
      if (entry.entrypoint !== next.entrypoint)
        changes.push({
          id: entry.id,
          kind: "entrypoint-changed",
          breaking: true,
          from: entry.entrypoint,
          to: next.entrypoint,
        });
      if (JSON.stringify(entry.api) !== JSON.stringify(next.api))
        changes.push({
          id: entry.id,
          kind: "api-changed",
          breaking: "review",
          migration: next.sections.migration?.content ?? null,
        });
      if (
        JSON.stringify(entry.capabilities) !== JSON.stringify(next.capabilities)
      )
        changes.push({
          id: entry.id,
          kind: "capabilities-changed",
          capabilities: next.capabilities,
        });
    }
  }
  for (const entry of target.entries)
    if (catalog && !catalog.entries.some((e) => e.id === entry.id))
      changes.push({ id: entry.id, kind: "added", breaking: false });
  for (const [kind, previous, following] of [
    ["lifecycle-changed", catalog?.entries ?? [], target.entries],
    [
      "component-lifecycle-changed",
      catalog?.components ?? [],
      target.components ?? [],
    ],
  ]) {
    for (const entry of previous) {
      const next = following.find((e) => e.id === entry.id);
      if (!next) continue;
      const before = lifecycleOf(entry, from),
        after = lifecycleOf(next, to);
      if (JSON.stringify(before) !== JSON.stringify(after))
        changes.push({
          id: entry.id,
          kind,
          from: before.state,
          to: after.state,
          lifecycle: after,
          breaking: after.state === "removed",
          migration: after.migration,
        });
    }
  }
  const peers = target.package.peerDependencies ?? {};
  const consumer = await json(resolve(identity.project, "package.json"));
  const dependencyChecks = Object.entries(peers).map(
    ([dependency, required]) => {
      const declared =
        consumer.dependencies?.[dependency] ??
        consumer.devDependencies?.[dependency] ??
        null;
      let status = "unknown";
      if (
        declared &&
        semver.validRange(declared) &&
        semver.validRange(required)
      )
        status = semver.subset(declared, required)
          ? "range-compatible"
          : "review-required";
      return { dependency, required, declared, status };
    },
  );
  return {
    dryRun: true,
    decision,
    current: catalog
      ? binding(identity, catalog)
      : {
          package: { name, version: from },
          verification: identity.resolved.verification,
          warnings: identity.warnings,
          catalogAvailable: false,
        },
    target: {
      name: target.package.name,
      version: target.package.version,
      packageRoot: targetRoot,
      contentSha256: target.contentSha256,
      verification: artifact ? "local-tarball" : "candidate-directory",
      artifactSha256: artifact?.sha256 ?? null,
    },
    versionChange: semver.diff(from, to),
    channelChange:
      Boolean(semver.prerelease(from)) !== Boolean(semver.prerelease(to)),
    changes,
    comparisonsAvailable: Boolean(catalog),
    dependencyChecks,
    proposedActions:
      decision === "no-change"
        ? []
        : [
            "Resolve current source/runtime overrides and select a fixed artifact baseline.",
            "Review API differences and required product adaptations before changing dependencies.",
            "Obtain an explicit target tarball and verify its release manifest checksum; a directory is not a released artifact.",
          ],
    checks: [
      "frozen-install",
      "typecheck",
      "independent-tarball-consumer",
      "product Playwright for affected UI",
    ],
    applied: false,
  };
}

export async function query(command, options) {
  const handlers = { inspect, search, docs, "upgrade-plan": upgradePlan };
  if (!Object.hasOwn(handlers, command))
    fail("unknown_command", `Unknown command: ${command}`);
  return handlers[command](options);
}
