#!/usr/bin/env node
import { parseArgs } from "node:util";
import { query } from "./query.mjs";

try {
  const { values, positionals } = parseArgs({
    allowPositionals: true,
    options: {
      project: { type: "string" },
      target: { type: "string" },
      json: { type: "boolean" },
      section: { type: "string" },
      kind: { type: "string" },
      lifecycle: { type: "string" },
      capability: { type: "string" },
      limit: { type: "string" },
      offset: { type: "string" },
      help: { type: "boolean" },
    },
  });
  const [command, ...args] = positionals;
  if (values.help || !command) {
    console.log(
      "yueli-ui inspect|search <intent>|docs <module-id>|upgrade-plan --project <package-directory> [--target <package-directory>] [--section api] [--kind module|component] [--lifecycle active|deprecated|removed|all] [--capability <id>] [--limit N] [--offset N] [--json]\nyueli-ui mcp  # read-only stdio MCP adapter",
    );
  } else if (command === "mcp") {
    const { serve } = await import("./mcp.mjs");
    await serve();
  } else {
    const result = await query(command, {
      ...values,
      query: args.join(" "),
      id: args[0],
    });
    console.log(JSON.stringify(result, null, values.json ? 0 : 2));
  }
} catch (error) {
  console.error(
    JSON.stringify({
      error: { code: error.code ?? "query_failed", message: error.message },
    }),
  );
  process.exitCode = 1;
}
