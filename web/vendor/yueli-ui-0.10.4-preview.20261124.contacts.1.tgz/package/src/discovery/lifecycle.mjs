import semver from "semver";

export function lifecycleOf(entry, version) {
  const state =
    entry.lifecycle?.state ??
    (entry.status === "deprecated" || entry.status === "removed"
      ? entry.status
      : "active");
  const plannedRemovalVersion = entry.removalVersion ?? null;
  return {
    state,
    recommendation:
      state === "active"
        ? "use"
        : state === "deprecated"
          ? "migrate"
          : "do-not-import",
    reason: entry.lifecycle?.reason ?? null,
    deprecatedIn: entry.lifecycle?.deprecatedIn ?? null,
    removedIn: entry.lifecycle?.removedIn ?? null,
    replacement:
      entry.lifecycle?.replacement ??
      (entry.replacement ? { entrypoint: entry.replacement } : null),
    migration: entry.lifecycle?.migration ?? null,
    plannedRemovalVersion,
    removalOverdue: Boolean(
      plannedRemovalVersion &&
      semver.valid(plannedRemovalVersion) &&
      semver.valid(version) &&
      semver.gte(version, plannedRemovalVersion),
    ),
  };
}

export function validateLifecycle(lifecycle, available) {
  if (!["active", "deprecated", "removed"].includes(lifecycle.state))
    throw new Error("Invalid lifecycle state.");
  if (lifecycle.state !== "active" && !lifecycle.reason)
    throw new Error("Inactive entries require a reason.");
  for (const field of ["deprecatedIn", "removedIn", "plannedRemovalVersion"])
    if (lifecycle[field] && !semver.valid(lifecycle[field]))
      throw new Error(`Invalid lifecycle SemVer: ${field}`);
  if (lifecycle.state === "removed" && (available || !lifecycle.removedIn))
    throw new Error(
      "Removed entries must have a removal version and no live export.",
    );
  if (lifecycle.state !== "removed" && !available)
    throw new Error("Active/deprecated entries require a live public export.");
}
