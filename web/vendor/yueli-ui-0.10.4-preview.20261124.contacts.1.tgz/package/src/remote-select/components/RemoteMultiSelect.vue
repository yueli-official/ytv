<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, ref, watch } from "vue";
import { mergeRemoteSelectPage } from "../page";
import type { SelectMenuProps } from "@nuxt/ui";
import UButton from "@nuxt/ui/components/Button.vue";
import CollectionMultiSelect from "../../collection/components/CollectionMultiSelect.vue";
import type { CollectionMultiSelectMessages } from "../../collection/multi-select";
import type {
  RemoteSelectLoader,
  RemoteSelectOption,
  RemoteSelectValue,
} from "../types";

const props = withDefaults(
  defineProps<{
    load: RemoteSelectLoader;
    messages: CollectionMultiSelectMessages & {
      loading: string;
      error: string;
      retry: string;
      minimumQuery: (count: number) => string;
    };
    pagination?: { loadMore: string; loadingMore: string };
    label: string;
    placeholder: string;
    initialItems?: readonly RemoteSelectOption[];
    debounceMs?: number;
    minimumQueryLength?: number;
    cache?: boolean;
    disabled?: boolean;
    visibleLimit?: number;
    size?: SelectMenuProps["size"];
    ui?: SelectMenuProps["ui"];
  }>(),
  {
    initialItems: () => [],
    debounceMs: 250,
    minimumQueryLength: 0,
    cache: true,
    disabled: false,
    visibleLimit: 2,
  },
);
const model = defineModel<RemoteSelectValue[]>({ default: () => [] });
const emit = defineEmits<{ loadError: [error: unknown] }>();
const selection = ref<{focusSearch: () => void} | null>(null);
const nextCursor = ref<string>();
const loadingMore = ref(false);
const pageFailed = ref(false);
let requestedCursors = new Set<string>();
const searchTerm = ref("");
const open = ref(false);
const composing = ref(false);
const loading = ref(false);
const failed = ref(false);
const items = ref<RemoteSelectOption[]>([]);
const remembered = ref<RemoteSelectOption[]>([]);
const resultCache = new Map<string, {items: RemoteSelectOption[]; cursor?: string}>();
const query = computed(() => searchTerm.value.trim());
const tooShort = computed(() => query.value.length < props.minimumQueryLength);
let timer: ReturnType<typeof setTimeout> | undefined;
let controller: AbortController | undefined;
let sequence = 0;
function cancel() {
  if (timer !== undefined) clearTimeout(timer);
  timer = undefined;
  controller?.abort();
  controller = undefined;
  sequence++;
  loading.value = false;
  loadingMore.value = false;
}
function retain() {
  const merged = new Map<RemoteSelectValue, RemoteSelectOption>();
  for (const item of [
    ...props.initialItems,
    ...remembered.value,
    ...items.value,
  ])
    merged.set(item.value, item);
  remembered.value = model.value.flatMap((value) =>
    merged.has(value) ? [merged.get(value)!] : [],
  );
}
watch([model, items, () => props.initialItems], retain, {
  immediate: true,
  deep: true,
});
async function run(force = false) {
  cancel();
  failed.value = false;
  pageFailed.value = false;
  nextCursor.value = undefined;
  requestedCursors = new Set();
  if (!open.value || props.disabled || tooShort.value) {
    items.value = [];
    return;
  }
  const key = query.value;
  if (props.cache && !force && resultCache.has(key)) {
    const saved=resultCache.get(key)!;
    items.value = [...saved.items];
    nextCursor.value = saved.cursor;
    return;
  }
  const current = sequence;
  const request = new AbortController();
  controller = request;
  loading.value = true;
  items.value = [];
  try {
    const result = await props.load({ query: key, signal: request.signal });
    if (request.signal.aborted || current !== sequence) return;
    const page=mergeRemoteSelectPage([],props.pagination ? result : {items:result.items},requestedCursors);
    items.value = page.items;
    nextCursor.value = page.cursor;
    if (props.cache) {
      resultCache.delete(key);
      resultCache.set(key, {items:[...items.value],cursor:nextCursor.value});
      if (resultCache.size > 50)
        resultCache.delete(resultCache.keys().next().value!);
    }
  } catch (error) {
    if (request.signal.aborted || current !== sequence) return;
    failed.value = true;
    emit("loadError", error);
  } finally {
    if (current === sequence) {
      loading.value = false;
      controller = undefined;
    }
  }
}
async function loadMore() {
  if (!props.pagination || !open.value || props.disabled || composing.value || loading.value || loadingMore.value || !nextCursor.value) return;
  const cursor=nextCursor.value, key=query.value, current=sequence;
  const request=new AbortController(); controller=request; loadingMore.value=true; pageFailed.value=false;
  try {
    const result=await props.load({query:key,cursor,signal:request.signal});
    if(request.signal.aborted || current!==sequence) return;
    const requested=new Set([...requestedCursors,cursor]);
    const page=mergeRemoteSelectPage(items.value,result,requested);
    items.value=page.items; nextCursor.value=page.cursor; requestedCursors=requested;
    if(!page.cursor) { await nextTick(); if(open.value && current===sequence) selection.value?.focusSearch(); }
  } catch(error) {
    if(request.signal.aborted || current!==sequence) return;
    pageFailed.value=true; emit("loadError",error);
  } finally {
    if(current===sequence) {loadingMore.value=false; controller=undefined;}
  }
}
function schedule() {
  cancel();
  failed.value = false;
  pageFailed.value = false;
  nextCursor.value = undefined;
  items.value = [];
  if (!open.value || composing.value || props.disabled || tooShort.value)
    return;
  loading.value = true;
  timer = setTimeout(() => void run(), Math.max(0, props.debounceMs));
}
function composition(active: boolean) {
  composing.value = active;
  schedule();
}
function setOpen(value: boolean) {
  open.value = value;
  schedule();
}
function refresh() {
  resultCache.clear();
  schedule();
}
watch(searchTerm, schedule);
watch(() => [props.load, props.minimumQueryLength, props.cache], refresh);
watch(() => !!props.pagination, refresh);
watch(() => props.disabled, schedule);
onBeforeUnmount(cancel);
defineExpose({ refresh });
</script>
<template>
  <CollectionMultiSelect
    ref="selection"
    v-model="model"
    v-model:search-term="searchTerm"
    :options="items"
    :selected-options="remembered"
    :messages="messages"
    :label="label"
    :placeholder="placeholder"
    :disabled="disabled"
    :visible-limit="visibleLimit"
    :size="size"
    :ui="ui"
    :loading="loading"
    ignore-filter
    :selected-first="false"
    @open="setOpen"
    @search-composition="composition"
  >
    <template #content-bottom>
      <div v-if="pagination && nextCursor && !loading" class="border-t border-default p-2" data-remote-pagination>
        <p v-if="pageFailed" role="alert" class="mb-2 text-xs text-error">{{ messages.error }}</p>
        <UButton :label="loadingMore ? pagination.loadingMore : pageFailed ? messages.retry : pagination.loadMore" :loading="loadingMore" :disabled="disabled || loadingMore" color="neutral" variant="ghost" :size="size" class="w-full" @keydown.enter.stop @keydown.space.stop @click="loadMore" />
      </div>
    </template>
    <template #empty>
      <div
        class="flex items-center justify-between gap-3"
        role="status"
        aria-live="polite"
      >
        <span :class="failed ? 'text-error' : 'text-muted'">{{
          failed
            ? messages.error
            : tooShort
              ? messages.minimumQuery(minimumQueryLength)
              : loading
                ? messages.loading
                : messages.empty
        }}</span>
        <UButton
          v-if="failed"
          :label="messages.retry"
          color="neutral"
          variant="ghost"
          :size="size"
          @click="run(true)"
        />
      </div>
    </template>
  </CollectionMultiSelect>
</template>
