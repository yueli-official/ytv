import type {RemoteSelectOption,RemoteSelectLoadResult} from "./types";
export function mergeRemoteSelectPage(previous: readonly RemoteSelectOption[], result: RemoteSelectLoadResult, requested: ReadonlySet<string>) {
 const cursor=result.nextCursor ?? undefined;
 if(cursor !== undefined && (!cursor.trim() || requested.has(cursor))) throw new Error("Invalid or repeated pagination cursor");
 return {items:[...new Map([...previous,...result.items].map(item=>[item.value,{...item}])).values()],cursor};
}
