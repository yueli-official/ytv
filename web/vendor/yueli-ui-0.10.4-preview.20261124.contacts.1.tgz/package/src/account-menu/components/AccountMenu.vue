<script setup lang="ts">
import type { ButtonProps, DropdownMenuItem } from "@nuxt/ui";
import { computed, onBeforeUnmount, onMounted, ref } from "vue";

export interface AccountMenuAction {
  readonly label: string;
  readonly icon?: string;
  readonly to?: string;
  readonly description?: string;
  readonly disabled?: boolean;
  readonly onSelect?: (event?: Event) => void | Promise<void>;
}

export interface AccountMenuMessages {
  readonly currentUser: string;
  readonly logout: string;
  readonly openMenu: (displayName: string) => string;
}

export type AccountMenuAppearanceValue = "system" | "light" | "dark";

export interface AccountMenuAppearanceMessages {
  readonly label: string;
  readonly system: string;
  readonly light: string;
  readonly dark: string;
}

export interface AccountMenuAppearance {
  readonly value: AccountMenuAppearanceValue;
  readonly messages: AccountMenuAppearanceMessages;
  readonly onChange: (
    value: AccountMenuAppearanceValue,
  ) => unknown | Promise<unknown>;
}

export type AccountMenuTriggerMode = "inline" | "sidebar" | "collapsed";

const props = withDefaults(
  defineProps<{
    name?: string;
    size?: ButtonProps["size"];
    email?: string;
    avatarUrl?: string;
    contextActions?: readonly AccountMenuAction[];
    utilityActions?: readonly AccountMenuAction[];
    appearance?: AccountMenuAppearance;
    triggerMode?: AccountMenuTriggerMode;
    logout: () => unknown | Promise<unknown>;
    messages: AccountMenuMessages;
  }>(),
  {
    name: "",
    email: "",
    avatarUrl: "",
    contextActions: () => [],
    utilityActions: () => [],
    appearance: undefined,
    triggerMode: "inline",
  },
);

const displayName = computed(
  () => props.name || props.email || props.messages.currentUser,
);
const initial = computed(() => displayName.value.charAt(0).toLocaleUpperCase());
const narrowViewport = ref(false);
let viewportQuery: MediaQueryList | undefined;

function updateViewportMatch(event: MediaQueryList | MediaQueryListEvent) {
  narrowViewport.value = event.matches;
}

onMounted(() => {
  viewportQuery = window.matchMedia("(max-width: 1023px)");
  updateViewportMatch(viewportQuery);
  viewportQuery.addEventListener("change", updateViewportMatch);
});

onBeforeUnmount(() => {
  viewportQuery?.removeEventListener("change", updateViewportMatch);
});

const menuItems = computed(() => {
  const groups: DropdownMenuItem[][] = [
    [
      {
        label: displayName.value,
        description: props.name && props.email ? props.email : undefined,
        avatar: {
          src: props.avatarUrl || undefined,
          text: initial.value,
          alt: displayName.value,
          size: "sm",
        },
        type: "label" as const,
      },
    ],
  ];

  if (props.contextActions.length)
    groups.push(props.contextActions.map((action) => ({ ...action })));

  const utilityItems: DropdownMenuItem[] = props.utilityActions.map(
    (action) => ({ ...action }),
  );
  if (props.appearance) {
    const appearance = props.appearance;
    const options: ReadonlyArray<{
      value: AccountMenuAppearanceValue;
      label: string;
      icon: string;
    }> = [
      {
        value: "system",
        label: appearance.messages.system,
        icon: "i-tabler-device-desktop",
      },
      {
        value: "light",
        label: appearance.messages.light,
        icon: "i-tabler-sun",
      },
      {
        value: "dark",
        label: appearance.messages.dark,
        icon: "i-tabler-moon",
      },
    ];
    utilityItems.push({
      label: appearance.messages.label,
      icon: "i-tabler-sun-moon",
      children: options.map((option) => ({
        label: option.label,
        icon: option.icon,
        type: "checkbox" as const,
        checked: appearance.value === option.value,
        onSelect: async (event?: Event) => {
          event?.preventDefault();
          await appearance.onChange(option.value);
        },
      })),
    });
  }
  if (utilityItems.length) groups.push(utilityItems);

  groups.push([
    {
      label: props.messages.logout,
      icon: "i-tabler-logout",
      onSelect: async () => {
        await props.logout();
      },
    },
  ]);
  return groups;
});

const menuContent = computed(() => ({
  align: "end" as const,
  side:
    props.triggerMode === "inline" || narrowViewport.value
      ? ("bottom" as const)
      : ("right" as const),
  sideOffset: 4,
  collisionPadding: 12,
}));

const menuUi = computed(() => ({
  content: [
    "yueli-account-menu-surface z-[110] min-w-56 rounded-xl border border-default bg-[var(--yueli-surface-overlay)] p-1 shadow-lg",
    props.triggerMode === "sidebar"
      ? "w-(--reka-dropdown-menu-trigger-width)"
      : "w-56",
  ],
  group: "p-0.5",
  label: "normal-case",
  item: "rounded-lg",
  itemWrapper: "min-w-0",
  itemLabel: "truncate",
  itemDescription: "truncate text-xs",
}));
</script>

<template>
  <UDropdownMenu
    :items="menuItems"
    :size="size"
    :content="menuContent"
    :ui="menuUi"
  >
    <UButton
      type="button"
      color="neutral"
      variant="ghost"
      :size="size"
      :trailing-icon="
        triggerMode === 'sidebar'
          ? 'i-tabler-selector'
          : triggerMode === 'inline'
            ? 'i-tabler-chevron-down'
            : undefined
      "
      :ui="{
        trailingIcon:
          triggerMode === 'inline' ? 'hidden sm:block' : 'ms-auto text-muted',
      }"
      :block="triggerMode === 'sidebar'"
      :square="triggerMode === 'collapsed'"
      :class="[
        'data-[state=open]:bg-elevated data-[state=open]:text-highlighted',
        triggerMode === 'sidebar' && 'w-full justify-start',
        triggerMode === 'collapsed' && 'justify-center',
      ]"
      :aria-label="messages.openMenu(displayName)"
      aria-haspopup="menu"
      data-account-menu-trigger
    >
      <UAvatar
        :src="avatarUrl || undefined"
        :text="initial"
        :alt="displayName"
        :size="triggerMode === 'sidebar' ? 'sm' : 'xs'"
        class="shrink-0"
      />
      <span
        v-if="triggerMode !== 'collapsed'"
        :class="[
          'grid min-w-0 text-start',
          triggerMode === 'sidebar' ? 'flex-1' : 'max-w-36',
          triggerMode === 'inline' && 'hidden sm:grid',
        ]"
      >
        <span class="truncate font-medium text-highlighted">
          {{ displayName }}
        </span>
        <span
          v-if="triggerMode === 'sidebar' && name && email"
          class="truncate text-xs font-normal text-muted"
        >
          {{ email }}
        </span>
      </span>
    </UButton>
  </UDropdownMenu>
</template>

<style>
.yueli-account-menu-surface {
  z-index: 110;
  isolation: isolate;
  opacity: 1 !important;
  background-color: var(--yueli-surface-overlay) !important;
}
</style>
