<script setup lang="ts">
import type { SiteLauncherIconKind } from "../site-directory";

defineProps<{ kind: SiteLauncherIconKind }>();

const icons: Record<SiteLauncherIconKind, string> = {
  home: "i-tabler-home-2",
  book: "i-tabler-book",
  package: "i-tabler-package",
  code: "i-tabler-code",
  tv: "i-tabler-device-tv",
  account: "i-tabler-user-circle",
  gallery: "i-tabler-photo",
  blog: "i-tabler-article",
  compass: "i-tabler-compass",
};
</script>

<template>
  <span class="site-launcher-icon grid size-10 shrink-0 place-items-center rounded-xl" :data-kind="kind" aria-hidden="true">
    <UIcon :name="icons[kind]" class="size-5" />
  </span>
</template>

<style scoped>
.site-launcher-icon {
  color: var(--y-site-launcher-icon-color);
  background: color-mix(in srgb, var(--y-site-launcher-icon-color) 12%, white);
}
[data-kind="home"] { --y-site-launcher-icon-color: var(--y-site-launcher-home); }
[data-kind="book"] { --y-site-launcher-icon-color: var(--y-site-launcher-book); }
[data-kind="package"] { --y-site-launcher-icon-color: var(--y-site-launcher-package); }
[data-kind="code"] { --y-site-launcher-icon-color: var(--y-site-launcher-code); }
[data-kind="tv"] { --y-site-launcher-icon-color: var(--y-site-launcher-tv); }
[data-kind="account"] { --y-site-launcher-icon-color: var(--y-site-launcher-account); }
[data-kind="gallery"] { --y-site-launcher-icon-color: var(--y-site-launcher-gallery); }
[data-kind="blog"] { --y-site-launcher-icon-color: var(--y-site-launcher-blog); }
[data-kind="compass"] { --y-site-launcher-icon-color: var(--y-site-launcher-compass); }
</style>
