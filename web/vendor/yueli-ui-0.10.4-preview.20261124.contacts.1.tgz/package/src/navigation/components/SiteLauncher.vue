<script setup lang="ts">
import { ref } from "vue";
import SiteLauncherIcon from "./SiteLauncherIcon.vue";
import { yueliContactLinks, yueliSites, type SiteLauncherItem } from "../site-directory";

withDefaults(defineProps<{ items?: readonly SiteLauncherItem[]; label?: string }>(), {
  items: () => yueliSites,
  label: "月离网站",
});
const open = ref(false);
</script>

<template>
  <UPopover
    v-model:open="open"
    :content="{ align: 'end', side: 'bottom', sideOffset: 8 }"
    :ui="{
      content: 'max-w-[calc(100vw-2rem)] rounded-2xl border border-[var(--y-site-launcher-border)] bg-[var(--y-site-launcher-surface)] p-0 shadow-xl',
    }"
  >
    <UTooltip :text="label"
      ><UButton
        icon="i-tabler-grid-dots"
        :aria-label="label"
        color="neutral"
        variant="ghost"
        class="rounded-full"
    /></UTooltip>
    <template #content>
      <section
        data-site-launcher
        class="w-[19.5rem] max-w-[calc(100vw-2rem-2px)] max-h-[var(--reka-popper-available-height)] overflow-y-auto overscroll-contain px-3 pb-3 pt-3"
        :aria-label="label"
      >
        <h2
          class="px-2 pb-2 pt-1 text-sm font-semibold text-[var(--y-site-launcher-ink)]"
        >
          {{ label }}
        </h2>
        <div
          class="grid grid-cols-3 gap-1"
        >
          <a
            v-for="item in items"
            :key="item.id"
            :href="item.url"
            target="_blank"
            rel="noopener noreferrer"
            :aria-label="item.name"
            class="flex min-w-0 flex-col items-center gap-2 rounded-xl px-1 py-2.5 text-center transition-colors hover:bg-[var(--y-site-launcher-hover)] focus-visible:bg-[var(--y-site-launcher-hover)] focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-[var(--y-site-launcher-focus)]"
          >
            <img v-if="item.iconUrl !== undefined" :src="item.iconUrl" alt="" class="size-10 shrink-0 object-contain" />
            <SiteLauncherIcon v-else :kind="item.icon" />
            <span
              class="line-clamp-2 w-full break-words text-xs font-medium text-[var(--y-site-launcher-ink)]"
              >{{ item.name }}</span
            >
          </a>
        </div>
        <nav
          v-if="items === yueliSites"
          aria-label="联系方式"
          class="mt-2 border-t border-[var(--y-site-launcher-border)] pt-2"
        >
          <h3 class="px-2 text-xs font-medium text-[var(--y-site-launcher-ink)]">联系方式</h3>
          <div class="mt-1 grid grid-cols-3 gap-1">
            <a
              v-for="contact in yueliContactLinks"
              :key="contact.name"
              :href="contact.url"
              target="_blank"
              rel="noopener noreferrer"
              class="flex min-h-11 min-w-0 items-center justify-center gap-1.5 rounded-lg px-1 text-xs text-[var(--y-site-launcher-ink)] transition-colors hover:bg-[var(--y-site-launcher-hover)] focus-visible:bg-[var(--y-site-launcher-hover)] focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-[var(--y-site-launcher-focus)]"
            >
              <UIcon :name="contact.icon" class="size-4 shrink-0" aria-hidden="true" />
              <span>{{ contact.name }}</span>
            </a>
          </div>
        </nav>
      </section>
    </template>
  </UPopover>
</template>
