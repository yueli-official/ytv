import navIconUrl from "./assets/nav-favicon.svg?no-inline";

export type SiteLauncherIconKind =
  | "home" | "book" | "package" | "code" | "tv" | "account"
  | "gallery" | "blog" | "compass";

export type SiteLauncherItem = {
  id: string;
  name: string;
  url: string;
} & (
  | { iconUrl: string; icon?: never }
  | { icon: SiteLauncherIconKind; iconUrl?: never }
);

export const yueliSites = [
  { id: "www", name: "官网", url: "https://www.yuelili.com/", iconUrl: "https://www.yuelili.com/favicon.svg?v=20261124-brand" },
  { id: "docs", name: "文档", url: "https://docs.yuelili.com/", iconUrl: "https://docs.yuelili.com/favicon.svg" },
  { id: "apps", name: "软件", url: "https://apps.yuelili.com/", iconUrl: "https://apps.yuelili.com/favicon.svg" },
  { id: "paste", name: "代码分享", url: "https://paste.yuelili.com/", iconUrl: "https://paste.yuelili.com/favicon.svg" },
  { id: "tv", name: "影视", url: "https://tv.yuelili.com/", iconUrl: "https://tv.yuelili.com/favicon.svg" },
  { id: "account", name: "用户中心", url: "https://account.yuelili.com/", iconUrl: "https://account.yuelili.com/favicon.svg?v=20260929" },
  { id: "gallery", name: "图库", url: "https://gallery.yuelili.com/", iconUrl: "https://gallery.yuelili.com/favicon.svg?v=20261024-brand" },
  { id: "blog", name: "AE博客", url: "https://cg.yuelili.com/", iconUrl: "https://cg.yuelili.com/favicon.ico?v=20260929" },
  { id: "nav", name: "导航", url: "https://nav.yuelili.com/", iconUrl: navIconUrl },
] as const satisfies readonly SiteLauncherItem[];

export const yueliContactLinks = [
  { name: "QQ群", url: "https://qm.qq.com/q/lAuaWN1hKi", icon: "i-tabler-messages" },
  { name: "GitHub", url: "https://github.com/Yuelioi", icon: "i-tabler-brand-github" },
  { name: "哔哩哔哩", url: "https://space.bilibili.com/4279370", icon: "i-tabler-brand-bilibili" },
] as const;
