import { readdir, readFile } from "node:fs/promises";
import { resolve, relative } from "node:path";

const sharedStyles = new Set([
  "tailwindcss",
  "@nuxt/ui",
  "@yueli/ui/tailwind.css",
  "@yueli/ui/theme.css",
  "@yueli/asset-nuxt/tailwind.css",
  "@yueli/content-nuxt/article.css",
]);
const excluded = new Set([
  "node_modules",
  "vendor",
  ".git",
  ".nuxt",
  ".output",
  ".task",
  ".doctor",
  ".cache",
  ".turbo",
  "dist",
  "coverage",
  "test-results",
  "playwright-report",
  "flightdeck",
]);

// Read literal imports and CSS declarations without executing product config.
// Comments and quoted examples remain whole tokens, not executable-looking text.
function tokens(source) {
  const pattern =
    /\/\*[\s\S]*?\*\/|\/\/[^\r\n]*|<!--[\s\S]*?-->|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`|[A-Za-z_$][\w$-]*|[^\s]/g;
  return Array.from(source.matchAll(pattern), ([value]) => {
    if (/^(?:\/\*|\/\/|<!--)/.test(value)) return null;
    if (/^["'`]/.test(value))
      return {
        kind: "string",
        value: value.slice(1, -1).replace(/\\([\\"'`])/g, "$1"),
      };
    return { kind: "token", value };
  }).filter(Boolean);
}

function duplicates(source) {
  const parts = tokens(source);
  const literal = (index) =>
    parts[index]?.kind === "string" ? parts[index].value : null;
  for (let i = 0; i < parts.length; i++) {
    const word = parts[i];
    if (
      word.kind === "token" &&
      ["import", "from", "require"].includes(word.value)
    ) {
      const target =
        literal(i + 1) ??
        (parts[i + 1]?.value === "(" ? literal(i + 2) : null) ??
        (parts[i + 1]?.value === "url" && parts[i + 2]?.value === "("
          ? literal(i + 3)
          : null);
      if (
        sharedStyles.has(target) &&
        (parts[i - 1]?.value === "@" || target.endsWith(".css"))
      )
        return true;
    }
    if (parts[i - 1]?.value === "@" && word.kind === "token") {
      if (
        word.value === "plugin" &&
        literal(i + 1) === "@tailwindcss/typography"
      )
        return true;
      if (word.value === "source" && literal(i + 1)?.includes("@yueli/"))
        return true;
    }
    if (
      word.value === "css" &&
      parts[i + 1]?.value === ":" &&
      parts[i + 2]?.value === "["
    ) {
      let depth = 1;
      for (let j = i + 3; j < parts.length && depth; j++) {
        if (parts[j].kind === "string" && sharedStyles.has(parts[j].value))
          return true;
        if (parts[j].kind === "token" && parts[j].value === "[") depth++;
        if (parts[j].kind === "token" && parts[j].value === "]") depth--;
      }
    }
  }
  return false;
}

export async function verifyConsumerStyles(project, { cssEntries = [] } = {}) {
  project = resolve(project);
  const pending = [project];
  const violations = cssEntries.filter((entry) => sharedStyles.has(entry));
  while (pending.length) {
    const directory = pending.pop();
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      if (entry.isSymbolicLink()) continue;
      const file = resolve(directory, entry.name);
      if (entry.isDirectory()) {
        if (!excluded.has(entry.name)) pending.push(file);
      } else if (
        /\.(?:css|vue|[cm]?[jt]s)$/.test(entry.name) &&
        duplicates(await readFile(file, "utf8"))
      ) {
        violations.push(relative(project, file));
      }
    }
  }
  if (violations.length)
    throw new Error(
      `Component styles are installed by @yueli/ui; remove manual framework/shared CSS imports or internal sources: ${violations.join(", ")}`,
    );
}
