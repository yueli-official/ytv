<script setup lang="ts">
import { computed, ref, useId, watch } from "vue";

export interface AdminTrendPoint {
  readonly label: string;
  readonly axisLabel?: string;
  readonly value: number;
}

const props = withDefaults(
  defineProps<{
    points: readonly AdminTrendPoint[];
    compact?: boolean;
    metricLabel?: string;
    unit?: string;
    emptyLabel?: string;
    ariaLabel?: string;
  }>(),
  {
    compact: false,
    metricLabel: "数据",
    unit: "",
    emptyLabel: "当前周期还没有记录",
    ariaLabel: "",
  },
);

const width = 720;
const height = 200;
const formatter = new Intl.NumberFormat("zh-CN", {
  maximumSignificantDigits: 15,
});
const values = computed(() => props.points.map((point) => point.value));
const peak = computed(() => Math.max(...values.value));
const scale = computed(() => {
  const min = Math.min(0, ...values.value);
  const max = Math.max(0, peak.value) || (min === 0 ? 1 : 0);
  const roughStep = (max - min) / (props.compact ? 3 : 4);
  const magnitude = 10 ** Math.floor(Math.log10(roughStep));
  const interval = [1, 2, 2.5, 5, 10].find(
    (factor) => roughStep <= factor * magnitude,
  )!;
  const step = values.value.every(Number.isInteger)
    ? Math.max(1, Math.ceil(interval * magnitude))
    : interval * magnitude;
  const first = Math.floor(min / step);
  const last = Math.ceil(max / step);
  return {
    min: first * step,
    max: last * step,
    ticks: Array.from(
      { length: last - first + 1 },
      (_, index) => (last - index) * step,
    ),
  };
});

function positionY(value: number) {
  const { min, max } = scale.value;
  return height * ((max - value) / (max - min));
}

const coordinates = computed(() =>
  props.points.map((point, index) => ({
    ...point,
    x:
      props.points.length === 1
        ? width / 2
        : (index / (props.points.length - 1)) * width,
    y: positionY(point.value),
  })),
);
const linePath = computed(() =>
  coordinates.value
    .map((point, index) => `${index ? "L" : "M"} ${point.x} ${point.y}`)
    .join(" "),
);
const areaPath = computed(() => {
  if (!coordinates.value.length) return "";
  const first = coordinates.value[0]!;
  const last = coordinates.value.at(-1)!;
  const baseline = positionY(0);
  return `${linePath.value} L ${last.x} ${baseline} L ${first.x} ${baseline} Z`;
});
const axisLabels = computed(() => {
  if (!props.points.length) return [];
  const indexes = new Set([
    0,
    Math.floor((props.points.length - 1) / 2),
    props.points.length - 1,
  ]);
  return [...indexes]
    .sort((left, right) => left - right)
    .map((index) => coordinates.value[index]!);
});
const instructionsId = useId();
const activeIndex = ref<number>();
const activePoint = computed(() =>
  activeIndex.value === undefined
    ? undefined
    : coordinates.value[activeIndex.value],
);
const accessibleLabel = computed(
  () =>
    props.ariaLabel ||
    `${props.metricLabel}趋势，共 ${props.points.length} 个数据点，峰值 ${formatter.format(peak.value)}${props.unit}`,
);

watch(() => props.points, clearSelection);

function clearSelection() {
  activeIndex.value = undefined;
}

function onPointerLeave(event: PointerEvent) {
  if (event.pointerType !== "touch") clearSelection();
}

function onPointerMove(event: PointerEvent) {
  if (event.pointerType !== "touch") selectPoint(event);
}

function selectPoint(event: PointerEvent) {
  const plot = (event.currentTarget as HTMLElement).getBoundingClientRect();
  const offset = Math.max(
    0,
    Math.min(1, (event.clientX - plot.left) / plot.width),
  );
  activeIndex.value = Math.round(offset * (props.points.length - 1));
}

function onKeyDown(event: KeyboardEvent) {
  const last = props.points.length - 1;
  switch (event.key) {
    case "ArrowLeft":
      activeIndex.value = Math.max(0, (activeIndex.value ?? 1) - 1);
      break;
    case "ArrowRight":
      activeIndex.value = Math.min(last, (activeIndex.value ?? -1) + 1);
      break;
    case "Home":
      activeIndex.value = 0;
      break;
    case "End":
      activeIndex.value = last;
      break;
    case "Escape":
      clearSelection();
      return;
    default:
      return;
  }
  event.preventDefault();
}
</script>

<template>
  <figure data-trend-chart data-admin-trend-chart @pointerleave="onPointerLeave">
    <div v-if="points.length" class="space-y-2">
      <div
        class="flex min-h-6 items-center justify-between gap-2 text-xs tabular-nums"
      >
        <span class="text-muted">{{ unit }}</span>
        <span
          role="status"
          class="rounded px-2 py-1 text-highlighted"
          :class="{ 'bg-elevated': activePoint }"
        >
          <template v-if="activePoint">{{ activePoint.label }} · {{ formatter.format(activePoint.value) }}{{ unit }}</template>
        </span>
      </div>
      <div class="grid grid-cols-[auto_minmax(0,1fr)] gap-x-3 gap-y-2">
        <div aria-hidden="true" class="relative grid grid-cols-[max-content] items-start text-right text-xs tabular-nums text-muted">
          <span
            v-for="tick in scale.ticks"
            :key="tick"
            class="absolute right-0 -translate-y-1/2"
            :style="{ top: `${(positionY(tick) / height) * 100}%` }"
          >
            {{ formatter.format(tick) }}
          </span>
          <span
            v-for="tick in scale.ticks"
            :key="`measure-${tick}`"
            class="invisible col-start-1 row-start-1 whitespace-nowrap"
          >{{ formatter.format(tick) }}</span>
        </div>
        <div
          class="relative min-w-0 cursor-crosshair rounded-sm focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-primary"
          :class="compact ? 'h-28 sm:h-32' : 'h-52 sm:h-60'"
          role="group"
          tabindex="0"
          :aria-label="accessibleLabel"
          :aria-describedby="instructionsId"
          @pointermove="onPointerMove"
          @pointerdown="selectPoint"
          @pointercancel="clearSelection"
          @blur="clearSelection"
          @keydown="onKeyDown"
        >
          <svg
            class="block size-full overflow-visible"
            :viewBox.attr="`0 0 ${width} ${height}`"
            preserveAspectRatio="none"
            role="img"
            :aria-label="accessibleLabel"
          >
            <path
              v-for="tick in scale.ticks"
              :key="tick"
              :d="`M 0 ${positionY(tick)} H ${width}`"
              class="stroke-default"
              fill="none"
              vector-effect="non-scaling-stroke"
            />
            <path
              :d="`M 0 0 V ${height} H ${width}`"
              class="stroke-current text-muted opacity-60"
              fill="none"
              vector-effect="non-scaling-stroke"
            />
            <path :d="areaPath" class="fill-primary/10" />
            <path
              :d="linePath"
              fill="none"
              class="stroke-primary"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
              vector-effect="non-scaling-stroke"
            />
            <path
              v-if="activePoint"
              :d="`M ${activePoint.x} 0 V ${height}`"
              class="stroke-primary/70"
              fill="none"
              stroke-dasharray="3 3"
              vector-effect="non-scaling-stroke"
            />
          </svg>
          <span
            v-for="(point, index) in coordinates"
            v-show="points.length <= 14 || activeIndex === index"
            :key="index"
            aria-hidden="true"
            class="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 rounded-full border border-primary"
            :class="activeIndex === index ? 'size-3 bg-primary ring-2 ring-default' : 'size-1.5 bg-default'"
            :style="{
              left: `${(point.x / width) * 100}%`,
              top: `${(point.y / height) * 100}%`,
            }"
          />
        </div>
        <div
          aria-hidden="true"
          class="relative col-start-2 h-5 text-xs tabular-nums text-muted"
        >
          <span
            v-for="(point, index) in axisLabels"
            :key="index"
            class="absolute truncate"
            :class="{
              'max-w-full': axisLabels.length === 1,
              'max-w-[33%]': axisLabels.length > 1,
              '-translate-x-1/2': point.x > 0 && point.x < width,
              '-translate-x-full': point.x === width,
            }"
            :style="{ left: `${(point.x / width) * 100}%` }"
          >{{ point.axisLabel ?? point.label }}</span>
        </div>
      </div>
      <span :id="instructionsId" class="sr-only">
        使用左右方向键查看各数据点，Home 和 End 跳到首尾。
      </span>
    </div>
    <div
      v-else
      class="grid place-items-center text-sm text-muted"
      :class="compact ? 'h-28 sm:h-32' : 'h-52 sm:h-60'"
    >
      {{ emptyLabel }}
    </div>
    <figcaption class="sr-only">
      <span v-for="point in points" :key="point.label">
        {{ point.label }}：{{ point.value }}{{ unit }}。
      </span>
    </figcaption>
  </figure>
</template>
