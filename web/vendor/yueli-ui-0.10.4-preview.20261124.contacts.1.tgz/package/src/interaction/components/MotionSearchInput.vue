<script setup lang="ts">
import { ref, watch, nextTick, onBeforeUnmount } from "vue";
import type { InputProps } from "@nuxt/ui";
defineOptions({ inheritAttrs: false });
const props = withDefaults(
  defineProps<{
    label: string;
    clearLabel: string;
    placeholder?: string;
    debounceMs?: number;
    loading?: boolean;
    disabled?: boolean;
    readonly?: boolean;
    motion?: boolean;
    size?: InputProps["size"];
    ui?: InputProps["ui"];
  }>(),
  { debounceMs: 300, motion: true },
);
const value = defineModel<string>({ default: "" });
const emit = defineEmits<{ search: [query: string] }>();
const input = ref<{ inputRef: HTMLInputElement }>();
const draft = ref(value.value);
let composing = false;
let timer: ReturnType<typeof setTimeout> | undefined;
let lastQuery = value.value.trim();
function cancel() {
  clearTimeout(timer);
  timer = undefined;
}
function submit(event?: KeyboardEvent, explicit = true) {
  if (
    composing ||
    event?.isComposing ||
    event?.keyCode === 229 ||
    props.disabled ||
    props.readonly
  )
    return;
  event?.preventDefault();
  cancel();
  const query = draft.value.trim();
  if (explicit || query !== lastQuery) {
    lastQuery = query;
    emit("search", query);
  }
}
function update(raw: unknown) {
  const text = String(raw ?? "");
  draft.value = text;
  if (composing || props.disabled || props.readonly || value.value === text)
    return;
  value.value = text;
  cancel();
  timer = setTimeout(
    () => submit(undefined, false),
    Math.max(0, props.debounceMs),
  );
}
function startComposition() {
  composing = true;
  cancel();
}
function finishComposition(event: CompositionEvent) {
  composing = false;
  update((event.target as HTMLInputElement).value);
}
async function clear() {
  if (props.disabled || props.readonly) return;
  composing = false;
  cancel();
  draft.value = value.value = "";
  submit();
  await nextTick();
  input.value?.inputRef?.focus({ preventScroll: true });
}
watch(
  value,
  (text) => {
    if (text === draft.value) return;
    cancel();
    if (!composing) draft.value = text;
  },
  { flush: "sync" },
);
watch(
  () => [props.disabled, props.readonly],
  () => {
    if (props.disabled || props.readonly) cancel();
  },
);
onBeforeUnmount(cancel);
defineExpose({ focus: () => input.value?.inputRef?.focus() });
</script>
<template>
  <UInput
    ref="input"
    v-bind="$attrs"
    :model-value="draft"
    :aria-label="label"
    :aria-busy="loading || undefined"
    :placeholder="placeholder"
    :size="size"
    :ui="ui"
    :loading="loading"
    :disabled="disabled"
    :readonly="readonly"
    icon="i-tabler-search"
    loading-icon="i-tabler-loader-2"
    class="motion-search w-full min-w-0"
    :data-motion="motion"
    @update:model-value="update"
    @compositionstart="startComposition"
    @compositionend="finishComposition"
    @keydown.enter="submit($event)"
  >
    <template #trailing>
      <Transition
        :name="motion ? 'search-clear' : undefined"
        @before-leave="(element) => element.setAttribute('inert', '')"
        @before-enter="(element) => element.removeAttribute('inert')"
      >
        <UTooltip v-if="draft && !disabled && !readonly" :text="clearLabel">
          <UButton
            :aria-label="clearLabel"
            :size="size"
            type="button"
            icon="i-tabler-x"
            color="neutral"
            variant="ghost"
            class="inline-flex items-center justify-center"
            @click="clear"
          />
        </UTooltip>
      </Transition>
    </template>
  </UInput>
</template>
<style scoped>
.search-clear-enter-active,
.search-clear-leave-active {
  transition: opacity 150ms ease-out;
}
.search-clear-enter-from,
.search-clear-leave-to {
  opacity: 0;
}
@media (prefers-reduced-motion: reduce) {
  .search-clear-enter-active,
  .search-clear-leave-active {
    transition: none;
  }
  .motion-search :deep([data-slot="leadingIcon"]) {
    animation: none;
  }
}
</style>
