<script setup lang="ts">
import { ref, watch, useId, nextTick } from "vue";
import type { ButtonProps, CollapsibleProps } from "@nuxt/ui";
const props = withDefaults(
  defineProps<{
    label: string;
    disabled?: boolean;
    invalid?: boolean;
    motion?: boolean;
    size?: ButtonProps["size"];
    ui?: CollapsibleProps["ui"];
    buttonUi?: ButtonProps["ui"];
  }>(),
  { motion: true },
);
const open = defineModel<boolean>("open", { default: false });
const root = ref<HTMLElement>();
const content = ref<HTMLElement>();
const labelId = `disclosure-${useId().replaceAll(":", "")}`;
watch(
  () => props.invalid,
  (invalid) => {
    if (invalid) open.value = true;
  },
  { immediate: true },
);
watch(
  open,
  async (value) => {
    if (
      !value &&
      typeof document !== "undefined" &&
      content.value?.contains(document.activeElement)
    ) {
      await nextTick();
      root.value
        ?.querySelector<HTMLElement>("[data-disclosure-trigger]")
        ?.focus({ preventScroll: true });
    }
  },
  { flush: "pre" },
);
</script>
<template>
  <div ref="root" class="motion-disclosure min-w-0" :data-motion="motion">
    <UCollapsible
      v-model:open="open"
      :disabled="disabled"
      :unmount-on-hide="false"
      :ui="ui"
    >
      <UButton
        :id="labelId"
        data-disclosure-trigger
        :label="label"
        :disabled="disabled"
        :size="size"
        :ui="buttonUi"
        color="neutral"
        variant="ghost"
        class="w-full justify-between"
        trailing-icon="i-tabler-chevron-down"
      />
      <template #content>
        <div
          ref="content"
          role="region"
          :aria-labelledby="labelId"
          :aria-hidden="!open"
          :inert="!open"
          class="min-w-0 py-3"
        >
          <slot />
        </div>
      </template>
    </UCollapsible>
  </div>
</template>
<style scoped>
.motion-disclosure :deep([data-slot="trailingIcon"]) {
  transition: transform 180ms ease-out;
}
.motion-disclosure
  :deep(
    [data-disclosure-trigger][aria-expanded="true"] [data-slot="trailingIcon"]
  ) {
  transform: rotate(180deg);
}
.motion-disclosure[data-motion="false"] :deep([data-slot="content"]) {
  animation: none;
}
.motion-disclosure[data-motion="false"] :deep([data-slot="trailingIcon"]) {
  transition: none;
}
@media (prefers-reduced-motion: reduce) {
  .motion-disclosure :deep([data-slot="content"]) {
    animation: none;
  }
  .motion-disclosure :deep([data-slot="trailingIcon"]) {
    transition: none;
  }
}
</style>
