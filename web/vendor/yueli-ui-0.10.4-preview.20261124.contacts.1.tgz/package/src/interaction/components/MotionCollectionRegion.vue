<script setup lang="ts">
import { ref, computed, toRef, watch, onBeforeUnmount } from "vue";
import { useMinimumLoading } from "../../feedback/minimum-loading";
const props = withDefaults(
  defineProps<{
    label: string;
    loadingLabel: string;
    loading?: boolean;
    state?: "ready" | "empty" | "error";
    motion?: boolean;
    reserveSpace?: boolean;
  }>(),
  { state: "ready", motion: true, reserveSpace: true },
);
const pending = useMinimumLoading(toRef(props, "loading", false));
const visibleState = computed(() => (pending.value ? "loading" : props.state));
const root = ref<HTMLElement>();
const body = ref<HTMLElement>();
const height = ref<number>();
const transitioning = ref(false);
let observer: ResizeObserver | undefined;
watch(
  body,
  (element) => {
    observer?.disconnect();
    if (!element) return;
    const measure = () => {
      if (visibleState.value === "ready")
        height.value = element.getBoundingClientRect().height;
    };
    measure();
    if (typeof ResizeObserver !== "undefined") {
      observer = new ResizeObserver(measure);
      observer.observe(element);
    }
  },
  { flush: "post" },
);
watch(
  visibleState,
  () => {
    if (root.value?.contains(document.activeElement))
      root.value.focus({ preventScroll: true });
  },
  { flush: "pre" },
);
function beforeLeave(element: Element) {
  transitioning.value = true;
  element.setAttribute("inert", "");
}
onBeforeUnmount(() => observer?.disconnect());
</script>
<template>
  <section
    ref="root"
    tabindex="-1"
    :aria-label="label"
    :aria-busy="pending || undefined"
    :data-region-state="visibleState"
    :style="
      reserveSpace && (pending || transitioning) && height
        ? { minHeight: `${height}px` }
        : undefined
    "
    class="min-w-0"
    :data-motion="motion"
  >
    <span role="status" class="sr-only">{{ pending ? loadingLabel : "" }}</span>
    <Transition
      :name="motion ? 'collection-state' : undefined"
      mode="out-in"
      @before-leave="beforeLeave"
      @before-enter="(element) => element.removeAttribute('inert')"
      @after-enter="transitioning = false"
      @enter-cancelled="transitioning = false"
    >
      <div :key="visibleState" ref="body" class="min-w-0">
        <template v-if="visibleState === 'loading'">
          <slot name="loading"
            ><div
              v-for="n in 3"
              :key="n"
              class="space-y-2 border-b border-default py-4 last:border-0"
            >
              <USkeleton class="h-4 w-1/3" /><USkeleton
                class="h-3 w-2/3"
              /></div
          ></slot>
        </template>
        <slot v-else-if="visibleState === 'empty'" name="empty" />
        <slot v-else-if="visibleState === 'error'" name="error" />
        <slot v-else />
      </div>
    </Transition>
  </section>
</template>
<style scoped>
.collection-state-enter-active,
.collection-state-leave-active {
  transition: opacity 160ms ease-out;
}
.collection-state-enter-from,
.collection-state-leave-to {
  opacity: 0;
}
@media (prefers-reduced-motion: reduce) {
  .collection-state-enter-active,
  .collection-state-leave-active {
    transition: none;
  }
}
</style>
