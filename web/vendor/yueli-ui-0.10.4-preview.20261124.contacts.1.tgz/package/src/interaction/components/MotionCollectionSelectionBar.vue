<script setup lang="ts">
import { ref, watch, nextTick, onBeforeUnmount } from "vue";
import type { ButtonProps } from "@nuxt/ui";
import CollectionSelectionBar from "../../collection/CollectionSelectionBarBase.vue";
import type { CollectionPanelMessages } from "../../collection/panel";
const props = withDefaults(
  defineProps<{
    count: number;
    size?: ButtonProps["size"];
    mode?: "keys" | "query";
    messages: CollectionPanelMessages;
    canSelectAllResults?: boolean;
    motion?: boolean;
    reserveSpace?: boolean;
    returnFocusTo?: HTMLElement | null;
  }>(),
  {
    mode: "keys",
    canSelectAllResults: false,
    motion: true,
    reserveSpace: true,
  },
);
const emit = defineEmits<{ selectAllResults: []; clearSelection: [] }>();
const root = ref<HTMLElement>();
const body = ref<HTMLElement>();
const height = ref<number>();
let observer: ResizeObserver | undefined;
watch(
  body,
  (element) => {
    observer?.disconnect();
    if (!element || typeof ResizeObserver === "undefined") return;
    observer = new ResizeObserver(() => {
      if (props.count > 0)
        height.value = element.getBoundingClientRect().height;
    });
    observer.observe(element);
  },
  { flush: "post" },
);
watch(
  () => props.count,
  async (count, previous) => {
    const focusedInside = body.value?.contains(document.activeElement);
    if (count === 0 && previous > 0 && focusedInside) {
      await nextTick();
      (props.returnFocusTo?.isConnected
        ? props.returnFocusTo
        : root.value
      )?.focus({ preventScroll: true });
    }
  },
);
onBeforeUnmount(() => observer?.disconnect());
</script>
<template>
  <div
    ref="root"
    tabindex="-1"
    :aria-label="messages.bulkRegion"
    class="min-w-0"
    :style="reserveSpace && height ? { minHeight: `${height}px` } : undefined"
  >
    <Transition :name="motion ? 'selection' : undefined">
      <div
        v-show="count > 0"
        :inert="count === 0 ? true : undefined"
        :aria-hidden="count === 0 ? true : undefined"
        ref="body"
        class="rounded-lg border border-default bg-primary/5 p-3"
      >
        <CollectionSelectionBar
          :count="count"
          :size="size"
          :mode="mode"
          :messages="messages"
          :can-select-all-results="canSelectAllResults"
          @select-all-results="emit('selectAllResults')"
          @clear-selection="emit('clearSelection')"
          ><slot
        /></CollectionSelectionBar>
      </div>
    </Transition>
  </div>
</template>
<style scoped>
.selection-enter-active,
.selection-leave-active {
  transition:
    opacity 180ms ease-out,
    transform 180ms ease-out;
}
.selection-enter-from,
.selection-leave-to {
  opacity: 0;
  transform: translateY(0.25rem);
}
@media (prefers-reduced-motion: reduce) {
  .selection-enter-active,
  .selection-leave-active {
    transition: none;
  }
}
</style>
