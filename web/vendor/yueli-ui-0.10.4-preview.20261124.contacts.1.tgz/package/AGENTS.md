# @yueli/ui

本包为 Nuxt UI 消费者提供共享主题、交互和页面模式。使用现有组件、计划新增封装或升级依赖时，从这里进入。

## 使用与选型

1. 在消费者包含 `package.json` 的目录执行 `yueli-ui inspect --project . --json`，确认声明、锁定制品与实际来源。未提供 bin 时使用 `node node_modules/@yueli/ui/src/discovery/cli.mjs`。
2. 按需求执行 `yueli-ui search "搜索" --kind component --project . --json --limit 5`。没有结果时改用较短关键词或准确组件名；从 [常用高级组件清单](docs/advanced-components.md) 按场景定位。
3. 对选中的稳定 ID 查询 `docs <id> --section usage|api|readme|migration`（每次选一个 section，并带 `--project . --json`）。采用 active 入口；deprecated 按替代说明迁移，removed 不生成 import。

文档以消费者已安装包为准；当前源码或最新文档不能补作旧包合同。查询工具不执行 Nuxt 配置，最终运行解析仍需消费者构建与浏览器验证。命令、MCP、版本识别和升级差异见 [发现与升级说明](docs/ai-discovery.md)。安装与主题接入见 [README](README.md)。

## 维护本包

- 公共用途、中文别名、生命周期和文档入口由 `src/manifest.ts` 拥有；props、emits、model、slots 与默认值由组件及公共类型拥有。维护这些源文件后生成 `ai/`，不手改生成目录。
- 沿用 Nuxt UI 的主题、原生 `size`、`ui` 与已有交互能力。新封装提供跨消费者复用的职责，产品的数据请求、业务权限和持久化留给消费者。选型边界见高级组件清单。
- 修改发现入口或随包文档时，核对 `package.json/files`、目录生成器和打包文件校验；运行 `generate:discovery`、`test:discovery`，并实际检查 tarball 包含指引及被引用文档。组件或公共类型变化再运行相应类型、组件和界面验收。
- 对外发行使用新版本并经过 Workspace 批准基线；文档内容同样绑定制品摘要，已交付的同版本 tarball 不覆盖。升级命令与门禁不代表获得提交、推送、发行或部署授权。

## 消费者仓库的入口

包内指引不意味着代理会自动遍历依赖。消费者的根 `AGENTS.md` 应明确指向**已安装** `@yueli/ui/AGENTS.md` 并要求先 inspect、再 search/docs。详细说明由本包维护，消费者只保留入口，不复制规则全文。
