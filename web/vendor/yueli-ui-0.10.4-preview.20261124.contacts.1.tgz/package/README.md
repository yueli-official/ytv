# @yueli/ui

Experimental public UI foundation for Nuxt UI consumers.

`AdminRowActions` uses each action's leading icon without adding a second external-link icon to overflow labels. Links keep their declared target and rel attributes. Products should use concise action labels; item context belongs to the action group's accessible name.

AI 使用与维护从 [AGENTS.md](AGENTS.md) 开始；按场景选型见 [常用高级组件清单](docs/advanced-components.md)，其他参考见 [文档索引](docs/index.md)。
For version inspection, public capability search, version-matched documentation,
dry-run upgrade plans and stdio MCP, see [discovery tools](docs/ai-discovery.md). The pure JSON catalog
is exported at `@yueli/ui/discovery/catalog.json`; Node queries use `@yueli/ui/discovery`.

Add `yueli-admin-branded` to `AdminConsoleLayout` to opt into branded page headers,
collection surfaces and compact toolbars from `theme.css`. Colors derive from the
consumer's `--ui-primary` and semantic surfaces; public pages and other admin
consumers remain unchanged. Exclude immersive editors from this class. Put actual
dashboard metrics in `PageHeader`'s `tools` slot using `AdminOverview`, a
`data-admin-metrics` grid and `AdminMetricCard`. `AdminOverview`'s optional `artwork`
slot accepts a **product-owned** SVG/image/component; Foundation only owns its
placement, decorative accessibility and responsive behavior, never the drawing.
The illustration is hidden when the overview container is narrower than 60rem.
Put list search controls in `CollectionPanel`'s
`navigation` slot inside `data-admin-collection-tools`; custom collections can use
`data-admin-collection` and `data-admin-collection-columns`. Comment moderation
also accepts a `navigation` slot while preserving its built-in lifecycle tabs by
default. These attributes only select presentation; products own data and actions.

`AdminTabs` from `@yueli/ui/admin` provides same-page horizontal navigation with
`v-model`, `items: readonly AdminTabItem[]`, and `navigationLabel`. It owns active
weight/underline, single-axis scrolling and selected-tab visibility (including
external selection and resize). Add a product surface class for a standalone bar;
use `TabbedSurface` when tabs and content share a card. `TabbedSurface` keeps its
existing API and now delegates navigation to `AdminTabs`. Product routes, data and
content layout remain caller-owned; this does not change all Nuxt UI Tabs globally.

Authorization user lists use `AuthorizationGrantBadge` from `@yueli/ui/admin`: pass the product role display name as `role` and the grant source as `source`. The badge shows only the role; its hover/focus tooltip localizes the source, including `initial_claim`. See [grant badge conventions](../../../flightdeck/knowledge/frontend/authorization-grant-badges.md).

The package intentionally has no root export. Import a documented explicit subpath so experimental modules can mature independently:

```ts
import { createCollectionWorkflow } from "@yueli/ui/collection";
```

Current public surface:

- `@yueli/ui` — Nuxt module registering public components, Nuxt UI, complete component sources and default styles, with a configurable `Y` prefix.
- `@yueli/ui/tailwind.css` — legacy explicit source entry; Nuxt consumers do not import this file.
- `@yueli/ui/theme` — provider-neutral Nuxt UI preset and complete Tabler icon contract.
- `@yueli/ui/theme.css` — default light/dark tokens and base rules, installed automatically by the Nuxt module.
- `@yueli/ui/manifest` — machine-readable maturity and ownership metadata.
- `@yueli/ui/messages` — caller-owned message key/parameter contract; no locale catalogs.
- `@yueli/ui/image` — bounded raster optimization/crop geometry, output naming and caller-translatable dimension validation.
- `@yueli/ui/image/browser` — disposable browser decode/canvas Adapter with explicit optimization/fallback results.
- `@yueli/ui/account-menu/pattern` — provider-neutral account/appearance grouping, identity fallback and inline/sidebar/collapsed menu trigger.
- `@yueli/ui/admin` — complete AdminConsoleLayout, lower-level shell/page primitives, shared PageHeader and TabbedSurface with caller-owned brand content, navigation, data and translation.
- `@yueli/ui/remote-select` — debounced, abortable and cached remote entity search built on Nuxt UI SelectMenu.
- `@yueli/ui/dashboard/pattern` — legacy compatibility entry for PageHeader, TabbedSurface and region-driven DashboardLayout; new admin consumers use `@yueli/ui/admin`.
- `@yueli/ui/feedback` — latest-wins action lifecycle, minimum loading visibility and transport-neutral notice normalization.
- `@yueli/ui/feedback/pattern` — explicit `ActionFeedbackButton` import.
- `@yueli/ui/navigation/back-to-top` — explicit accessible BackToTop Pattern import.
- `@yueli/ui/navigation/table-of-contents` — accessible heading hierarchy, fragment navigation and active-section tracking for reading surfaces.
- `@yueli/ui/sharing/content-share` — bounded public-content share targets, system sharing and clipboard feedback rendered on the original action.
- `@yueli/ui/settings` — framework-independent JSON-safe baseline, dirty, capture and discard workflow.
- `@yueli/ui/settings/vue` — reactive Vue Adapter for a caller-owned settings form.
- `@yueli/ui/settings/browser` and `@yueli/ui/settings/vue-router` — opt-in unload and route-leave guards.
- `@yueli/ui/settings/pattern` — SettingsLayout, SettingSection and SettingsSaveDock explicit imports.
- `@yueli/ui/collection` — framework-independent remote collection workflow, schema-driven route query codec and memory query Adapter.
- `@yueli/ui/collection/vue` — Vue setup lifecycle, reactive snapshot and data-query invalidation Adapter.
- `@yueli/ui/collection/vue-router` — optional Vue Router query Adapter plus a reactive query-only composable for host-owned data loaders.
- `@yueli/ui/collection/pattern` — complete `CollectionPanel`, lower-level `CollectionFrame`, adaptive table toolbar, and composable Toolbar/Pagination/Dock/Footer/Tabs/View/selection patterns.
- `@yueli/ui/comments` — public two-level comment threads, sorting, nested reply timeline, plain-text composer and caller-supplied data/auth adapters.
- `@yueli/ui/comments/admin` — comment moderation collection, canonical source/user/date columns, responsive rows and caller-owned data/command adapters.

### 封装组件的大小与字体

控件尺寸、字号、间距与图标大小沿用 Nuxt UI 的原生 `size`，Foundation 不重新定义尺寸映射，也不设置独立控件字体体系。集合工具栏、选择操作、视图切换、分页、编辑器命令栏、行操作与账户菜单可直接传原生 `size`；未传时保留 Nuxt UI 默认值与消费者主题配置。

```vue
<CollectionHeaderTools size="lg" ... />

<UTheme :props="{ button: { size: 'sm' }, input: { size: 'sm' } }">
  <CollectionTableToolbar ... />
</UTheme>
```

消费者继续用 Nuxt UI 的 `app.config.ui`、`UTheme` 和控件实例 `ui` 覆盖。工具栏与命令栏的插槽按钮继承原生上下文，显式传入的控件属性优先；共享封装不使用固定宽高或字号压过原生尺寸。`createUiPreset` 负责已有颜色与表面样式，不改写原生 `variants.size` 或字段 `fixed` 默认值。

正文、标题和布局使用 Tailwind 命名 Token，如 `text-sm`、`font-sans`、`gap-3`、`rounded-lg`，CSS 使用 `var(--text-sm)`、`var(--spacing)` 等变量。组件内不新增独立数值字号、字体或像素尺寸；细边框、浏览器断点为必要例外。阴影与现有语义文字变量集中在主题中，消费者可通过 CSS Token 覆盖。源码门禁见 `test/design-tokens.test.ts`。

当前是未发布预览候选的本地修改；正式包发行与产品消费者升级未包含在本轮交付中。

Enable the Nuxt module and package Tailwind source:

```ts
export default defineNuxtConfig({
  modules: ["@nuxt/ui", "@yueli/ui"],
  yueliUi: {
    // Only names that can arrive from persisted data or an API belong here.
    // Literal i-tabler-* names in application and @yueli source are scanned.
    tablerIcons: ["i-tabler-palette", "i-tabler-photo"],
  },
});
```

The module owns deterministic local Tabler delivery for every consumer: it
pins the Nuxt Icon peer, bundles Foundation/core and application allowlist
icons, and resolves other valid Tabler names through Nuxt Icon's same-origin
server provider. External Iconify fallback remains disabled.

`YAdminIconPicker` provides the shared searchable Tabler manager for settings,
navigation and content metadata. It shows a preloaded Chinese-labelled quick
catalog immediately, then lazy-loads the complete Tabler catalog only when the
picker is mounted. Search therefore includes names such as `fish` without
adding the full collection to the application entry bundle. Persisted choices
remain available after reload through the same-origin server provider. Products
may supply preferred icons through `options` without disabling full-catalog
search. Set `fullCatalog: false` explicitly when a domain needs a restricted set.

### Upgrading to 0.2.0

Install the pinned `@nuxt/icon@2.4.1`, `@iconify-json/tabler@1.2.35` and
`@iconify/vue@5.0.1` peers. The provider is the local Nuxt server and external
Iconify API fallback is disabled; `yueliUi.tablerIcons` remains the fast-path
allowlist for icons that must render without a lazy lookup.

```ts
export default defineNuxtConfig({
  modules: ["@yueli/ui"],
  css: ["~/assets/css/main.css"], // Product-owned tokens and extra styles only.
});
```

### Automatic styles in 0.9

The module owns the Tailwind/Nuxt UI entry, scans the complete package source,
and compiles registered layer and product CSS in one graph. Asset and Content
layers register their own styles. Remove old framework/shared CSS imports and
package-internal `@source` declarations from the application; the build gate
rejects these redundant imports in custom source directories, Vue/JS/TS imports and Nuxt CSS configuration as well. Framework CSS resolves from the consumer independently of the build directory. No component requires a per-site CSS checklist.
Typography is an owned dependency and is enabled automatically. Product `@theme`
declarations, custom plugins, CSS variables and additional
styles remain in the application's configured CSS. They follow the defaults;
component `ui` props, normal props and slots retain their existing customization.

Build the app config from caller-owned palette names. Foundation knows neither
the product name nor how its Tailwind palettes are registered. `primary` is
required; `neutral`, `success`, `info`, `warning`, and `error` may be replaced
independently when a product has its own semantic palette:

```ts
import { createUiPreset } from "@yueli/ui/theme";

export default defineAppConfig(
  createUiPreset({
    primary: "brand",
    success: "positive",
    warning: "caution",
    error: "danger",
  }),
);
```

`@yueli/ui/theme.css` owns both light and `.dark` semantic surface values. Public
feedback Patterns consume Nuxt UI semantic roles such as `--ui-primary`,
`--ui-success`, `--ui-warning`, and `--ui-error`; they do not embed product RGB,
hex, or dark-only colors. Switching color mode or registering a different
palette therefore updates the same components without a second implementation.

The CSS surface API uses the `--yueli-*` and `.yueli-*` namespaces. Prefer
Tailwind utilities inside components; the stylesheet exists for cross-tree
tokens and browser-level behavior that cannot be expressed reliably by local
component utilities. It is opt-in so a consumer may use only the workflow
packages without adopting the visual theme.

Image policy is split from the browser runtime. The pure entrypoint rejects
active SVG input, preserves animated GIF by default, caps side length and total
canvas pixels, and exposes validation data instead of translated sentences.
The browser Adapter guarantees decoded object URL cleanup and can discard an
encoded result that is larger than the source:

```ts
import { optimizeImage } from "@yueli/ui/image/browser";

const result = await optimizeImage(file, { maxSide: 1920 });
// result.reason is stable; the caller decides whether/how to notify the user.
await upload(result.file);
```

The module auto-imports public Patterns with the `Y` prefix by default. It also auto-imports `useActionFeedback`, `useMinimumLoading`, and `useFeedbackConfirm`; consumers that prefer explicit imports can use `@yueli/ui/feedback`. BackToTop owns its scroll threshold, focus return, reduced-motion behavior and dock/overlay avoidance. Action feedback owns latest-wins async state and reset timing. AdminConsoleLayout follows Nuxt UI's official dashboard ownership and hides the fixed sidebar, search, active navigation, route bar, canvas, mobile drawer and back-to-top anatomy behind one small Interface. AccountMenu owns identity fallback, action grouping, optional appearance selection, sidebar trigger anatomy and the async logout command boundary without reading an auth provider or persisting color-mode state. Visible copy and appearance state remain caller-owned: pass translated props or messages and a preference Adapter; Foundation ships no locale catalogs.

Use the admin template with Nuxt UI primitives and caller-owned domain content:

```vue
<YAdminConsoleLayout
  brand-label="Content"
  brand-icon="i-tabler-file-text"
  brand-to="/"
  :navigation="navigation"
  :search-groups="searchGroups"
  :messages="shellMessages"
  storage-key="content-admin"
  main-id="content-main"
>
  <template #account="{ collapsed }">
    <ProductAccountMenu :collapsed />
  </template>
  <DocumentManagePage />
</YAdminConsoleLayout>
```

Standard canvas pages use `YManagePage`; it requires the page icon and owns the
accessible heading, right-side action area and the fixed `space-y-5` rhythm
between the heading and page body. Collection pages place `YCollectionPanel`
inside it, so search, filters, selection and pagination remain one collection
surface instead of becoming a second page toolbar:

```vue
<YManagePage id="documents" title="Documents" icon="i-tabler-file-text">
  <template #actions><UButton label="New document" /></template>
  <YCollectionPanel v-bind="collection" />
</YManagePage>
```

`PageHeader` remains the lower-level seam for exceptional compositions. New
standard pages should not call it directly because doing so makes the required
icon and vertical rhythm caller-owned again.

Dense collection rows use `YAdminRowActions`. Callers provide only action
identity, label, Tabler icon, target or callback; the Module owns tooltip,
accessible naming, optical centering, responsive hit area, danger treatment and
the shared 16px glyph. Use `presentation="inline"` for the few justified direct
actions and `presentation="overflow"` for low-frequency action groups:

```vue
<YAdminRowActions
  :label="`${item.title} actions`"
  :items="[
    {
      id: 'view',
      label: 'View',
      icon: 'i-tabler-external-link',
      to: item.href,
    },
    {
      id: 'edit',
      label: 'Edit',
      icon: 'i-tabler-pencil',
      onSelect: () => edit(item),
    },
  ]"
/>
```

Settings workflows use `YSettingSection` as the standard configuration Card.
It owns a compact title header, optional right-side actions and a full-width
body below; products should not recreate left-label/right-form grids or custom
Card headers. Omit `description` when the field labels already explain the
section.

Public content comments use `PublicCommentThread`. The product owns loading and
submission adapters; the Module owns thread cards, nested replies, oldest/newest
sorting, composer state and anonymous/login presentation:

```vue
<PublicCommentThread
  v-model:order="order"
  :comments="comments"
  :total="total"
  :messages="messages"
  :format-time="formatTime"
  :submit="submitComment"
/>
```

`YAdminConsoleLayout` is SSR-safe and is the server-rendered application shell. Do not
wrap the whole component in `ClientOnly` or replace it with a hydration-only
"opening console" screen. Keep browser-only behavior at the smallest child
boundary. Consumer acceptance should inspect the navigation response HTML for
`data-admin-shell` and verify that repeated authenticated refreshes never
render a whole-page placeholder.

Admin navigation is intentionally shallow. The public contract accepts flat
navigation or one parent level with leaf children; deeper product structure
belongs in page tabs, local navigation or breadcrumbs. A parent with children
should normally use `type: "trigger"`, while each child owns the actual route.
Product skins set semantic `--yueli-admin-shell`, `--yueli-admin-canvas` and
`--yueli-admin-search` tokens; the shared module owns geometry, states and
responsive behavior. `YAdminShell` and its typed `ui` prop remain a lower-level
seam only for a genuinely different console anatomy.
Normalize the caller-computed active state before rendering, and derive command
palette leaves from the same permission-filtered tree:

```ts
import {
  createAdminNavigationSearchItems,
  normalizeAdminNavigation,
  type AdminNavigationItem,
} from "@yueli/ui/admin";

const navigation = normalizeAdminNavigation([
  {
    label: "Site settings",
    icon: "i-tabler-settings",
    type: "trigger",
    children: [
      { label: "Home", to: "/manage/home", active: true },
      { label: "Footer", to: "/manage/footer" },
    ],
  },
] satisfies readonly AdminNavigationItem[]);

const searchItems = createAdminNavigationSearchItems(navigation, {
  idPrefix: "manage-page",
});
```

`normalizeAdminNavigation` promotes an explicitly active child to its parent
and opens that group on first render. It also makes every parent trigger-only,
discarding parent navigation and selection callbacks so a mobile disclosure
cannot close the Sidebar. Routes and authorization remain
caller-owned: recursively remove unauthorized leaves before normalization, then
use the same result for the Sidebar and search projection. Parent triggers do
not close a mobile Sidebar; leaf navigation may close it after selection.

Do not use the admin template as a generic card or analytics layout. Nuxt UI continues to own Button, Card, Table, Select and other primitives; products own metrics, permissions, routes and business actions. The deprecated DashboardLayout fixed four business regions and is not the target architecture. The structure follows the official [Nuxt UI dashboard template](https://github.com/nuxt-ui-templates/dashboard) without copying its fixtures or product pages.

`AdminPage` makes its `mainId` element the page scroll container and focus target. Pass the same ID to `BackToTop` as both `target-id` and `scroll-container-id`; sticky page content can also use that stable boundary without inspecting Nuxt UI's internal DOM.

Use `RemoteSelect` only when options come from a remote loader. Static and locally filtered options should use `USelectMenu` directly:

```vue
<script setup lang="ts">
import type {
  RemoteSelectLoader,
  RemoteSelectMessages,
} from "@yueli/ui/remote-select";

const authorId = ref<string | number | null>(null);
const messages: RemoteSelectMessages = {
  placeholder: "Select author",
  searchPlaceholder: "Search authors",
  empty: "No authors found",
  error: "Authors could not be loaded",
  retry: "Retry",
  minimumQuery: (count) => `Enter at least ${count} characters`,
};
const load: RemoteSelectLoader = async ({ query, signal }) => {
  const result = await api.searchAuthors({ query, signal });
  return {
    items: result.items.map((author) => ({
      value: author.id,
      label: author.name,
      description: author.email,
    })),
  };
};
</script>

<template>
  <YRemoteSelect v-model="authorId" :load :messages :minimum-query-length="2" />
</template>
```

The loader receives an `AbortSignal`; consumers must pass it to their HTTP adapter. The Pattern owns debounce, latest-wins sequencing, request cancellation, per-instance query caching and retry. It never displays raw transport errors.

Option presentation uses Nuxt UI's native label, description, leading icon and selected indicator. Both `RemoteSelectOption` and `CollectionControlOption` accept `description`, `icon` and `trailingIcon`; use the current level's name for `label` and its ancestor path for `description`. Right icons are decorative selection hints, not separate buttons. RemoteSelect forwards `item-leading`, `item-label`, `item-description` and `item-trailing` slots; an explicit `item` slot replaces the whole row and owns its presentation. Use a trailing slot for caller-owned hover styling, and preserve keyboard/highlight and touch visibility. Collection controls preserve native disabled options.

`AdminRowActions.presentation` defaults to `auto`: one action remains visible, two or three actions fold into the grouped menu when the action container is at most 10rem wide, and more than three actions use the menu at any width. `inline` retains wrapping icon buttons; `overflow` always uses the menu. Both renderings retain the same items, accessible labels, link targets, loading/disabled rules and native Nuxt UI size. CSS container queries keep the SSR tree stable; the decision uses available action width, not a device label. This changes the default presentation of existing calls; consumers requiring fixed inline buttons should explicitly set `presentation="inline"` when upgrading.

Settings keeps persistence and translation outside the library. The pure workflow owns a cloned baseline and dirty/capture/discard semantics; Vue, browser unload and Router leave protection are separate opt-in Adapters. Route confirmation is a caller function, so Foundation never hard-codes a language or calls `window.confirm` on behalf of every product. The visible Patterns accept caller-owned labels and slots while standardizing responsive section navigation and the safe-area-aware save dock.
When a settings workflow is placed inside `AdminPage`, pass `:show-header="false"` to `SettingsLayout`; the page navbar remains the single page heading while settings sections keep their own local headings.

Settings section navigation responds to its own container: tabs use a dropdown below 48rem and wrapping buttons above it; sidebar layout uses a dropdown below 64rem and a sidebar above it. Existing `navigationLayout="auto|sidebar|tabs"` chooses the structure, and resizing preserves the active section. A wide browser with a narrow panel still gets the compact control.

```vue
<script setup lang="ts">
import { useActionFeedback } from "@yueli/ui/feedback";

const save = useActionFeedback();
</script>

<template>
  <YActionFeedbackButton
    :status="save.status.value"
    idle-label="Save"
    pending-label="Saving"
    success-label="Saved"
    @click="save.run(persist)"
  />
  <YBackToTop label="Back to top" />
</template>
```

Application feedback uses four shared surfaces. Mount one root under `UApp`,
disable Nuxt UI's built-in toaster, and keep all visible labels caller-owned:

```vue
<UApp :toaster="null">
  <YFeedbackRoot
    :messages="{
      confirm: t('common.confirm'),
      cancel: t('common.cancel'),
      toastClose: t('common.closeNotification'),
    }"
  >
    <NuxtPage />
  </YFeedbackRoot>
</UApp>
```

Inside descendants, use the shared surfaces instead of product-local alerts:

```vue
<script setup lang="ts">
import { createNuxtToastNotifier } from "@yueli/ui/feedback";
import { useToast } from "@nuxt/ui/composables";

const toast = createNuxtToastNotifier(useToast());
const confirmation = useFeedbackConfirm();
const save = useActionFeedback();

async function removeItem() {
  const result = await confirmation.confirm({
    title: "Delete item?",
    description: "This cannot be undone.",
    tone: "error",
  });
  if (!result.confirmed) return;
  await deleteItem();
}
</script>

<template>
  <YActionFeedbackButton
    :status="save.status.value"
    idle-label="Save"
    pending-label="Saving"
    success-label="Saved"
    @click="save.run(persist)"
  />
  <YInlineStatus v-if="loadProblem" tone="error">
    {{ loadProblem }}
  </YInlineStatus>
</template>
```

The four standard surfaces are: action feedback on the triggering control,
`YInlineStatus` beside persistent local state, the bottom-right
`YFeedbackToastRegion` owned by `YFeedbackRoot` for transient cross-region
notices, and `useFeedbackConfirm()` for decisions that must interrupt the task.
The notifier exposes `info()`, `success()`, `warning()`, and `error()` helpers so
products do not repeat tone/icon policy.

The notifier has four semantic helpers; `InlineStatus` also accepts `neutral` (five tones).
`InlineStatus` supports `variant="plain"` (default, no panel) and `variant="soft"`
(light tinted surface and border). A title puts body text on the next line; the
`actions` slot sits below. Keep local validation beside its field and use the
triggering `ActionFeedbackButton` for an applied/saved result. Do not duplicate it
with a success toast. All toasts are closable and have no countdown. Errors remain
until dismissed (`duration: 0`); other tones default to 3200 ms and pause during
hover or keyboard focus. Inline status always exposes a working close button (self-hides and emits dismiss).
Toasts support horizontal swipe dismissal and optional typed `actions` for undo/retry;
asynchronous actions prevent duplicate execution and retain a retryable failure.
Error duration and close policy are enforced even when
a caller supplies conflicting values. This feedback port follows Yotta's
`frontend/src/composables/useAppToast.ts` and `components/common/InlineStatus.vue`,
while retaining Foundation's existing public adapters and richer action API.

`CollectionPanel` is the default complete Pattern for card, grid and lightweight row collections: it owns responsive search, a single filter Popover, configured direction utilities, page and result selection, loading/error/empty states, row/grid containers and pagination. At the standard `@xl` container size (576px), search, the filter trigger and utilities share one row; compact containers put search first and the controls on a deterministic second row. Selection replaces that default toolbar in the same position instead of appending a sticky layer, while the column header remains visible. Pages that place search/filter controls in the caller-owned `navigation` slot can opt into the same contextual-toolbar behavior with `selectionReplacesNavigation`; lifecycle tabs or other persistent navigation should leave it disabled. While batch mode is active, `CollectionPanel` suppresses row-level `AdminRowActions` and double-click editing so the selected-set action remains the active interaction context. Callers may pass an empty `searchAction` to use live search, provide an `active-filters` slot for individually removable chips, and use a control `searchPlaceholder` to opt into Nuxt UI's searchable `USelectMenu`. Callers still own translated `CollectionPanelMessages`, query semantics, business HTTP and mutations. `isSelectable` on the Workflow and `isItemSelectable` on the Pattern express rows such as the current administrator that must remain visible but cannot enter batch selection. Because page-local eligibility cannot describe unloaded rows, all-results selection is intentionally unavailable when that predicate is configured. For strict data-table alignment, sorting, visibility and row selection, compose the public Collection Workflow with Nuxt UI `UTable` directly; the Foundation does not reimplement or shallow-wrap its column model. `CollectionTableToolbar` supplies the same toolbar anatomy around that direct `UTable`. Filter fields stay flat unless a real semantic distinction justifies sections under the [Collection toolbar standard](src/collection/toolbar-standard.md); strict table sorting remains in column headers. `CollectionFrame` remains the lower-level anatomy seam. Lightweight or domain-shaped screens may compose `CollectionToolbar`, `CollectionPagination`, `CollectionDock`, `CollectionFooter`, `CollectionLifecycleTabs`, `CollectionViewToggle`, `CollectionActiveFilters`, `CollectionPageSelection`, `CollectionRowShell` and `CollectionSortDirectionButton`.

Nuxt UI owns primitives. Collection patterns compose Nuxt UI controls only where the package adds stable responsive anatomy, query/selection semantics or accessibility behavior; it does not re-export generic buttons, cards or tables. DashboardLayout is a workflow-level composition of caller-owned regions, not a generic card/dashboard primitive.

Route query semantics stay caller-owned, while the shared codec applies the same normalization rules in every consumer:

```ts
const codec = createCollectionRouteQueryCodec({
  q: { kind: "string", default: "", maxLength: 120 },
  status: {
    kind: "enum",
    values: ["all", "draft", "published"] as const,
    default: "all",
  },
  page: { kind: "positive-integer", default: 1 },
});
```

Defaults are omitted from the URL. Repeated query values use the first value; invalid enums and positive integers fall back to the caller's declared default.

`useVueCollectionWorkflow` creates and disposes the Workflow inside Vue setup, binds an optional query Adapter, runs the first load on mount and exposes a reactive snapshot. A caller-owned primitive `dataQueryKey` can exclude presentation-only fields such as `view`, so list/grid changes do not refetch identical data. The caller's async `load` still owns business HTTP and must resolve or reject the supplied Workflow load token.

When Nuxt `useAsyncData` or another host loader already owns fetching, `useVueRouterCollectionQuery` supplies normalized reactive URL state and `replace`/`update` commands without introducing a second loader.

Run `pnpm --filter @yueli/ui test`, `pnpm --filter @yueli/ui typecheck` and
`pnpm --filter @yueli/ui test:pack` from the repository root. The pack conformance checks the
tarball allowlist, installs it into a temporary standalone Nuxt 4 consumer and runs a production build.

## 维护说明

- 生命周期：实验性公共 UI foundation，未达到 Pattern 门槛前不承诺稳定视觉 API。
- 权威来源：显式公开子路径、maturity manifest、单元测试及 UI conformance consumer。
- 维护边界：共享查询、选择、加载时序与消息引用；Nuxt UI primitives、业务字段、翻译和产品动作由调用方拥有。
- 变更要求：公开接口或路由同步行为变化时，必须同步更新单测、生产模式 Playwright 和 Work 证据。

### Compact density (0.4.0)

Set `data-yueli-density="compact"` on the document HTML element in the
consumer's SSR head configuration (for Nuxt, use `useHead({ htmlAttrs: {
"data-yueli-density": "compact" } })`). Import the normal
`@yueli/ui/theme.css`. The document-level attribute also covers portalled UI.
It selects shared tokens for page headings, navigation, row/account controls
and comments, and keeps form text at 14px across breakpoints. Omitting the
attribute preserves previous sizes. Business and authorization behavior does
not change.

Remove conflicting local mobile-enlargement utilities when opting in. Version
0.4.0 is a local release candidate; publication and remote artifact URL updates
are separate actions.

### Mobile bottom navigation (0.4.0 candidate)

`@yueli/ui/navigation/mobile-bottom-nav` exports `MobileBottomNav` and
`MobileBottomNavItem`; Nuxt module consumers can also use `YMobileBottomNav`.
Place one navigation as the last child of the public flex-column shell, after main.
Import the shared Tailwind/theme styles and set viewport `width=device-width,
initial-scale=1, viewport-fit=cover` in the consumer's document head.

```vue
<script setup lang="ts">
import {
  MobileBottomNav,
  type MobileBottomNavItem,
} from "@yueli/ui/navigation/mobile-bottom-nav";
const route = useRoute();
const items = computed<readonly MobileBottomNavItem[]>(() => [
  {
    id: "home",
    label: "Home",
    icon: "i-tabler-home",
    to: "/",
    active: route.path === "/",
  },
  { id: "create", label: "Create", icon: "i-tabler-plus" },
  {
    id: "inbox",
    label: "Inbox",
    icon: "i-tabler-mail",
    to: "/inbox",
    badge: 3,
    ariaLabel: "Inbox, 3 unread",
    active: route.path === "/inbox",
  },
]);
function select(item: MobileBottomNavItem) {
  if (item.id === "create") {
    /* Product opens its composer. */
  }
}
</script>
<template>
  <div class="flex min-h-dvh flex-col">
    <main class="flex-1"><slot /></main>
    <MobileBottomNav
      :items="items"
      label="Primary navigation"
      @select="select"
    />
  </div>
</template>
```

Use 3–5 short labels. Items with `to` are links; items without it are buttons.
`select` reports activation; the product owns action effects, active route matching,
login and permission filtering. Disabled items cannot activate. `hidden` or an empty
list removes both navigation and reservation. Supply meaningful `ariaLabel` for badges.

Below 768px the bar is 48px plus 1px border and safe area, with 20px Tabler icons and
11px labels. The spacer reserves its full height on SSR. Input focus hides navigation
without moving content. At 768px it hides and releases the reservation. This is a
compact mobile pattern, not a replacement for desktop navigation or same-page Tabs.

`--yueli-mobile-bottom-space` is available at document root while the navigation is
mounted; use `bottom: var(--yueli-mobile-bottom-space, 0px)` for sticky business actions.
Do not add another content padding or safe-area inset on top of the built-in spacer.
FeedbackToastRegion consumes the variable automatically; BackToTop discovers the bar
through its existing `data-y-dock` avoidance contract. Modal surfaces remain above the
bar and own focus. Input focus is an editing policy, not keyboard detection.

BVideo migrated from its local sample by replacing the component import and deleting
product-owned navigation CSS. The public dependency URL remains on the published
release until 0.4.0 is authorized and published; local validation uses the explicit
Workspace source overlay and an independent tarball consumer. Existing consumers
without MobileBottomNav retain their previous spacing and Toast placement.

### 权限申请与用户资料（本地候选）

`@yueli/ui/admin` 导出 `AuthorizationUser` 与 `AuthorizationApplication`。前者接收 subject/name/handle/avatarUrl/profileUrl/loading；后者接收 user、role、reason、createdAt、busy，并发出 review(approve|reject)。组件不请求身份或权限接口，不自行授权。消费者提供公开资料、Asset SDK URL、Account 主页及审批 Adapter。时间按 Asia/Shanghai 展示。新增导出将随下一版本发布，现有导出保持不变。

## 紧凑后台集合

`CollectionPanel` 默认紧凑网格与分页；`PageHeader` / `ManagePage` tools 插槽承载 `CollectionHeaderTools`。独立列表复用 `CollectionPaginationBar`，不复制页码计算。详见[规则与验收](../../../flightdeck/knowledge/frontend/compact-admin-collections.md)。

`CommentModerationCollection` 推荐显式启用 `layout="columns"`：作者、时间和正文为主列，来源、状态和横向更多菜单在桌面独立对齐；窄屏将后三项移到正文下方。该布局不展示来源缩略图，通过审核进入更多菜单，保留回复上下文、用户详情与批量操作。产品应传入完整状态（包括已通过）。Gallery 验收后已接入 Blog、Docs、BVideo；现有 `compact` / `table` 显式调用不变。部署使用固定候选包，不能把本地源码接入当成已发布正式 Release。

## 内容编辑工作台

`@yueli/ui/admin` 导出 `EditorCommandBar`，使用 `immersive`、`settingsOpen` 两个 model，以及 title/status/preview/lifecycle/actions 插槽。产品拥有保存、发布和权限；设置面板复用 `EditorInspector`。`CollectionPanel` 的 `editItem` 事件支持双击非交互区域进入完整编辑，独立表格可复用 `isCollectionEditGesture`。详见[交互与发布规则](../../../flightdeck/knowledge/frontend/editor-workbench.md)。

## Shared site launcher

`import { SiteLauncher } from "@yueli/ui/navigation/site-launcher"` exposes an independent Vue/Nuxt UI component. Nuxt consumers can use `YSiteLauncher`. The default three-column menu uses the nine entries in `yueliSites` and displays each site's published favicon in its original colors, and lists the Yueli contact links beneath the grid. For a custom menu, pass `items` with `id`, `name`, `url`, and either an `iconUrl` image or a bundled Tabler `icon` such as `home`, `book`, or `package`. The launcher supports keyboard navigation and light/dark surfaces. Preserve Foundation Tailwind/theme imports.

The Nav entry ships the unmodified `nav/web/public/favicon.svg` asset because its production HTTPS origin does not currently serve the SVG. If Nav updates this asset, update the bundled copy alongside it. Consumers with their own `items` control the icons and destinations of those entries.

## Pagination responsiveness

CollectionPagination and CollectionPaginationBar expose `layout="auto|compact|full"`; CollectionPanel and CollectionFooter forward `pagination-layout`. Default `auto` uses the pagination container width: at 24rem or below it shows previous, current/total and next; wider containers retain numbered pages. `compact` always uses the minimal controls, `full` retains numbered controls. CSS container queries preserve SSR markup and do not require browser width listeners. Existing `compact` on CollectionPagination controls desktop edge buttons; existing `compactPagination` on CollectionPanel chooses footer anatomy, not screen adaptation.

No consumer changes are needed for the default. Use `full` only when its containing layout can hold the numbered controls. Page-size selection remains available in CollectionPaginationBar; CollectionFooter preserves its existing page-size disclosure. Empty/single-page bars disable navigation; the standalone primitive remains hidden for one page unless `compact` requests persistent controls. The package is a local preview candidate, not a product dependency upgrade.

Remote arrays use `RemoteMultiSelect` (`YRemoteMultiSelect`), with the existing loader type and shared selected-item management. See [remote multi-select](src/remote-select/multi-select.md) for retained labels, IME-safe query scheduling, retry and adoption boundaries.

Static multi-level leaf selection uses `CollectionHierarchySelect` (`YCollectionHierarchySelect`). See [hierarchy selection](src/collection/hierarchy-select.md) for parent navigation, global path search and disabled inheritance.

Named filter snapshots use `CollectionFilterPresets` (`YCollectionFilterPresets`): save, restore, update and delete with consumer-owned async actions. See [filter presets](src/collection/filter-presets.md) for codec normalization, single apply and storage/permission boundaries.

NumericRangeFilter adds optional presets, draft/immediate apply, ceiling and native size/ui. See [numeric ranges](src/admin-platform/numeric-range.md); existing scalar boundaries and update/apply events remain.

日期范围：[CalendarDateRangeFilter](src/admin-platform/date-range.md)。

# 正式制品依赖门禁

消费者通过 Workspace `frontend sync --local <repository> --artifacts <directory>`
从 Repository Lock 生成 `vendor/frontend-baseline.json`，并锁定正式 tarball。
`node node_modules/@yueli/ui/src/discovery/dependencies.mjs --baseline vendor/frontend-baseline.json`
核验声明、产品 lock 引用及 SDK snapshot 依赖链、tarball 地址与完整性摘要、批准的 SHA-256，以及每个共享包自身解析到的实际版本与文件内容。
本地 sibling 源码不能作为正式制品放行；本地联调由 Workspace prepare/up 的解析门禁负责。
构建结束再次执行并带 `--receipt .output/frontend-dependencies.json`，为部署保留依赖回执。
部署仍须把该回执与 Workspace 当前批准基线和实际 Web 制品摘要对账；消费者自带快照不能自行批准新基线。

## Visual assets preview

The visual-assets preview adds configurable `VisualAssetField` and icon groups. See [usage and operations](src/admin/visual-asset-field.md). It retains the currently approved reading navigation `maxHeight` and `scrollbar` options, including keyboard scrolling. Existing consumers keep their default behavior.
