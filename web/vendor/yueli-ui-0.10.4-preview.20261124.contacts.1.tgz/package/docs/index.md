# UI 使用与选型文档

- [常用高级组件清单](advanced-components.md)：按场景选择现有能力，区分上游组件与候选封装，比较展示卡片效果。
- [发现与升级工具](ai-discovery.md)：版本识别、组件查询、MCP 与升级差异的详细参考。

使用与维护规则见 [AGENTS.md](../AGENTS.md)，安装与主题接入见 [README](../README.md)。
