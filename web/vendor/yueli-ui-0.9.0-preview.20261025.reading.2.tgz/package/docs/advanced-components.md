# 常用高级组件清单

本清单用于按场景选型，不是所有组件的完整 API。先按 [包指引](../AGENTS.md) 确认实际版本，再用 discovery 查询组件；状态由该版本 catalog 的 lifecycle 决定。下面“候选”没有公共导出，不能生成对应 import。

## 已有 Foundation 能力

表中为显式导出的名称。Nuxt 自动注册名称通常加 `Y` 前缀；以本版 module 与 discovery 为准。

| 场景 | 已有组件／入口 | 高级能力与采用边界 |
| --- | --- | --- |
| 搜索输入 | `MotionSearchInput` · `@yueli/ui/interaction` | 输入法组合态、防抖、回车提交、清空恢复焦点。组件发出 `search`，消费者发请求并处理过期响应。 |
| 保存／发布按钮 | `ActionFeedbackButton` · `@yueli/ui/feedback/pattern` | 原位动作状态；`enhanced` 可选稳定宽度和焦点增强。已有 `MotionActionFeedbackButton` 包装入口，先查用途与迁移，按实际需求采用。 |
| 集合搜索筛选排序 | `CollectionHeaderTools` · `@yueli/ui/collection/pattern` | 筛选草稿、取消／应用、容器自适应。消费者通过统一提交事件请求数据。 |
| 命名筛选方案 | `CollectionFilterPresets` · `@yueli/ui/collection/pattern` | 保存、恢复、覆盖和删除筛选方案，异步状态防重入；存储、权限和方案迁移由产品处理。 |
| 远程选择 | `RemoteSelect`、`RemoteMultiSelect` · `@yueli/ui/remote-select` | 远程加载与搜索；多选有取消旧请求、保留已选名称、失败重试及可选追加。静态选项继续使用适合的 Nuxt UI 选择组件。 |
| 分页 | `CollectionPagination`、`CollectionPaginationBar` · `@yueli/ui/collection/pattern` | 共享分页与紧凑布局，数据页码／总量由消费者提供。 |
| 选择与批量操作 | `CollectionSelectionBar` · `@yueli/ui/collection/pattern` | 选择数量、批量操作与可选 `enhanced` 行为；另有 `MotionCollectionSelectionBar` 入口。领域操作和选中数据仍由产品拥有。 |
| 集合状态区域 | `MotionCollectionRegion` · `@yueli/ui/interaction` | 加载、空态和错误切换、稳定骨架；工具栏和分页位于区域外。 |
| 附加字段折叠 | `MotionDisclosure` · `@yueli/ui/interaction` | 保留输入 DOM、焦点恢复、invalid 时展开，适合含草稿的低频附加表单。 |
| 工作流 Tabs | `AdminTabs` · `@yueli/ui/admin` | 统一后台工作流导航，支持原生 `ui` 和可选 `motion`；另有 `MotionAdminTabs` 入口。 |
| 行操作 | `AdminRowActions` · `@yueli/ui/admin` | 行操作集中呈现，按空间选择合适布局；链接沿用目标和 rel，适合表格与列表操作。 |
| 后台壳与指标卡 | `AdminConsoleLayout`、`AdminMetricCard` · `@yueli/ui/admin` | 复用控制台结构与指标展示；统计采集、计算和权限不属于指标卡。 |
| 设置页面 | `SettingsLayout` · `@yueli/ui/settings/pattern` | 共享设置页布局；配套 settings workflow 处理草稿、脏状态和保存边界。 |
| 全局错误反馈 | `FeedbackToastRegion` · `@yueli/ui/feedback/pattern` | 统一通知数量、位置和动效。操作成功优先用控件原位状态，按站群反馈规范选择载体。 |

例如查询搜索输入：

```sh
yueli-ui search "输入法搜索" --kind component --project <consumer-web> --json
yueli-ui docs component:MotionSearchInput --section api --project <consumer-web> --json
yueli-ui docs component:MotionSearchInput --section readme --project <consumer-web> --json
```

`Motion` 名称不表示比所有同类入口更新；先查询各入口的 active／deprecated 状态、增强参数与迁移，选择满足需求的规范入口。

## Nuxt UI 已有的高级基础

下面属于上游 Nuxt UI，不是 `@yueli/ui` 新增导出。能力以消费者所用版本为准；本轮核对的是 Nav 安装的 Nuxt UI 4.9.0。

| 场景 | 上游入口 | 复用方向 |
| --- | --- | --- |
| 通用内容面板 | `UCard` | 先用原生 slots、主题与 `ui` 配置统一边框、背景和间距。 |
| 展示／链接卡片 | `UPageCard` | 已有 `spotlight`、`spotlightColor`、`highlight`、`highlightColor`、布局和内容插槽。正式沉淀展示卡前优先验证这些基础。 |
| 文本输入 | `UInput` | 统一原生尺寸、图标、加载和字段外观；防抖、输入法等完整搜索行为可复用 Foundation 现有入口。 |
| 命令式搜索 | `UCommandPalette` | 可作为搜索面板的基础；跨来源请求、取消、权限与路由适配仍需按产品场景设计。 |

来源：[Nuxt UI 4.9.0 组件源码](https://github.com/nuxt/ui/tree/v4.9.0/src/runtime/components)、[PageCard](https://github.com/nuxt/ui/blob/v4.9.0/src/runtime/components/PageCard.vue)。

## 候选封装：尚未实现

| 建议名称／方向 | 值得共享的职责 | 沉淀前要验证 |
| --- | --- | --- |
| `ShowcaseCard`：展示卡片 | 基于 UPageCard 统一内容槽位、链接语义、品牌变体与动效策略 | Nav 分类卡与另一个真实站点是否能共用少量选项；保持键盘和触屏行为。 |
| 搜索输入的首页变体 | 在既有搜索行为上提供聚焦光晕、紧凑／首页外观 | 沿用现有输入法、防抖与 focus 合同，首页和工具栏分别验收；不新增重复搜索入口。 |
| `SearchPanel`：搜索面板 | 快捷键、焦点、结果分组、加载／空／失败状态 | 产品提供搜索 Adapter；明确取消请求、选择结果和返回焦点，跨站内容结构验证后再定 Interface。 |
| 品牌背景与精选区域 | 背景材质、色调、布局的少量可组合样式 | 背景色归主题，版式归组合组件；无需为单个渐变增加公开组件。 |

候选名称仅帮助讨论，未承诺最终命名或提供公共接口。新增能力先采用 Nuxt UI 现有机制；重复出现在真实消费者的交互复杂度再由 Foundation 封装。新组件的动效、减少动态效果、SSR、长内容、亮暗主题和实际 JS 成本需验证后才能推荐跨站采用。

## UPageCard 与当前 Nav 视觉的区别

两者不是“原生普通、定制高级”的等级关系：

| 维度 | UPageCard 4.9.0 | 当前 Nav 视觉版 |
| --- | --- | --- |
| 鼠标聚光 | 原生提供 spotlight，跟随相对位置 | Vue 更新相对坐标，CSS 绘制局部径向渐变 |
| 边框强调 | 原生 highlight、颜色与主题配置 | 页面定制细边框、分类色调与悬停表现 |
| 视觉完整性 | 提供可配置卡片基础 | 包含整页冷黑底、蓝绿背景、搜索光晕、分类图标色调、精选布局与入场效果 |
| 跨站职责 | 上游通用组件 | 当前仍是 Nav 局部实现，没有成为 Foundation 公共接口 |

本站当前观感主要来自配色、材质、排版与效果组合，不能据此判断原生机制做不到。推荐路线是保留认可的视觉设计，先验证用 UPageCard 承载可复用卡片机制，再由共享层补统一主题和交互约束。两者的聚光实现可能有不同视觉参数与事件成本，尚未做逐像素或性能对照，不宣称可以无差异直接替换。
