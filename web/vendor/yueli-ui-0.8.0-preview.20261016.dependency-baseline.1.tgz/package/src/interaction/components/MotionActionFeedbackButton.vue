<script setup lang="ts">
import { computed, useAttrs, ref, watch, nextTick } from "vue";
import ActionFeedbackButton from "../../feedback/ActionFeedbackButtonBase.vue";
import type { ActionFeedbackStatus } from "../../feedback/action";
defineOptions({ inheritAttrs: false });
const props = withDefaults(
  defineProps<{
    status?: ActionFeedbackStatus;
    idleLabel: string;
    pendingLabel: string;
    successLabel: string;
    errorLabel: string;
    motion?: boolean;
  }>(),
  { status: "idle", motion: true },
);
const emit = defineEmits<{ click: [event: MouseEvent] }>();
const states: ActionFeedbackStatus[] = ["idle", "pending", "success", "error"];
const root = ref<HTMLElement>();
let restoreFocus = false;
watch(
  () => props.status,
  async (status, previous) => {
    if (status === "pending")
      restoreFocus =
        root.value?.querySelector(":scope > button") === document.activeElement;
    else if (previous === "pending" && restoreFocus) {
      await nextTick();
      if (
        document.activeElement === document.body ||
        root.value?.contains(document.activeElement)
      )
        root.value
          ?.querySelector<HTMLButtonElement>(":scope > button")
          ?.focus({ preventScroll: true });
      restoreFocus = false;
    }
  },
);
const attrs = useAttrs();
function measurementAttrs() {
  const result = { ...attrs };
  for (const key of [
    "id",
    "name",
    "form",
    "autofocus",
    "aria-describedby",
    "aria-labelledby",
  ])
    delete result[key];
  return result;
}
const labels = computed(() => ({
  idleLabel: props.idleLabel,
  pendingLabel: props.pendingLabel,
  successLabel: props.successLabel,
  errorLabel: props.errorLabel,
}));
</script>
<template>
  <span
    ref="root"
    class="motion-action inline-grid align-middle"
    :data-motion="motion"
    :data-status="status"
  >
    <span
      v-for="state in states"
      :key="state"
      class="invisible col-start-1 row-start-1 pointer-events-none"
      aria-hidden="true"
      inert
    >
      <ActionFeedbackButton
        v-bind="{ ...measurementAttrs(), ...labels }"
        :status="state"
        disabled
        tabindex="-1"
        class="w-full"
      />
    </span>
    <ActionFeedbackButton
      v-bind="{ ...$attrs, ...labels }"
      :status="status"
      class="col-start-1 row-start-1 w-full"
      @click="emit('click', $event)"
    />
  </span>
</template>
<style scoped>
.motion-action[data-motion="true"][data-status="pending"]
  > :deep(button > [data-slot="label"]) {
  animation: action-pending 180ms ease-out;
}
.motion-action[data-motion="true"][data-status="success"]
  > :deep(button > [data-slot="label"]) {
  animation: action-success 180ms ease-out;
}
.motion-action[data-motion="true"][data-status="error"]
  > :deep(button > [data-slot="label"]) {
  animation: action-error 180ms ease-out;
}
@keyframes action-pending {
  from {
    opacity: 0.4;
    transform: translateY(0.15rem);
  }
}
@keyframes action-success {
  from {
    opacity: 0.4;
    transform: translateY(0.15rem);
  }
}
@keyframes action-error {
  from {
    opacity: 0.4;
    transform: translateY(0.15rem);
  }
}
@media (prefers-reduced-motion: reduce) {
  .motion-action[data-motion="true"][data-status]
    > :deep(button > [data-slot="label"]) {
    animation: none;
  }
}
</style>
