<script setup lang="ts">
defineProps<{ kind: 'home' | 'book' | 'package' }>();
</script>
<template>
 <svg viewBox="0 0 48 48" fill="none" aria-hidden="true" focusable="false">
  <template v-if="kind === 'home'">
   <path d="M8 21 24 7l16 14v18a3 3 0 0 1-3 3H11a3 3 0 0 1-3-3Z" fill="#4285F4" />
   <path d="m4 23 20-18 20 18-4 5L24 14 8 28Z" fill="#7C4DFF" />
   <rect x="19" y="28" width="10" height="14" rx="2" fill="#E8F0FE" />
   <rect x="11" y="25" width="5" height="6" rx="1" fill="#B7D3FF" />
   <rect x="32" y="25" width="5" height="6" rx="1" fill="#B7D3FF" />
  </template>
  <template v-else-if="kind === 'book'">
   <path d="M13 7h23a3 3 0 0 1 3 3v31H15a5 5 0 0 1-5-5V10a3 3 0 0 1 3-3Z" fill="#F9AB00" />
   <path d="M9 10h22a3 3 0 0 1 3 3v23H12a6 6 0 0 0-6 6V13a3 3 0 0 1 3-3Z" fill="#4285F4" />
   <path d="M12 36h22v6H12a3 3 0 0 1 0-6Z" fill="#E8F0FE" />
   <path d="M25 10v16l-4-3-4 3V10Z" fill="#34A853" />
   <path d="M14 30h12" stroke="#C5DAFF" stroke-width="2" stroke-linecap="round" />
  </template>
  <template v-else>
   <path d="m24 4 18 10v20L24 44 6 34V14Z" fill="#00A88F" />
   <path d="m24 4 18 10-18 10L6 14Z" fill="#4CD4B5" />
   <path d="M24 24v20l18-10V14Z" fill="#008C78" />
   <path d="m15 9 18 10v9l-6 3V22L9 12Z" fill="#D8FFF1" />
   <path d="m6 14 18 10 18-10M24 24v20" stroke="#007C70" stroke-width="1.5" stroke-linejoin="round" />
  </template>
 </svg>
</template>
