<script setup lang="ts">
import { ref } from 'vue';
import SiteLauncherIcon from './SiteLauncherIcon.vue';
import type { SiteLauncherItem } from '../site-directory';
withDefaults(defineProps<{ items: readonly SiteLauncherItem[]; label?: string }>(), { label: '月离网站' });
const open = ref(false);
</script>
<template>
 <UPopover v-model:open="open" :content="{ align: 'end', side: 'bottom', sideOffset: 8 }" :ui="{ content: 'max-w-[calc(100vw-2rem)] rounded-3xl border border-[var(--y-site-launcher-border)] bg-[var(--y-site-launcher-shell)] p-2 shadow-xl' }">
  <UTooltip :text="label"><UButton icon="i-tabler-grid-dots" :aria-label="label" color="neutral" variant="ghost" class="rounded-full" /></UTooltip>
  <template #content>
   <section data-site-launcher class="w-80 max-w-full rounded-2xl bg-[var(--y-site-launcher-surface)] p-3" :aria-label="label">
    <h2 class="px-2 pb-2 pt-1 text-base font-medium text-[var(--y-site-launcher-ink)]">{{ label }}</h2>
    <div class="grid max-h-80 grid-cols-3 gap-1 overflow-y-auto overscroll-contain">
     <a v-for="item in items" :key="item.id" :href="item.url" target="_blank" rel="noopener noreferrer" :aria-label="item.name" class="flex min-w-0 flex-col items-center gap-3 rounded-2xl px-2 py-4 text-center transition-colors hover:bg-[var(--y-site-launcher-hover)] focus-visible:bg-[var(--y-site-launcher-hover)] focus-visible:outline-2 focus-visible:outline-[var(--y-site-launcher-focus)]">
      <SiteLauncherIcon :kind="item.icon" class="size-11 shrink-0" />
      <span class="line-clamp-2 w-full break-words text-sm text-[var(--y-site-launcher-ink)]">{{ item.name }}</span>
     </a>
    </div>
   </section>
  </template>
 </UPopover>
</template>
