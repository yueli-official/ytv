#!/usr/bin/env node
// Shared build gate. Policy is a generated snapshot of the Workspace Repository
// Lock; no project configuration is executed and no dependency is installed.
import { readFile, realpath, mkdir, writeFile } from 'node:fs/promises';
import { resolve, dirname, relative, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { parseArgs } from 'node:util';
import { parseDocument } from 'yaml';
import semver from 'semver';
import { readArtifact } from './query.mjs';

const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const json = async file => JSON.parse(await readFile(file, 'utf8'));
const fail = message => { throw new Error(message); };

async function packageRoot(importer, name) {
  for (let dir = importer; ; dir = dirname(dir)) {
    const candidate = resolve(dir, 'node_modules', name);
    try { const root = await realpath(candidate); await readFile(resolve(root, 'package.json')); return root; }
    catch (error) { if (!['ENOENT','ENOTDIR'].includes(error.code)) throw error; }
    if (dirname(dir) === dir) fail(`${importer}: dependency ${name} is not installed`);
  }
}

export async function verifyDependencies({ project = '.', baseline, receipt } = {}) {
  project = await realpath(resolve(project));
  if (!baseline) fail('An approved frontend baseline is required');
  const policy = await json(resolve(project, baseline));
  if (policy.schemaVersion !== 1 || !/^[a-f0-9]{64}$/.test(policy.baselineSha256 || '') || !policy.packages || !Object.keys(policy.packages).length) fail('Invalid frontend baseline');
  const manifest = await json(resolve(project, 'package.json'));
  const lockBytes = await readFile(resolve(project, 'pnpm-lock.yaml'));
  const lockDocument = parseDocument(lockBytes.toString());
  if (lockDocument.errors.length) fail('Invalid pnpm lockfile');
  const lock = lockDocument.toJS();
  const importer = lock.importers?.['.'];
  if (!importer) fail('A standalone frozen product lockfile is required; source overlays cannot be released');
  const declared = { ...manifest.dependencies, ...manifest.devDependencies, ...manifest.optionalDependencies };
  const artifacts = new Map();
  for (const [name, expected] of Object.entries(policy.packages)) {
    if (!declared[name]) continue;
    if (!/^[a-f0-9]{64}$/.test(expected.sha256 || '') || !semver.valid(expected.version)) fail(`${name}: invalid approved identity`);
    const filename = `${name.slice(1).replaceAll('/', '-')}-${expected.version}.tgz`;
    const specifier = `file:vendor/${filename}`;
    if (declared[name] !== specifier) fail(`${name}: declared ${declared[name]}, expected ${specifier}`);
    const locked = importer.dependencies?.[name] || importer.devDependencies?.[name] || importer.optionalDependencies?.[name];
    if (locked?.specifier !== specifier) fail(`${name}: lockfile does not match the approved declaration`);
    const path = resolve(project, 'vendor', filename);
    if (hash(await readFile(path)) !== expected.sha256) fail(`${name}: approved artifact digest mismatch`);
    const artifact = await readArtifact(path, name);
    if (artifact.version !== expected.version || artifact.sha256 !== expected.sha256) fail(`${name}: approved artifact version/digest mismatch`);
    artifacts.set(name, artifact);
  }
  if (!artifacts.has('@yueli/ui')) fail('The approved @yueli/ui dependency is required');
  // Follow managed dependencies from their own real importer, including peers.
  // A correct product root cannot hide an old copy under a linked SDK/layer.
  const queue = [{ root: project, manifest, product: true }];
  const checked = new Set();
  const packages = {};
  while (queue.length) {
    const current = queue.shift();
    const dependencies = current.product ? declared : { ...current.manifest.dependencies, ...current.manifest.peerDependencies, ...current.manifest.optionalDependencies };
    for (const [name, range] of Object.entries(dependencies)) {
      if (!name.startsWith('@yueli/')) continue;
      if (!policy.packages[name]) fail(`${current.manifest.name}: ${name} is outside the approved baseline`);
      const artifact = artifacts.get(name);
      if (!artifact) fail(`${current.manifest.name}: add approved ${name} to the product's dependencies`);
      const root = await packageRoot(current.root, name);
      if (!root.replaceAll('\\','/').split('/').includes('node_modules')) fail(`${current.manifest.name}: ${name} resolves to source checkout ${root}; frozen artifact install required`);
      const installed = await json(resolve(root, 'package.json'));
      if (installed.name !== name || installed.version !== artifact.version) fail(`${current.manifest.name}: ${name} resolves to ${installed.version}, expected ${artifact.version}`);
      if (!current.product && semver.validRange(range) && !semver.satisfies(installed.version, range, { includePrerelease: true })) fail(`${current.manifest.name}: peer/dependency ${name}@${range} rejects approved ${installed.version}`);
      const identity = `${name}:${root}`;
      if (checked.has(identity)) continue;
      checked.add(identity);
      for (const field of ['exports','main','type','bin']) if (JSON.stringify(installed[field]) !== JSON.stringify(artifact.manifest[field])) fail(`${name}: installed ${field} differs from approved artifact`);
      for (const [file, bytes] of artifact.files) {
        if (file === 'package.json') continue; // pnpm may normalize metadata.
        const target = resolve(root, file), child = relative(root, target);
        if (child.startsWith('..') || isAbsolute(child)) fail(`${name}: invalid artifact path`);
        if (hash(await readFile(target)) !== hash(bytes)) fail(`${name}: installed content differs from approved artifact: ${file}`);
      }
      packages[name] = { version: artifact.version, sha256: artifact.sha256 };
      queue.push({ root, manifest: artifact.manifest, product: false });
    }
  }
  const result = { schemaVersion: 1, baselineSha256: policy.baselineSha256, packages,
    packageJsonSha256: hash(await readFile(resolve(project,'package.json'))), lockfileSha256: hash(lockBytes) };
  if (receipt) { const file = resolve(project,receipt); await mkdir(dirname(file),{recursive:true}); await writeFile(file,JSON.stringify(result,null,2)+'\n'); }
  return result;
}

if (process.argv[1] && await realpath(resolve(process.argv[1])) === await realpath(fileURLToPath(import.meta.url))) {
  try {
    const { values } = parseArgs({ options: { project: { type:'string' }, baseline: { type:'string' }, receipt: { type:'string' } } });
    const result = await verifyDependencies(values);
    console.log(`Frontend dependencies verified: ${Object.keys(result.packages).length} packages; baseline ${result.baselineSha256}`);
  } catch (error) { console.error(`Frontend release blocked: ${error.message}`); process.exitCode = 1; }
}
