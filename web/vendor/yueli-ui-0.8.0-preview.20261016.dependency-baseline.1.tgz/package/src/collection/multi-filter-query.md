# Multi-value collection filters

从 `interaction.9` 起，`CollectionHeaderTools` 与 `CollectionPanel` 支持增量 `multiControls` 和一次性的 `filterApply` 事件。现有 `controls`、`filters`（HeaderTools）和 `controlChange` 仍保持单值合同。新消费者使用 `filterApply` 提交混合条件，不同时监听旧事件发请求，以免重复提交。

```ts
import { createCollectionRouteQueryCodec } from '@yueli/ui/collection';
import { useVueRouterCollectionQuery } from '@yueli/ui/collection/vue-router';
import type { CollectionFilterApply } from '@yueli/ui/collection/pattern';

const codec = createCollectionRouteQueryCodec({
  boards: { kind: 'enum-set', values: ['blog', 'forum', 'docs'] as const, default: [] },
  status: { kind: 'enum', values: ['all', 'published', 'draft'] as const, default: 'all' },
  page: { kind: 'positive-integer', default: 1 },
});
const state = useVueRouterCollectionQuery({ router: useRouter(), codec });
async function apply(snapshot: CollectionFilterApply) {
  await state.replace(codec.parse({
    boards: (snapshot.multiValues.boards ?? []).map(String),
    status: String(snapshot.values.status ?? 'all'),
    page: '1',
  }));
  // Load once from normalized query, or let the host's existing query watcher do it.
}
```

`multiControls` 是 `CollectionMultiSelectControl[]`，每项提供稳定 `id`、`label`、数组 `value`、`options`、`placeholder` 和 `messages`；还可传 `disabled`、`visibleLimit`、`selectedFirst`、`searchFields`、`virtualize`。`options` 与消息配置见 [多选指南](multi-select.md)。`size` 由外层 HeaderTools/Panel 传给控件，仍使用原生 Nuxt UI。

```vue
<CollectionHeaderTools
  label="内容工具栏" search-placeholder="搜索内容…"
  :controls="singleControls" :multi-controls="multiControls"
  @filter-apply="apply"
/>
```

打开筛选时复制每个数组；取消、Escape 或点击外侧不改变已应用数据。再次打开从调用方当前值重新初始化，受控 `filtersOpen` 也遵循此约定。应用发出完整 `{ values, multiValues }` 快照，其中数组是新副本。无论改变多少个字段，新事件每次应用只发一次；请求时机仍由调用方拥有。应用后重置分页由消费者明确执行，组件不会推导业务字段名称。

## enum-set URL contract

- 稳定字符串 ID 使用重复参数：`?boards=blog&boards=forum`。单个字符串也接受。含逗号的 ID 是一个值，不按逗号拆分；URL 编解码由 Router 负责。
- `values` 必须是唯一、非空字符串集合，`default` 必须是其子集。输出按声明的 `values` 顺序排列，去掉重复和无效 ID；解析后的数组只读且冻结。
- 缺失参数使用默认集合。显式空字符串表示空集合；非空默认的清空会序列化为 `['']`，得到 `?boards=`。不能用空数组序列化，因为 Router 会省略该参数并恢复默认。
- 与规范化后的默认集合相同时省略参数。现有 Vue Router Adapter 保留不属于 codec 的查询参数；对新字段无需另写 URL Adapter。
- 此字段是白名单枚举集。远程、开放式 ID 集合需要消费者 codec，不能把未知 ID 静默加入枚举集；数字控件值在进入 URL 合同时显式转换成字符串。

这是增量配置，不要求旧单选消费者迁移。升级时 AI 先确认安装制品，再查询 `CollectionHeaderTools`／`CollectionPanel` 的 `multiControls`、`filterApply`，以及 `createCollectionRouteQueryCodec` 的 `enum-set` 合同。远程多选、自动层级级联与保存筛选方案不属于此合同。

## Filter container

`interaction.10` 起，HeaderTools/Panel 的 `filterPresentation` 默认 `auto`：屏幕达到 48rem 使用按钮旁的 Popover，较窄屏幕使用底部 Drawer。可指定 `popover`、`drawer`、`modal`；复杂筛选使用 `filterPresentation="modal"` 保留原中央弹窗。此为默认展示方式变化，查询与旧事件合同不变。排序弹窗保持现有方式。

公共 `CollectionFilterSurface` 也可独立导入，使用 `v-model:open`、`presentation`、`title`、`label`、原生 `size` 和 `body`／`footer` 插槽承载自定义筛选。它只负责容器、触发和关闭；调用方拥有草稿与应用逻辑。HeaderTools 共用同一套逻辑，因此改变展示配置不产生另一份筛选状态。

Popover 以可用视口空间限制宽高，字段区独立滚动，操作保持可见；Drawer 提供滚动字段区和底部安全区。原生容器负责键盘、Escape、外侧关闭、嵌套下拉和焦点返回。SSR 首次使用稳定按钮占位，挂载后判断视口，未执行服务器端 window 操作。打开期间保持当前容器，避免调整视口或修改配置时卸载正在编辑的字段；下次打开采用新的展示方式。没有根据字段数量猜测复杂度，请消费者明确选择。
