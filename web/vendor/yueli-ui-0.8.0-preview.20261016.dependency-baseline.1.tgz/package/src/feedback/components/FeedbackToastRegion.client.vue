<script setup lang="ts">
import "../feedback-surface.css";
import { useToast } from "@nuxt/ui/composables";
import { computed, onBeforeUnmount, reactive, watch } from "vue";
import { normalizeNuxtToastInput, type FeedbackNoticeAction, type NuxtToastInput } from "../notice";

interface ToastNotice extends NuxtToastInput {
  id: string | number;
  open?: boolean;
  _duplicate?: number;
}

const toast = useToast();
const props = withDefaults(defineProps<{ closeLabel?: string; actionPendingLabel?: string; actionFailureLabel?: string }>(), {
  closeLabel: "Close notification",
  actionPendingLabel: "Working…",
  actionFailureLabel: "Action failed. Try again.",
});
let mounted = true;
const busy = reactive(new Set<string | number>());
const failed = reactive(new Set<string | number>());
const drag = reactive({ id: undefined as string | number | undefined, pointer: -1, startX: 0, startY: 0, x: 0, width: 0, horizontal: false });
const timers = new Map<string | number, ReturnType<typeof setTimeout>>();
const signatures = new Map<string | number, string>();
const hovered = new Set<string | number>();
const focused = new Set<string | number>();
const notices = computed(() =>
  (toast.toasts.value as unknown as ToastNotice[])
    .filter((notice) => notice.open !== false)
    .slice(-3)
    .map((notice) => normalizeNuxtToastInput(notice)),
);

function clearTimer(id: string | number) {
  const timer = timers.get(id);
  if (timer) clearTimeout(timer);
  timers.delete(id);
}

function schedule(notice: ToastNotice) {
  clearTimer(notice.id);
  const duration = notice.duration ?? 3200;
  if (duration <= 0 || hovered.has(notice.id) || focused.has(notice.id) || busy.has(notice.id) || failed.has(notice.id) || drag.id === notice.id) return;
  timers.set(
    notice.id,
    setTimeout(() => toast.remove(notice.id), duration),
  );
}

watch(
  () =>
    notices.value
      .map(
        (notice) =>
          `${notice.id}:${notice.duration ?? 3200}:${notice._duplicate ?? 0}`,
      )
      .join("|"),
  () => {
    const visible = new Set(notices.value.map((notice) => notice.id));
    for (const id of signatures.keys()) if (!visible.has(id)) {
      clearTimer(id);
      signatures.delete(id);
      hovered.delete(id);
      focused.delete(id);
      busy.delete(id);
      failed.delete(id);
    }
    for (const notice of notices.value) {
      const signature = `${notice.duration}:${notice._duplicate ?? 0}`;
      if (signatures.get(notice.id) !== signature) {
        signatures.set(notice.id, signature);
        schedule(notice);
      }
    }
  },
  { immediate: true },
);

onBeforeUnmount(() => {
  mounted = false;
  for (const id of timers.keys()) clearTimer(id);
});

function pause(notice: ToastNotice, reason: "hover" | "focus") {
  (reason === "hover" ? hovered : focused).add(notice.id);
  clearTimer(notice.id);
}

function resume(notice: ToastNotice, reason: "hover" | "focus", event?: FocusEvent) {
  if (event?.relatedTarget instanceof Node && (event.currentTarget as HTMLElement)?.contains(event.relatedTarget)) return;
  (reason === "hover" ? hovered : focused).delete(notice.id);
  schedule(notice);
}

async function runAction(notice: ToastNotice, action: FeedbackNoticeAction, event: MouseEvent) {
  if (busy.has(notice.id)) return;
  busy.add(notice.id); failed.delete(notice.id); clearTimer(notice.id);
  try {
    await action.onClick(event);
    if (mounted) toast.remove(notice.id);
  } catch {
    if (mounted && notices.value.some(item => item.id === notice.id)) failed.add(notice.id);
  } finally { if (mounted) busy.delete(notice.id); }
}

function dragStart(notice: ToastNotice, event: PointerEvent) {
  if (!event.isPrimary || event.button !== 0 || (event.target as HTMLElement).closest("button,a,input") || busy.has(notice.id)) return;
  const element = event.currentTarget as HTMLElement;
  Object.assign(drag, { id: notice.id, pointer: event.pointerId, startX: event.clientX, startY: event.clientY, x: 0, width: element.getBoundingClientRect().width, horizontal: false });
  element.setPointerCapture(event.pointerId);
  clearTimer(notice.id);
}
function dragMove(event: PointerEvent) {
  if (drag.pointer !== event.pointerId) return;
  const x = event.clientX - drag.startX, y = event.clientY - drag.startY;
  if (!drag.horizontal && Math.abs(x) > 8 && Math.abs(x) > Math.abs(y) * 1.2) drag.horizontal = true;
  if (drag.horizontal) { drag.x = x; event.preventDefault(); }
}
function dragEnd(notice: ToastNotice, event: PointerEvent, cancelled = false) {
  if (drag.pointer !== event.pointerId) return;
  const dismiss = !cancelled && drag.horizontal && Math.abs(drag.x) >= Math.min(96, drag.width * 0.3);
  const element = event.currentTarget as HTMLElement;
  if (element.hasPointerCapture(event.pointerId)) element.releasePointerCapture(event.pointerId);
  Object.assign(drag, { id: undefined, pointer: -1, x: 0, horizontal: false });
  if (dismiss) toast.remove(notice.id); else schedule(notice);
}

function tone(notice: ToastNotice) {
  return notice.color ?? "neutral";
}

function role(notice: ToastNotice) {
  return notice.type === "foreground" ||
    tone(notice) === "error" ||
    tone(notice) === "warning"
    ? "alert"
    : "status";
}
</script>

<template>
  <Teleport to="body">
    <TransitionGroup
      tag="section"
      name="yueli-toast"
      class="yueli-toast-region"
      aria-label="通知"
    >
      <div
        v-for="notice in notices"
        :key="notice.id"
        class="yueli-toast-notice yueli-feedback-surface shadow-lg"
        :data-dragging="drag.id === notice.id && drag.horizontal"
        :style="drag.id === notice.id ? { '--toast-drag-x': `${drag.x}px`, opacity: 1 - Math.min(Math.abs(drag.x) / Math.max(drag.width, 1), 0.7) } : undefined"
        :data-tone="tone(notice)"
        :role="role(notice)"
        data-yueli-toast
        @pointerdown="dragStart(notice, $event)"
        @pointermove="dragMove"
        @pointerup="dragEnd(notice, $event)"
        @pointercancel="dragEnd(notice, $event, true)"
        @keydown.esc.stop="toast.remove(notice.id)"
        @mouseenter="pause(notice, 'hover')"
        @mouseleave="resume(notice, 'hover')"
        @focusin="pause(notice, 'focus')"
        @focusout="resume(notice, 'focus', $event)"
      >
        <span v-if="notice.icon" class="yueli-toast-icon yueli-feedback-icon" aria-hidden="true">
          <UIcon :name="notice.icon" class="size-5" />
        </span>
        <div class="min-w-0 flex-1">
          <p
            v-if="notice.title"
            class="line-clamp-2 text-sm font-semibold leading-5 text-highlighted"
          >
            {{ notice.title }}
          </p>
          <p
            v-if="notice.description"
            class="mt-0.5 line-clamp-2 text-xs leading-5 text-muted"
          >
            {{ notice.description }}
          </p>
          <div v-if="notice.actions?.length" class="mt-3 flex flex-wrap gap-2" data-toast-actions>
            <UButton v-for="(action, index) in notice.actions" :key="index" :label="busy.has(notice.id) ? props.actionPendingLabel : action.label" :icon="action.icon" :loading="busy.has(notice.id)" :disabled="busy.has(notice.id)" color="neutral" variant="outline" size="xs" @click="runAction(notice, action, $event)" />
          </div>
          <p v-if="failed.has(notice.id)" class="mt-2 text-xs text-error" role="alert">{{ props.actionFailureLabel }}</p>
        </div>
        <UButton
          icon="i-tabler-x"
          color="neutral"
          variant="ghost"
          size="xs"
          square
          :aria-label="props.closeLabel"
          class="-mr-1 -mt-1 shrink-0 text-dimmed"
          @click="toast.remove(notice.id)"
        />
      </div>
    </TransitionGroup>
  </Teleport>
</template>

<style scoped>
.yueli-toast-region {
  position: fixed;
  z-index: 110;
  bottom: calc(1rem + var(--yueli-mobile-bottom-space, 0rem));
  right: 1rem;
  display: flex;
  width: min(22rem, calc(100vw - 2rem));
  flex-direction: column;
  gap: 0.5rem;
  pointer-events: none;
}

.yueli-toast-notice {
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  padding: 0.75rem;
  border-radius: 1rem;
  box-shadow: var(--shadow-toast, var(--shadow-lg));
  touch-action: pan-y;
  transform: translateX(var(--toast-drag-x, 0rem));
  transition: transform 180ms var(--yueli-ease-out, ease-out), opacity 180ms ease-out;
  pointer-events: auto;
}

.yueli-toast-region[aria-hidden="true"] .yueli-toast-notice,
.yueli-toast-leave-active {
  pointer-events: none;
}

.yueli-toast-icon {
  width: 2rem;
  height: 2rem;
  padding: 0.375rem;
  border-radius: 0.625rem;
  flex: none;
  color: var(--ui-text-highlighted);
}

.yueli-toast-notice[data-tone="error"] .yueli-toast-icon {
  color: var(--ui-error);
}

.yueli-toast-notice[data-tone="warning"] .yueli-toast-icon {
  color: var(--ui-warning);
}

.yueli-toast-notice[data-tone="success"] .yueli-toast-icon {
  color: var(--ui-success);
}

.yueli-toast-notice[data-tone="info"] .yueli-toast-icon {
  color: var(--ui-info);
}

.yueli-toast-enter-active,
.yueli-toast-leave-active {
  transition:
    opacity 180ms var(--yueli-ease-out, ease-out),
    transform 180ms var(--yueli-ease-out, ease-out);
}

.yueli-toast-enter-from,
.yueli-toast-leave-to {
  opacity: 0;
  transform: translate(var(--toast-drag-x, 0rem), 0.5rem);
}

 .yueli-toast-notice[data-dragging="true"] { transition: none; user-select: none; }
@media (prefers-reduced-motion: reduce) {
  .yueli-toast-notice { transition: none; }
  .yueli-toast-enter-active,
  .yueli-toast-leave-active {
    transition: none;
  }
}
</style>

