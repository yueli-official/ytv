<script setup lang="ts">
import "../feedback-surface.css";
import { computed, ref, watch } from "vue";
import type { FeedbackTone } from "../notice";

const props = withDefaults(
  defineProps<{
    variant?: "plain" | "soft";
    tone?: FeedbackTone;
    title?: string;
    icon?: string;
    /** @deprecated Close buttons are always present; retained for source compatibility. */
    dismissible?: boolean;
    dismissLabel?: string;
  }>(),
  {
    variant: "plain",
    tone: "neutral",
    title: "",
    icon: "",
    dismissible: true,
    dismissLabel: "Close",
  },
);

const emit = defineEmits<{ dismiss: [] }>();
const visible = ref(true);
watch(() => [props.title, props.tone, props.variant], () => { visible.value = true; });
function dismiss() { visible.value = false; emit("dismiss"); }

const toneClass = computed(() => {
  if (props.tone === "error") return "text-error";
  if (props.tone === "warning") return "text-warning";
  if (props.tone === "success") return "text-success";
  if (props.tone === "info") return "text-info";
  return "text-muted";
});

const defaultIcon = computed(() => {
  if (props.tone === "error") return "i-tabler-alert-circle";
  if (props.tone === "warning") return "i-tabler-alert-triangle";
  if (props.tone === "success") return "i-tabler-circle-check";
  return "i-tabler-info-circle";
});
</script>

<template>
  <div
    v-if="visible"
    class="min-w-0 text-sm leading-5"
    :class="[toneClass, variant === 'soft' && 'yueli-feedback-surface rounded-xl p-4']"
    :role="tone === 'error' ? 'alert' : 'status'"
    :data-inline-status-variant="variant"
    :data-tone="tone"
  >
    <div class="flex min-w-0 items-start gap-2" data-inline-status-header>
      <div class="flex min-w-0 flex-1 items-center gap-2">
        <span class="flex shrink-0 items-center"
          :class="variant === 'soft' ? 'yueli-feedback-icon rounded-lg p-1.5' : 'h-5'" aria-hidden="true" data-inline-status-icon>
          <UIcon :name="icon || defaultIcon" class="size-4" />
        </span>
        <div class="min-w-0 flex-1 break-words" data-inline-status-content>
          <div v-if="title" class="font-semibold text-highlighted">{{ title }}</div>
          <slot v-else />
        </div>
      </div>
      <UButton
        size="xs" color="neutral" variant="ghost" icon="i-tabler-x" square
        :aria-label="dismissLabel" class="-my-1 shrink-0" data-inline-status-dismiss
        @click="dismiss"
      />
    </div>
    <div v-if="title" class="mt-1 min-w-0 break-words text-muted"
      :class="variant === 'soft' && 'pl-10'" data-inline-status-body><slot /></div>
    <div v-if="$slots.actions" class="mt-3 flex flex-wrap items-center gap-2"
      :class="variant === 'soft' && 'pl-10'" data-inline-status-actions><slot name="actions" /></div>
  </div>
</template>

