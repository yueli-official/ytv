export type PublicUiMaturity =
  "experimental" | "alpha" | "beta" | "stable" | "deprecated" | "removed";
export interface PublicUiLifecycle {
  readonly state: "active" | "deprecated" | "removed";
  readonly reason?: string;
  readonly deprecatedIn?: string;
  readonly removedIn?: string;
  readonly replacement?: {
    readonly entrypoint: `@yueli/ui/${string}`;
    readonly symbol?: string;
  };
  readonly migration?: string;
}
export interface PublicUiSymbolPolicy {
  readonly name: string;
  readonly lifecycle: PublicUiLifecycle;
  readonly canonicalEntrypoint?: `@yueli/ui/${string}`;
  /** Short purpose and adoption boundary, maintained beside lifecycle policy. */
  readonly description?: string;
  readonly aliases?: readonly string[];
  /** Package-relative maintained guides; defaults stay in component source. */
  readonly docs?: readonly string[];
}
export type PublicUiKind =
  "contract" | "headless-workflow" | "pattern" | "adapter";

export interface PublicUiManifestEntry {
  readonly id: string;
  readonly kind: PublicUiKind;
  readonly status: PublicUiMaturity;
  readonly entrypoint: `@yueli/ui/${string}`;
  readonly owner: "foundation";
  readonly responsibility: string;
  readonly nonResponsibilities: readonly string[];
  readonly runtimeDependencies: readonly string[];
  readonly replacement?: `@yueli/ui/${string}`;
  readonly removalVersion?: string;
  readonly lifecycle?: PublicUiLifecycle;
  readonly symbols?: readonly PublicUiSymbolPolicy[];
  readonly discovery?: {
    readonly aliases: readonly string[];
    readonly capabilities: readonly {
      readonly id: string;
      readonly supported: boolean;
      readonly contract?: string;
      readonly reason?: string;
      readonly introducedIn?: string;
    }[];
  };
  readonly evidence: {
    readonly docs: readonly string[];
    readonly tests: readonly string[];
    readonly consumers: readonly string[];
    readonly accessibility: readonly string[];
  };
}

export const publicUiManifest = [
  {
    id: "admin-platform",
    kind: "pattern", status: "experimental", entrypoint: "@yueli/ui/admin-platform", owner: "foundation",
    responsibility: "Shared admin composition, classification projections and validated numeric-range filtering with consumer-owned domain data.",
    nonResponsibilities: ["business HTTP", "persistence", "instant/timezone conversion"], runtimeDependencies: ["vue", "@nuxt/ui"],
    symbols: [{ name: "CalendarDateRangeFilter", description: "日历日期范围：含首尾、常用日期草稿或立即应用、错误焦点，时区参考日由消费者提供。", aliases: ["日期筛选", "最近7天", "更新日期", "date range"], docs: ["src/admin-platform/date-range.md"], lifecycle: {state:"active",migration:"interaction.15 新增，可选使用，不改既有数值范围。"} }, { name: "NumericRangeFilter", description: "数值区间筛选：手输上下限、常用范围草稿或即时应用、错误焦点与禁用；复用共享数值校验。", aliases: ["常用范围", "数值范围", "回复数量筛选", "numeric range"], docs: ["src/admin-platform/numeric-range.md"], lifecycle: {state: "active", migration: "interaction.14 增量 presets/presetApply/ceiling/disabled/size/ui 配置；默认快捷项不自动应用。只监听 apply 发请求，保留旧 update:modelValue 合同。"} }],
    evidence: { docs: ["src/admin-platform/numeric-range.md"], tests: ["test/numeric-range.test.ts", "scripts/test-pack.mjs"], consumers: ["js/apps/ui-lab"], accessibility: ["js/apps/ui-lab/test/e2e/numeric-range.spec.ts"] },
  },
  {
    id: "interaction-enhancements",
    symbols: [
      {
        name: "MotionActionFeedbackButton",
        description:
          "保存等异步动作的原位反馈；预留四种文案宽度并恢复焦点。请求由调用者处理。",
        aliases: ["保存按钮", "稳定宽度"],
        docs: ["src/interaction/README.md"],
        lifecycle: {
          state: "active",
          migration:
            "可保留此入口，或使用 ActionFeedbackButton enhanced；两者复用实现。四个状态文案须提供。",
        },
      },
      {
        name: "MotionAdminTabs",
        description:
          "内容工作流标签导航；只增强指示器过渡，选中外观用 ui 配置。",
        aliases: ["标签导航", "导航动效"],
        docs: ["src/interaction/README.md"],
        lifecycle: {
          state: "active",
          migration:
            "可保留此入口，或使用 AdminTabs motion；不改变 model 和导航项。",
        },
      },
      {
        name: "MotionCollectionSelectionBar",
        description:
          "选择后显示批量操作，隐藏时恢复焦点并可保留高度；操作与选择数据由调用者处理。",
        aliases: ["批量栏", "选择操作"],
        docs: ["src/interaction/README.md"],
        lifecycle: {
          state: "active",
          migration:
            "可保留此入口，或使用 CollectionSelectionBar enhanced。须持续挂载，不在外层按 count 条件卸载。",
        },
      },
      {
        name: "MotionCollectionActiveFilters",
        description:
          "可删除筛选标签，原位淡出并恢复相邻标签焦点；items 与删除结果由调用者维护。",
        aliases: ["筛选标签", "筛选动效"],
        docs: ["src/interaction/README.md"],
        lifecycle: {
          state: "active",
          migration:
            "可保留此入口，或使用 CollectionActiveFilters enhanced；保持稳定 key 与 remove/clear 数据更新。",
        },
      },
      {
        name: "MotionSearchInput",
        description:
          "支持输入法组合态、防抖查询和清空恢复焦点的搜索输入；不执行请求。",
        aliases: ["防抖搜索", "输入法搜索"],
        docs: ["src/interaction/README.md"],
        lifecycle: {
          state: "active",
          migration:
            "接入时用 search 事件触发请求，移除消费者重复的 debounce 和 model 请求监听，忽略过期响应。",
        },
      },
      {
        name: "MotionCollectionRegion",
        description:
          "集合内容的加载、空态与错误切换；骨架稳定显示，Toolbar 和分页保持在区域外。",
        aliases: ["集合加载", "稳定骨架"],
        docs: ["src/interaction/README.md"],
        lifecycle: {
          state: "active",
          migration:
            "仅包裹可替换内容，提供 empty/error 恢复入口；切换会卸载内容，不用于保存表单草稿。",
        },
      },
      {
        name: "MotionDisclosure",
        description:
          "低频附加字段折叠；保留输入 DOM，恢复焦点，并在 invalid 时展开。",
        aliases: ["折叠表单", "附加字段"],
        docs: ["src/interaction/README.md"],
        lifecycle: {
          state: "active",
          migration:
            "按表单需要采用；保留隐藏字段校验，由调用者提供 invalid，不默认隐藏关键字段。",
        },
      },
    ],
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/interaction",
    owner: "foundation",
    responsibility:
      "Provide opt-in motion-enhanced action feedback, tabs, selection bars, filter chips and IME-safe debounced search and stable collection loading transitions and draft-preserving disclosures.",
    nonResponsibilities: [
      "business requests",
      "selection persistence",
      "site migration",
    ],
    runtimeDependencies: ["vue", "@nuxt/ui", "tailwindcss"],
    discovery: {
      aliases: [
        "增强版",
        "动效",
        "motion",
        "状态按钮",
        "筛选标签",
        "批量操作",
        "增强搜索",
        "集合加载",
        "骨架屏",
        "内容切换",
        "折叠表单",
        "disclosure",
        "输入法",
        "debounce",
      ],
      capabilities: [
        {
          id: "reduced-motion",
          supported: true,
          reason:
            "All public interaction components expose motion; CSS respects prefers-reduced-motion.",
        },
        {
          id: "stable-action-width",
          supported: true,
          reason:
            "Required idle/pending/success/error labels reserve native button dimensions.",
        },
      ],
    },
    evidence: {
      docs: ["src/interaction/README.md"],
      tests: ["test/design-tokens.test.ts", "test/motion-search.test.ts"],
      consumers: ["ui-lab"],
      accessibility: [
        "prefers-reduced-motion",
        "native button/tab semantics",
        "focus restoration",
      ],
    },
  },
  {
    id: "site-launcher",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/navigation/site-launcher",
    owner: "foundation",
    responsibility:
      "Render an accessible fixed site grid with offline illustrations and light/dark surfaces.",
    nonResponsibilities: [
      "site registration",
      "product permissions",
      "directory persistence",
    ],
    runtimeDependencies: ["vue", "@nuxt/ui", "tailwindcss"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/design-tokens.test.ts"],
      consumers: ["distribution", "www"],
      accessibility: [
        "distribution/web/test/e2e/recommendations.acceptance.spec.ts",
      ],
    },
  },
  {
    id: "mobile-bottom-nav",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/navigation/mobile-bottom-nav",
    owner: "foundation",
    responsibility:
      "Own compact mobile navigation, safe-area reservation and shared floating-control avoidance.",
    nonResponsibilities: [
      "route matching",
      "authorization",
      "business actions",
    ],
    runtimeDependencies: ["vue", "@nuxt/ui", "tailwindcss"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/mobile-bottom-nav.test.ts", "scripts/test-pack.mjs"],
      consumers: ["bvideo"],
      accessibility: ["js/conformance/ui/test/e2e/mobile-bottom-nav.spec.ts"],
    },
  },
  {
    id: "theme",
    kind: "contract",
    status: "experimental",
    entrypoint: "@yueli/ui/theme",
    owner: "foundation",
    responsibility:
      "Own a provider-neutral Nuxt UI preset, deterministic local Tabler delivery and opt-in semantic light/dark surface tokens.",
    nonResponsibilities: [
      "application theme names",
      "product color registration",
      "runtime theme persistence",
      "locale catalogs",
    ],
    runtimeDependencies: [
      "@iconify-json/tabler",
      "@nuxt/icon",
      "@nuxt/ui",
      "tailwindcss",
    ],
    evidence: {
      docs: ["README.md"],
      tests: [
        "test/theme.test.ts",
        "test/icon-delivery.test.ts",
        "scripts/test-pack.mjs",
      ],
      consumers: ["js/conformance/ui"],
      accessibility: ["test/theme.test.ts"],
    },
  },
  {
    id: "image-policy",
    kind: "contract",
    status: "experimental",
    entrypoint: "@yueli/ui/image",
    owner: "foundation",
    responsibility:
      "Own bounded raster optimization decisions, resize geometry, cropper configuration, output naming and caller-translatable dimension violations.",
    nonResponsibilities: [
      "asset upload HTTP",
      "media storage",
      "visible cropper copy",
      "image CDN transformations",
    ],
    runtimeDependencies: [],
    evidence: {
      docs: ["README.md"],
      tests: ["test/image.test.ts", "scripts/test-pack.mjs"],
      consumers: ["js/conformance/ui"],
      accessibility: [],
    },
  },
  {
    id: "browser-image-optimization",
    kind: "adapter",
    status: "experimental",
    entrypoint: "@yueli/ui/image/browser",
    owner: "foundation",
    responsibility:
      "Apply the public image policy through a disposable browser decode/canvas/file runtime and report explicit fallback reasons.",
    nonResponsibilities: [
      "upload retries",
      "progress UI",
      "server-side transcoding",
      "cropper rendering",
    ],
    runtimeDependencies: [],
    evidence: {
      docs: ["README.md"],
      tests: ["test/image.test.ts", "scripts/test-pack.mjs"],
      consumers: ["js/conformance/ui"],
      accessibility: [],
    },
  },
  {
    id: "messages",
    kind: "contract",
    status: "experimental",
    entrypoint: "@yueli/ui/messages",
    owner: "foundation",
    responsibility:
      "Carry stable caller-resolved message keys and JSON-safe parameters.",
    nonResponsibilities: [
      "locale catalogs",
      "backend raw messages",
      "Nuxt i18n configuration",
    ],
    runtimeDependencies: [],
    evidence: {
      docs: ["README.md"],
      tests: [],
      consumers: ["js/conformance/ui"],
      accessibility: [],
    },
  },
  {
    id: "collection-workflow",
    discovery: {
      aliases: ["多值 URL", "数组查询", "重复参数"],
      capabilities: [
        {
          id: "enum-set-route-query",
          supported: true,
          introducedIn: "0.8.0-preview.20261010.interaction.9",
          contract: "CollectionRouteEnumSetField.kind",
          reason:
            "Repeated query keys represent a canonical whitelist set; explicit empty overrides survive router serialization.",
        },
      ],
    },
    kind: "headless-workflow",
    status: "experimental",
    entrypoint: "@yueli/ui/collection",
    owner: "foundation",
    responsibility:
      "Own remote collection load sequencing, route query normalization, query scope and cross-page selection invariants.",
    nonResponsibilities: [
      "business HTTP",
      "Vue rendering",
      "Nuxt UI primitives",
      "domain bulk actions",
    ],
    runtimeDependencies: [],
    evidence: {
      docs: ["README.md", "src/collection/multi-filter-query.md"],
      tests: [
        "test/collection-workflow.test.ts",
        "test/query-sync.test.ts",
        "js/conformance/ui/test/e2e/collection.spec.ts",
        "scripts/test-pack.mjs",
      ],
      consumers: [
        "js/conformance/ui",
        "yueli-official/platform/products/resource/web",
        "yueli-official/platform/products/blog/web",
      ],
      accessibility: ["js/conformance/ui/test/e2e/collection.spec.ts"],
    },
  },
  {
    id: "action-feedback",
    kind: "headless-workflow",
    status: "experimental",
    entrypoint: "@yueli/ui/feedback",
    owner: "foundation",
    responsibility:
      "Own latest-wins async action state, terminal reset timing, stable loading visibility, transport-neutral notice normalization and the application confirmation controller.",
    nonResponsibilities: [
      "business mutations",
      "locale catalogs",
      "global toast installation",
    ],
    runtimeDependencies: ["vue"],
    evidence: {
      docs: ["README.md"],
      tests: [
        "test/action-feedback.test.ts",
        "test/feedback-confirm.test.ts",
        "test/minimum-loading.test.ts",
        "test/feedback-notice.test.ts",
      ],
      consumers: ["js/conformance/ui"],
      accessibility: [],
    },
  },
  {
    id: "feedback-surfaces",
    symbols: [{name:"InlineStatus",description:"就近显示字段或区域状态；支持neutral/info/success/warning/error五种语义与plain/soft两种样式，标题正文分行，可关闭和追加操作。",aliases:["原地提示","局部错误","inline feedback"],docs:["src/feedback/feedback-standard.md"],lifecycle:{state:"active",migration:"feedback.2默认plain，soft使用共享浅色语义表面；关闭按钮始终显示并自隐藏，dismissible不再抑制关闭；成功优先使用ActionFeedbackButton。"}},{name:"FeedbackToastRegion",description:"右下角全局通知，最多三条；错误手动关闭，其他默认3200ms；悬停与键盘焦点暂停，无进度条。",aliases:["toast","浮动提示"],docs:["src/feedback/feedback-standard.md"],lifecycle:{state:"active",migration:"feedback.2浅色语义表面/浮层阴影，支持双向滑动、actions撤销/重试及异步失败恢复；错误duration强制0、close强制true，UApp禁用原生toaster仅保留一个Region。"}},{name:"UndoActionNotice",description:"可撤销操作提示：异步恢复防重复、失败重试，悬停和键盘焦点暂停到期；业务恢复由消费者提供。",aliases:["撤销操作","恢复归档","undo"],docs:["src/feedback/undo-action.md"],lifecycle:{state:"active",migration:"interaction.19 新增可选提示，不代替业务事务/回收站。durationMs默认8000，0持续；每次操作用新实例，恢复函数由消费者提供。"}}],
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/feedback/pattern",
    owner: "foundation",
    responsibility:
      "Own the shared application feedback root, bottom-right toast region and compact inline status surface across light/dark themes and caller-owned semantic palettes.",
    nonResponsibilities: [
      "business mutations",
      "locale catalogs",
      "product palette registration",
      "notification-center persistence",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: [
        "test/feedback-toast-region.test.ts",
        "test/inline-status.test.ts",
        "test/feedback-confirm.test.ts",
        "js/conformance/ui/test/e2e/collection.spec.ts",
        "scripts/test-pack.mjs",
      ],
      consumers: ["js/conformance/ui"],
      accessibility: [
        "test/inline-status.test.ts",
        "js/conformance/ui/test/e2e/collection.spec.ts",
      ],
    },
  },
  {
    id: "action-feedback-button",
    symbols: [
      {
        name: "ActionFeedbackButton",
        description:
          "保存、发布等动作的四状态按钮；enhanced 可选开启稳定宽度和焦点恢复。",
        aliases: ["保存按钮", "状态反馈"],
        docs: ["src/interaction/README.md"],
        lifecycle: {
          state: "active",
          migration:
            "interaction.6 起支持 enhanced，默认 false；无需改导入。motion 只控制动画，文案与请求由调用者拥有。",
        },
      },
    ],
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/feedback/pattern",
    owner: "foundation",
    responsibility:
      "Render a Nuxt UI action control whose label, icon, tone and live state remain coherent across idle, pending, success and error.",
    nonResponsibilities: [
      "executing mutations",
      "locale catalogs",
      "toast feedback",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md", "src/interaction/README.md"],
      tests: ["test/action-feedback-button.test.ts"],
      consumers: ["js/conformance/ui"],
      accessibility: ["test/action-feedback-button.test.ts"],
    },
  },
  {
    id: "back-to-top",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/navigation/back-to-top",
    owner: "foundation",
    responsibility:
      "Own scroll threshold, window or container scrolling, focus return, reduced motion and overlay/dock avoidance for one accessible floating control.",
    nonResponsibilities: [
      "page layout",
      "locale catalogs",
      "overlay state management",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/back-to-top.test.ts"],
      consumers: ["js/conformance/ui"],
      accessibility: ["test/back-to-top.test.ts"],
    },
  },
  {
    id: "reading-table-of-contents",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/navigation/table-of-contents",
    owner: "foundation",
    responsibility:
      "Own heading filtering, hierarchy, fragment navigation, active-section tracking and accessible visual states for in-page reading navigation.",
    nonResponsibilities: [
      "article rendering",
      "page column layout",
      "mobile disclosure placement",
      "product color values",
    ],
    runtimeDependencies: ["@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/reading-table-of-contents.test.ts"],
      consumers: ["docs/web", "blog/web"],
      accessibility: ["test/reading-table-of-contents.test.ts"],
    },
  },
  {
    id: "content-share-actions",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/sharing/content-share",
    owner: "foundation",
    responsibility:
      "Own bounded social targets, system sharing, resilient clipboard copying and original-action copy feedback for public content surfaces.",
    nonResponsibilities: [
      "popover placement",
      "page action layout",
      "content canonical URL policy",
      "locale catalogs",
    ],
    runtimeDependencies: ["@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/content-share-actions.test.ts"],
      consumers: ["blog/web", "docs/web"],
      accessibility: ["test/content-share-actions.test.ts"],
    },
  },
  {
    id: "account-menu-pattern",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/account-menu/pattern",
    owner: "foundation",
    responsibility:
      "Own provider-neutral identity fallback, account and appearance action grouping, inline/sidebar/collapsed trigger anatomy and the async logout command boundary.",
    nonResponsibilities: [
      "identity providers",
      "session state",
      "application navigation",
      "locale catalogs",
      "color-mode state or persistence",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/account-menu.test.ts", "scripts/test-pack.mjs"],
      consumers: ["js/conformance/ui"],
      accessibility: ["test/account-menu.test.ts"],
    },
  },
  {
    id: "admin-template",
    symbols: [
      {
        name: "AdminTabs",
        description:
          "后台工作流标签导航，支持原生 ui 样式配置与可选 motion 过渡。",
        aliases: ["标签导航", "导航样式"],
        docs: ["src/interaction/README.md"],
        lifecycle: {
          state: "active",
          migration:
            "interaction.6 起可设置 motion=true；默认关闭增强过渡，选中背景仍通过 ui.trigger 配置。",
        },
      },
    ],
    lifecycle: {
      state: "active",
      migration:
        "From 0.8.0-preview.20261009.ai-discovery.5, AdminRowActions defaults to auto. Review constrained action cells and menus. Set presentation='inline' to preserve fixed inline controls; keep accessible labels and existing callbacks. Validate narrow/wide containers, keyboard activation and disabled/loading actions.",
    },
    discovery: {
      aliases: [
        "行操作",
        "手机操作菜单",
        "自适应操作",
        "responsive row actions",
      ],
      capabilities: [
        {
          id: "container-responsive-row-actions",
          supported: true,
          introducedIn: "0.8.0-preview.20261009.ai-discovery.5",
          reason:
            "AdminRowActions.presentation exposes auto, inline and overflow; auto responds to action count and CSS container width.",
        },
      ],
    },
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/admin",
    owner: "foundation",
    responsibility:
      "Own the reusable admin-console shell, sidebar search/navigation, route bar, semantic canvas, page headers, tabbed surfaces, editor inspectors and collection-toolbar anatomy with caller-owned brand content, routes and domain data.",
    nonResponsibilities: [
      "business dashboard regions",
      "application routes",
      "authorization",
      "brand assets",
      "editor business fields or persistence",
      "locale catalogs",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md", "src/interaction/README.md"],
      tests: [
        "test/admin-navigation.test.ts",
        "test/admin-template.test.ts",
        "scripts/test-pack.mjs",
      ],
      consumers: [
        "js/apps/ui-lab",
        "js/conformance/ui",
        "yueli-official/blog/web",
        "yueli-official/docs/web",
        "yueli-official/identity/account",
      ],
      accessibility: ["test/admin-template.test.ts"],
    },
  },
  {
    id: "remote-select",
    symbols: [
      {
        name: "RemoteMultiSelect",
        description:
          "远程多选：防抖搜索、取消旧请求、跨搜索保留已选名称、加载反馈与失败重试、可选游标追加；复用共享多选摘要与已选管理。",
        aliases: ["远程多选", "异步多选", "远程分页", "加载更多", "cursor pagination", "remote multi select"],
        docs: ["src/remote-select/multi-select.md"],
        lifecycle: {
          state: "active",
          migration:
            "interaction.11 新增数组组件；不替换单值 RemoteSelect。由消费者提供 loader 和已保存名称 initialItems；interaction.16 可选 pagination 消费 nextCursor，业务查询/游标生成归消费者。",
        },
      },
    ],
    lifecycle: {
      state: "active",
      migration:
        "From 0.8.0-preview.20261009.ai-discovery.5, default rows use native Nuxt UI label/description/icon/selected indication. An explicit item slot still replaces the row. Prefer item-leading/item-label/item-description/item-trailing for partial customization; trailingIcon is decorative and does not create a separate action. Verify selection, keyboard and async cancellation.",
    },
    discovery: {
      aliases: [
        "远程选择器",
        "辅助标题",
        "下拉图标",
        "remote searchable select",
      ],
      capabilities: [
        { id: "cursor-pagination", supported: true, contract: "RemoteSelectLoadResult.nextCursor", introducedIn: "0.8.0-preview.20261010.interaction.16", reason: "Explicit RemoteMultiSelect.pagination only; request.cursor, first-page cache, append retry and stale response isolation. Single RemoteSelect ignores pagination." },
        {
          id: "description",
          supported: true,
          contract: "RemoteSelectOption.description",
        },
        {
          id: "leading-icon",
          supported: true,
          contract: "RemoteSelectOption.icon",
        },
        {
          id: "trailing-icon",
          supported: true,
          introducedIn: "0.8.0-preview.20261009.ai-discovery.5",
          contract: "RemoteSelectOption.trailingIcon",
          reason:
            "The item-trailing slot allows custom presentation; the icon is decorative, not a nested action.",
        },
        {
          id: "trailing-action",
          supported: false,
          reason:
            "Icons are decorative; option activation uses the native selection contract.",
        },
      ],
    },
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/remote-select",
    owner: "foundation",
    responsibility:
      "Own debounced, abortable, latest-wins remote option loading, per-instance query caching and retry around Nuxt UI SelectMenu.",
    nonResponsibilities: [
      "business HTTP clients",
      "local option filtering",
      "creating domain entities",
      "locale catalogs",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md", "src/remote-select/multi-select.md"],
      tests: ["test/remote-select.test.ts", "test/remote-multi.test.ts", "test/remote-page.test.ts", "scripts/test-pack.mjs"],
      consumers: ["js/apps/ui-lab", "js/conformance/ui"],
      accessibility: ["test/remote-select.test.ts", "js/apps/ui-lab/test/e2e/remote-pagination.spec.ts"],
    },
  },
  {
    id: "dashboard-patterns",
    lifecycle: {
      state: "deprecated",
      reason:
        "Legacy dashboard entrypoint. PageHeader and TabbedSurface share the active admin implementation; DashboardLayout requires explicit composition migration.",
      migration:
        "Import PageHeader and TabbedSurface from @yueli/ui/admin. Replace DashboardLayout with caller-owned regions composed with ManagePage/AdminOverview; there is no drop-in replacement.",
    },
    symbols: [
      {
        name: "DashboardLayout",
        lifecycle: {
          state: "deprecated",
          reason:
            "Legacy dashboard region layout duplicates the newer admin composition model.",
          migration:
            "Compose product-owned dashboard regions using ManagePage and AdminOverview; adapt region slots and messages explicitly.",
        },
      },
      {
        name: "PageHeader",
        canonicalEntrypoint: "@yueli/ui/admin",
        lifecycle: { state: "active" },
      },
      {
        name: "TabbedSurface",
        canonicalEntrypoint: "@yueli/ui/admin",
        lifecycle: { state: "active" },
      },
    ],
    kind: "pattern",
    status: "deprecated",
    entrypoint: "@yueli/ui/dashboard/pattern",
    owner: "foundation",
    responsibility:
      "Own responsive page-heading anatomy and the accessible decision order for caller-provided dashboard regions.",
    nonResponsibilities: [
      "business metrics",
      "business actions",
      "locale catalogs",
      "application navigation",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    replacement: "@yueli/ui/admin",
    evidence: {
      docs: ["README.md"],
      tests: ["test/dashboard-patterns.test.ts", "scripts/test-pack.mjs"],
      consumers: ["js/conformance/ui"],
      accessibility: ["test/dashboard-patterns.test.ts"],
    },
  },
  {
    id: "settings-workflow",
    kind: "headless-workflow",
    status: "experimental",
    entrypoint: "@yueli/ui/settings",
    owner: "foundation",
    responsibility:
      "Own JSON-safe settings baseline cloning, structural dirty comparison, capture, discard and revision semantics.",
    nonResponsibilities: [
      "business persistence",
      "Vue rendering",
      "browser navigation",
      "locale catalogs",
    ],
    runtimeDependencies: [],
    evidence: {
      docs: ["README.md"],
      tests: ["test/settings-workflow.test.ts", "scripts/test-pack.mjs"],
      consumers: ["js/conformance/ui"],
      accessibility: [],
    },
  },
  {
    id: "settings-adapters",
    kind: "adapter",
    status: "experimental",
    entrypoint: "@yueli/ui/settings/vue",
    owner: "foundation",
    responsibility:
      "Bind a caller-owned settings form to Vue reactivity and opt-in browser or Router leave protection.",
    nonResponsibilities: [
      "confirmation copy",
      "persistence",
      "route query semantics",
      "global window policy",
    ],
    runtimeDependencies: ["vue", "vue-router"],
    evidence: {
      docs: ["README.md"],
      tests: [
        "test/settings-vue.test.ts",
        "test/settings-browser.test.ts",
        "test/settings-vue-router.test.ts",
      ],
      consumers: ["js/conformance/ui"],
      accessibility: [],
    },
  },
  {
    id: "settings-patterns",
    symbols: [{name:"UnsavedChangesPrompt",description:"通用草稿离开确认：可请求继续编辑或放弃，复用beforeunload保护，保存中阻止离开。",aliases:["未保存保护","离开编辑","unsaved changes"],docs:["src/settings/unsaved-changes.md"],lifecycle:{state:"active",migration:"interaction.19 可选组件；消费者维护dirty/busy，requestLeave接到已有useSettingsLeaveGuard或标签/返回动作，成功保存才更新基线。"}}],
    discovery: {
      aliases: ["设置导航", "自适应设置", "responsive settings"],
      capabilities: [
        {
          id: "container-responsive-navigation",
          supported: true,
          introducedIn: "0.8.0-preview.20261009.ai-discovery.5",
          reason:
            "SettingsLayout uses container width for section dropdown, wrapping tabs and sidebar; navigationLayout keeps auto/sidebar/tabs choices.",
        },
      ],
    },
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/settings/pattern",
    owner: "foundation",
    responsibility:
      "Own responsive settings navigation, section anatomy and a safe-area-aware save lifecycle dock.",
    nonResponsibilities: [
      "settings fields",
      "business persistence",
      "permissions",
      "locale catalogs",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/settings-patterns.test.ts", "scripts/test-pack.mjs"],
      consumers: ["js/conformance/ui"],
      accessibility: ["test/settings-patterns.test.ts"],
    },
  },
  {
    id: "collection-frame",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/collection/pattern",
    owner: "foundation",
    responsibility:
      "Own the integrated collection frame anatomy, responsive controls disclosure, in-flow bulk region and accessible structural defaults.",
    nonResponsibilities: [
      "filter and sort semantics",
      "domain columns and items",
      "business actions",
      "pagination primitives",
      "translated copy",
      "data-table column sizing and alignment owned by Nuxt UI Table",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md", "src/interaction/README.md"],
      tests: [
        "js/conformance/ui/test/e2e/collection.spec.ts",
        "scripts/test-pack.mjs",
      ],
      consumers: ["js/conformance/ui"],
      accessibility: ["js/conformance/ui/test/e2e/collection.spec.ts"],
    },
  },
  {
    id: "collection-table-toolbar",
    symbols: [
      {
        name: "CollectionToolbar",
        lifecycle: {
          state: "deprecated",
          deprecatedIn: "0.8.0-preview.20261009.ai-discovery.2",
          reason:
            "Legacy wrapping filter layout and openFilters event overlap the canonical collection toolbar but do not satisfy the current toolbar anatomy and caller-owned copy contract.",
          replacement: {
            entrypoint: "@yueli/ui/collection/pattern",
            symbol: "CollectionTableToolbar",
          },
          migration:
            "Migrate to CollectionTableToolbar: adapt required label/filterLabel, filter popover slots, search submission and IME handling; do not rename the import without adapting the event contract.",
        },
      },
    ],
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/collection/pattern",
    owner: "foundation",
    responsibility:
      "Own one responsive default toolbar, stable filter popover and in-place selection mode around a caller-owned Nuxt UI Table.",
    nonResponsibilities: [
      "data-table rendering and column alignment",
      "filter and sort semantics",
      "business bulk actions",
      "business HTTP",
      "locale catalogs",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md", "src/collection/toolbar-standard.md"],
      tests: ["test/collection-table-toolbar.test.ts", "scripts/test-pack.mjs"],
      consumers: ["yueli-official/platform/products/docs/web"],
      accessibility: ["test/collection-table-toolbar.test.ts"],
    },
  },
  {
    id: "collection-pagination",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/collection/pattern",
    owner: "foundation",
    responsibility:
      "Own container-responsive pagination: auto switches to previous/status/next at 24rem, compact always minimizes controls, full retains numbered pages.",
    nonResponsibilities: [
      "server query",
      "total record calculation",
      "product dependency upgrades",
    ],
    runtimeDependencies: ["vue", "@nuxt/ui"],
    discovery: {
      aliases: [
        "分页",
        "手机分页",
        "自适应分页",
        "responsive pagination",
        "pagination layout",
      ],
      capabilities: [
        {
          id: "container-responsive-pagination",
          supported: true,
          introducedIn: "0.8.0-preview.20261009.ai-discovery.3",
          reason:
            "CollectionPagination.layout and CollectionPanel.paginationLayout expose auto/compact/full; the default uses CSS container queries.",
        },
      ],
    },
    evidence: {
      docs: ["README.md"],
      tests: ["scripts/test-pack.mjs", "test/design-tokens.test.ts"],
      consumers: ["js/conformance/ui"],
      accessibility: ["scripts/test-pack.mjs"],
    },
  },
  {
    id: "collection-panel",
    symbols: [
      {
        name: "CollectionFilterSurface",
        lifecycle: {
          state: "active",
          migration:
            "interaction.10 新增可复用筛选容器；auto 为宽屏 Popover／窄屏 Drawer，复杂筛选指定 modal。",
        },
        description:
          "筛选容器按配置展示为 Popover、底部抽屉或 Modal，复用 body/footer 插槽及原生焦点与关闭行为。",
        aliases: ["筛选容器", "自适应筛选", "筛选抽屉", "popover filter"],
        docs: ["src/collection/multi-filter-query.md"],
      },
      {
        name: "CollectionHeaderTools",
        lifecycle: {
          state: "active",
          migration:
            "interaction.9 增加 multiControls/filterApply；interaction.10 默认 auto 筛选容器，复杂条件可指定 filterPresentation=modal。新消费者仅监听 filterApply 发请求。",
        },
        description:
          "统一集合搜索、筛选和排序；单选与多选先编辑草稿，取消丢弃，应用一次提交完整条件。",
        aliases: ["混合筛选", "多选面板", "应用筛选"],
        docs: ["src/collection/multi-filter-query.md"],
      },
      {
        name: "CollectionPanel",
        lifecycle: {
          state: "active",
          migration:
            "interaction.9 支持 multiControls/filterApply；interaction.10 转发 filterPresentation，默认 auto，modal 保留原展示。controlChange 单值合同不变。",
        },
        description:
          "集合行／网格、加载状态、分页及共享工具栏；支持增量多项筛选配置和一次性应用事件。",
        aliases: ["集合多选筛选"],
        docs: ["src/collection/multi-filter-query.md"],
      },
      {
        name: "CollectionFilterPresets",
        description: "保存、恢复、覆盖和删除命名筛选方案；异步操作防重复提交，失败原地重试，存储与权限由消费者拥有。",
        aliases: ["筛选方案", "常用筛选", "saved filters", "filter presets"],
        docs: ["src/collection/filter-presets.md"],
        lifecycle: { state: "active", migration: "interaction.13 增量组件，不自动读写存储或监听查询。消费者 Adapter 实现一次应用，使用独立筛选 codec 排除分页及无关 URL，按产品用户与合同版本隔离持久化。" },
      },
      {
        name: "CollectionHierarchySelect",
        description:
          "多级选择：逐层导航、返回上级和根级、全树叶节点路径搜索；多选叶节点，父节点只导航；可选本组全选、部分状态和可点击祖先路径。",
        aliases: ["多级选择", "层级筛选", "本组全选", "父子选择", "部分选择", "面包屑导航", "定位已选项", "breadcrumb navigation", "hierarchy select"],
        docs: ["src/collection/hierarchy-select.md"],
        lifecycle: {
          state: "active",
          migration:
            "interaction.12 增量组件，数组叶节点 ID；唯一 ID 的静态树，父节点导航，禁用继承。现有平铺多选不必替换；interaction.17 可选 groupSelection 明确选择可用后代；interaction.18 breadcrumbs=true 可点击祖先路径，默认false；interaction.20 当前层级不重复祖先描述、标题只出现一次、组状态同行；全树搜索及已选定位保留路径；导航不改选择、不自动应用，不代表远程未知后代。",
        },
      },
      {
        name: "CollectionMultiSelect",
        description:
          "多项筛选：连续选择、标题与路径搜索、数量摘要、折叠已选项与键盘移除；基于 Nuxt UI 原生多选。",
        aliases: [
          "多选筛选",
          "多项筛选",
          "多 items",
          "路径搜索",
          "multi select",
        ],
        docs: ["src/collection/multi-select.md"],
        lifecycle: {
          state: "active",
          migration:
            "interaction.8 新增独立组件；数组 v-model，不替换既有单选 CollectionControl。消费者负责数组查询、空选择语义及请求。",
        },
      },
      {
        name: "CollectionActiveFilters",
        description:
          "显示已应用的筛选，可移除单项或清空；enhanced 可选开启过渡和焦点恢复。",
        aliases: ["筛选标签"],
        docs: ["src/interaction/README.md"],
        lifecycle: {
          state: "active",
          migration:
            "interaction.6 起支持 enhanced，默认 false；保持 items 的稳定 key，remove/clear 后由消费者更新数据。",
        },
      },
      {
        name: "CollectionSelectionBar",
        description:
          "展示所选数量和批量操作；enhanced 可选开启进出、占位和焦点恢复。",
        aliases: ["批量栏"],
        docs: ["src/interaction/README.md"],
        lifecycle: {
          state: "active",
          migration:
            "interaction.6 起支持 enhanced，默认 false；开启后须持续挂载，可关闭 reserveSpace，外层注意重复边框与内边距。",
        },
      },
    ],
    discovery: {
      aliases: [
        "集合面板",
        "搜索筛选",
        "多级选择器",
        "版块筛选",
        "collection controls",
        "searchable select",
      ],
      capabilities: [
        {
          id: "option-label",
          supported: true,
          contract: "CollectionControlOption.label",
        },
        {
          id: "leading-icon",
          supported: true,
          contract: "CollectionControlOption.icon",
        },
        {
          id: "description",
          supported: true,
          introducedIn: "0.8.0-preview.20261009.ai-discovery.5",
          contract: "CollectionControlOption.description",
        },
        {
          id: "trailing-icon",
          supported: true,
          introducedIn: "0.8.0-preview.20261009.ai-discovery.5",
          contract: "CollectionControlOption.trailingIcon",
          reason:
            "The icon is decorative; activation uses native option selection.",
        },
        {
          id: "trailing-action",
          supported: false,
          reason:
            "The public option contract does not expose an action, event or focus contract.",
        },
      ],
    },
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/collection/pattern",
    owner: "foundation",
    responsibility:
      "Own complete responsive search, configured controls, in-flow selection and bulk actions, loading/error/empty states, row/grid containers and pagination for remote collections.",
    nonResponsibilities: [
      "business HTTP",
      "domain item fields",
      "strict data-table column alignment",
      "business bulk actions",
      "locale catalogs",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md", "src/interaction/README.md"],
      tests: [
        "test/collection-panel.test.ts",
        "js/conformance/ui/test/e2e/collection.spec.ts",
        "scripts/test-pack.mjs",
      ],
      consumers: ["js/conformance/ui", "js/apps/ui-lab"],
      accessibility: ["js/conformance/ui/test/e2e/collection.spec.ts"],
    },
  },
  {
    id: "collection-vue-adapter",
    kind: "adapter",
    status: "experimental",
    entrypoint: "@yueli/ui/collection/vue",
    owner: "foundation",
    responsibility:
      "Bind a client-mounted collection Workflow to Vue setup lifecycle, reactive snapshots and data-query invalidation.",
    nonResponsibilities: [
      "SSR data fetching",
      "business HTTP",
      "search input policy",
      "Vue rendering",
      "domain feedback",
    ],
    runtimeDependencies: ["vue"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/vue-collection-workflow.test.ts", "scripts/test-pack.mjs"],
      consumers: [
        "js/conformance/ui",
        "yueli-official/platform/products/resource/web",
        "yueli-official/platform/products/blog/web",
      ],
      accessibility: [],
    },
  },
  {
    id: "collection-vue-router-adapter",
    kind: "adapter",
    status: "experimental",
    entrypoint: "@yueli/ui/collection/vue-router",
    owner: "foundation",
    responsibility:
      "Synchronize an owned collection query subset with Vue Router while preserving unrelated query keys.",
    nonResponsibilities: [
      "query semantics",
      "business HTTP",
      "route registration",
    ],
    runtimeDependencies: ["vue", "vue-router"],
    evidence: {
      docs: ["README.md"],
      tests: [
        "test/vue-router-query-sync.test.ts",
        "js/conformance/ui/test/e2e/collection.spec.ts",
        "scripts/test-pack.mjs",
      ],
      consumers: [
        "js/conformance/ui",
        "yueli-official/platform/products/resource/web",
        "yueli-official/platform/products/blog/web",
      ],
      accessibility: [],
    },
  },
] as const satisfies readonly PublicUiManifestEntry[];
