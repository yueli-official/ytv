# AI discovery and upgrade tools

The package includes a read-only Node CLI, JSON catalog and stdio MCP adapter.
Use Node 24.18.x. No Vue instance or Nuxt server is needed for discovery.

```sh
node node_modules/@yueli/ui/src/discovery/cli.mjs inspect --project . --json
node node_modules/@yueli/ui/src/discovery/cli.mjs search "多级选择器" --project . --json
node node_modules/@yueli/ui/src/discovery/cli.mjs docs collection-panel --project . --section api --json
node node_modules/@yueli/ui/src/discovery/cli.mjs upgrade-plan --project . --target /absolute/path/to/target-package --json
```

After installation the `yueli-ui` package bin provides the same commands.
`--project` refers to the directory containing the consumer package.json, often
`web/` in a product repository. The Foundation checkout can be queried with
`--project js/packages/ui`. Search supports `--capability`, `--limit` (0–20)
and `--offset`. Docs supports `usage`, `api`, `readme`, `migration` with bounded
character pagination (default 6000, maximum 12000).

## Identity and documents

`inspect` distinguishes declared specifiers, the matching pnpm importer, locked
tarball version/checksum/integrity, actual package path/version, source junctions
and Git source revision/dirty state. Normal pnpm store links are installed packages,
not automatically source overlays. Installed files can be compared with a local
locked tarball. This is local evidence, not a claim of release attestation.

Nuxt/Vite configuration is not executed. Projects containing such configuration
are reported with unknown final runtime resolution, even when filesystem package
resolution is known. There is no silent fallback to Foundation source or latest docs.
Old packages without a catalog return `catalog_unavailable`.

Package SemVer identifies the edition; schemaVersion identifies the catalog format.
Module IDs come from `publicUiManifest`. API summaries are generated using the
TypeScript AST and Vue macros/static template slots; inferred variable types and
dynamic slots may require source inspection and are not claimed as complete types.
Capabilities require public API evidence. Missing historical introducedIn versions
remain absent rather than guessed. Unsupported capabilities remain searchable.

Catalog content SHA and source hashes bind documentation to the package contents.
They detect drift, not provenance signatures. Final tarball SHA belongs to the
external release manifest, not inside the tarball itself.

## Upgrade behavior and migration

This candidate adds discovery exports and CLI tooling, component lifecycle records,
and responsive UI contracts. Existing exports remain available, but default behavior
can change: pagination uses a compact layout in narrow containers, AdminRowActions
defaults to auto, and settings navigation responds to container width. Review the
target catalog's migration sections rather than treating a higher version as a
drop-in update. Option descriptions and leading/trailing icons use native Nuxt UI
selection anatomy; decorative right icons do not create an independent action.
Explicit inline/full layout choices preserve those requested presentations.
Discovery requires a package containing the generated catalog; it does not add
documentation or new behavior to earlier installed packages.

`upgrade-plan` requires an explicit target package directory or `.tgz` tarball. Tarballs
are read and checked without extracting or executing their contents. It compares public
API and capability snapshots, package channels and peer dependency ranges. Results
are dry-run only: no install, file edits, commit, push or release. A directory is a
candidate, not proof of a published artifact; the result requires an explicit
tarball and release checksum before applying a product dependency update.
Legacy packages without catalogs receive a manual-baseline plan with API comparison
marked unavailable; they never borrow the target API as their current documentation.
Source/runtime ambiguity requires selecting a baseline first. Same-version catalog
changes are an integrity conflict. API changes always need review; generated diffs
are not automatically classified as safe migrations or executable codemods.

## MCP and AI guidance

Configure a stdio MCP client with command `node`, args containing the absolute
path to `src/discovery/cli.mjs` and `mcp`. The process opens no network port.
Tools `inspect`, `search`, `docs`, `upgrade-plan` call the same query handlers as the
CLI. The server supports protocol versions 2025-11-25 and 2025-06-18, validates
inputs and returns matching JSON as structured content and text.

`ai/llms.txt` is a compact module index. `ai/SKILL.md` provides generated usage
guidance; it is distributed as package content, not installed globally. Both are
generated from the same model as `ai/catalog.json`.

## Maintaining the catalog

Edit `src/manifest.ts` for IDs, purpose, aliases and verified capability metadata.
Edit public types/components for API contracts, and this guide for tool migration
semantics. Run `pnpm --filter @yueli/ui generate:discovery` after source edits.
`prepack` regenerates the catalog so every packed package carries its edition.
Generated `ai/` files are ignored locally and included in the tarball.
Run `test:discovery`, package typecheck and `test:pack` for the public boundary.

## 组件生命周期与重复入口

包 SemVer 是升级版本依据；组件采用稳定 ID，不维护独立 SemVer。成熟度（experimental/beta/stable）和生命周期是不同维度。

- active：正常推荐使用。
- deprecated：实现仍可用，新代码应选择替代入口，已有代码按 migration 迁移。
- removed：已无公共导出，保留墓碑和 removedIn，禁止生成 import。

生命周期由 src/manifest.ts 维护；AI 目录由源码生成，不另维护第二份登记表。未知弃用日期/移除版本为 null，不推测，不按时间自动过期。已声明移除版本但仍保留导出时 removalOverdue 会提示合同逾期。

```sh
yueli-ui search PageHeader --kind component --project <consumer> --json
yueli-ui search "" --kind component --lifecycle deprecated --project <consumer> --json
yueli-ui docs component:CollectionToolbar --section migration --project <consumer> --json
```

默认搜索只返回 active；审计用 --lifecycle all。模块返回各组件的独立生命周期，不能因模块可用就假定全部符号可用。组件按物理源文件归并多个导出，提供 canonical entrypoint、exports 和实际 props/emits/slots 文档；同源重导出不是重复实现。旧包未生成组件目录时，不使用新版目录补齐历史事实。
