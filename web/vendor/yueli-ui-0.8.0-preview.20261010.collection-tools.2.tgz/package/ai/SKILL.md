---
name: yueli-ui-discovery
description: Inspect actual Yueli UI dependencies, search public modules, read matching docs, and prepare a read-only upgrade plan.
---

First run yueli-ui inspect --project <package-root> --json. Distinguish source overrides from locked artifacts.
Search with yueli-ui search <intent> --project <package-root> --json --limit 5.
Read yueli-ui docs <module-id> --project <package-root> --section api --json; never substitute latest docs when unavailable.
Default search excludes deprecated/removed entries. Use --kind component for source-deduplicated components; audit with --lifecycle all. Read lifecycle.reason/replacement/migration before choosing an import. Never import removed entries.
Use yueli-ui upgrade-plan --project <package-root> --target <explicit-package-directory> --json. It does not install, commit or publish.
For MCP use yueli-ui mcp; all tools share the CLI query implementation.
