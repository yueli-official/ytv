export type PublicUiMaturity =
  "experimental" | "alpha" | "beta" | "stable" | "deprecated" | "removed";
export interface PublicUiLifecycle {
  readonly state: "active" | "deprecated" | "removed";
  readonly reason?: string;
  readonly deprecatedIn?: string;
  readonly removedIn?: string;
  readonly replacement?: {
    readonly entrypoint: `@yueli/ui/${string}`;
    readonly symbol?: string;
  };
  readonly migration?: string;
}
export interface PublicUiSymbolPolicy {
  readonly name: string;
  readonly lifecycle: PublicUiLifecycle;
  readonly canonicalEntrypoint?: `@yueli/ui/${string}`;
}
export type PublicUiKind =
  "contract" | "headless-workflow" | "pattern" | "adapter";

export interface PublicUiManifestEntry {
  readonly id: string;
  readonly kind: PublicUiKind;
  readonly status: PublicUiMaturity;
  readonly entrypoint: `@yueli/ui/${string}`;
  readonly owner: "foundation";
  readonly responsibility: string;
  readonly nonResponsibilities: readonly string[];
  readonly runtimeDependencies: readonly string[];
  readonly replacement?: `@yueli/ui/${string}`;
  readonly removalVersion?: string;
  readonly lifecycle?: PublicUiLifecycle;
  readonly symbols?: readonly PublicUiSymbolPolicy[];
  readonly discovery?: {
    readonly aliases: readonly string[];
    readonly capabilities: readonly {
      readonly id: string;
      readonly supported: boolean;
      readonly contract?: string;
      readonly reason?: string;
      readonly introducedIn?: string;
    }[];
  };
  readonly evidence: {
    readonly docs: readonly string[];
    readonly tests: readonly string[];
    readonly consumers: readonly string[];
    readonly accessibility: readonly string[];
  };
}

export const publicUiManifest = [
  {
    id: "site-launcher",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/navigation/site-launcher",
    owner: "foundation",
    responsibility:
      "Render an accessible fixed site grid with offline illustrations and light/dark surfaces.",
    nonResponsibilities: [
      "site registration",
      "product permissions",
      "directory persistence",
    ],
    runtimeDependencies: ["vue", "@nuxt/ui", "tailwindcss"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/design-tokens.test.ts"],
      consumers: ["distribution", "www"],
      accessibility: [
        "distribution/web/test/e2e/recommendations.acceptance.spec.ts",
      ],
    },
  },
  {
    id: "mobile-bottom-nav",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/navigation/mobile-bottom-nav",
    owner: "foundation",
    responsibility:
      "Own compact mobile navigation, safe-area reservation and shared floating-control avoidance.",
    nonResponsibilities: [
      "route matching",
      "authorization",
      "business actions",
    ],
    runtimeDependencies: ["vue", "@nuxt/ui", "tailwindcss"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/mobile-bottom-nav.test.ts", "scripts/test-pack.mjs"],
      consumers: ["bvideo"],
      accessibility: ["js/conformance/ui/test/e2e/mobile-bottom-nav.spec.ts"],
    },
  },
  {
    id: "theme",
    kind: "contract",
    status: "experimental",
    entrypoint: "@yueli/ui/theme",
    owner: "foundation",
    responsibility:
      "Own a provider-neutral Nuxt UI preset, deterministic local Tabler delivery and opt-in semantic light/dark surface tokens.",
    nonResponsibilities: [
      "application theme names",
      "product color registration",
      "runtime theme persistence",
      "locale catalogs",
    ],
    runtimeDependencies: [
      "@iconify-json/tabler",
      "@nuxt/icon",
      "@nuxt/ui",
      "tailwindcss",
    ],
    evidence: {
      docs: ["README.md"],
      tests: [
        "test/theme.test.ts",
        "test/icon-delivery.test.ts",
        "scripts/test-pack.mjs",
      ],
      consumers: ["js/conformance/ui"],
      accessibility: ["test/theme.test.ts"],
    },
  },
  {
    id: "image-policy",
    kind: "contract",
    status: "experimental",
    entrypoint: "@yueli/ui/image",
    owner: "foundation",
    responsibility:
      "Own bounded raster optimization decisions, resize geometry, cropper configuration, output naming and caller-translatable dimension violations.",
    nonResponsibilities: [
      "asset upload HTTP",
      "media storage",
      "visible cropper copy",
      "image CDN transformations",
    ],
    runtimeDependencies: [],
    evidence: {
      docs: ["README.md"],
      tests: ["test/image.test.ts", "scripts/test-pack.mjs"],
      consumers: ["js/conformance/ui"],
      accessibility: [],
    },
  },
  {
    id: "browser-image-optimization",
    kind: "adapter",
    status: "experimental",
    entrypoint: "@yueli/ui/image/browser",
    owner: "foundation",
    responsibility:
      "Apply the public image policy through a disposable browser decode/canvas/file runtime and report explicit fallback reasons.",
    nonResponsibilities: [
      "upload retries",
      "progress UI",
      "server-side transcoding",
      "cropper rendering",
    ],
    runtimeDependencies: [],
    evidence: {
      docs: ["README.md"],
      tests: ["test/image.test.ts", "scripts/test-pack.mjs"],
      consumers: ["js/conformance/ui"],
      accessibility: [],
    },
  },
  {
    id: "messages",
    kind: "contract",
    status: "experimental",
    entrypoint: "@yueli/ui/messages",
    owner: "foundation",
    responsibility:
      "Carry stable caller-resolved message keys and JSON-safe parameters.",
    nonResponsibilities: [
      "locale catalogs",
      "backend raw messages",
      "Nuxt i18n configuration",
    ],
    runtimeDependencies: [],
    evidence: {
      docs: ["README.md"],
      tests: [],
      consumers: ["js/conformance/ui"],
      accessibility: [],
    },
  },
  {
    id: "collection-workflow",
    kind: "headless-workflow",
    status: "experimental",
    entrypoint: "@yueli/ui/collection",
    owner: "foundation",
    responsibility:
      "Own remote collection load sequencing, route query normalization, query scope and cross-page selection invariants.",
    nonResponsibilities: [
      "business HTTP",
      "Vue rendering",
      "Nuxt UI primitives",
      "domain bulk actions",
    ],
    runtimeDependencies: [],
    evidence: {
      docs: ["README.md"],
      tests: [
        "test/collection-workflow.test.ts",
        "test/query-sync.test.ts",
        "js/conformance/ui/test/e2e/collection.spec.ts",
        "scripts/test-pack.mjs",
      ],
      consumers: [
        "js/conformance/ui",
        "yueli-official/platform/products/resource/web",
        "yueli-official/platform/products/blog/web",
      ],
      accessibility: ["js/conformance/ui/test/e2e/collection.spec.ts"],
    },
  },
  {
    id: "action-feedback",
    kind: "headless-workflow",
    status: "experimental",
    entrypoint: "@yueli/ui/feedback",
    owner: "foundation",
    responsibility:
      "Own latest-wins async action state, terminal reset timing, stable loading visibility, transport-neutral notice normalization and the application confirmation controller.",
    nonResponsibilities: [
      "business mutations",
      "locale catalogs",
      "global toast installation",
    ],
    runtimeDependencies: ["vue"],
    evidence: {
      docs: ["README.md"],
      tests: [
        "test/action-feedback.test.ts",
        "test/feedback-confirm.test.ts",
        "test/minimum-loading.test.ts",
        "test/feedback-notice.test.ts",
      ],
      consumers: ["js/conformance/ui"],
      accessibility: [],
    },
  },
  {
    id: "feedback-surfaces",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/feedback/pattern",
    owner: "foundation",
    responsibility:
      "Own the shared application feedback root, bottom-right toast region and compact inline status surface across light/dark themes and caller-owned semantic palettes.",
    nonResponsibilities: [
      "business mutations",
      "locale catalogs",
      "product palette registration",
      "notification-center persistence",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: [
        "test/feedback-toast-region.test.ts",
        "test/inline-status.test.ts",
        "test/feedback-confirm.test.ts",
        "js/conformance/ui/test/e2e/collection.spec.ts",
        "scripts/test-pack.mjs",
      ],
      consumers: ["js/conformance/ui"],
      accessibility: [
        "test/inline-status.test.ts",
        "js/conformance/ui/test/e2e/collection.spec.ts",
      ],
    },
  },
  {
    id: "action-feedback-button",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/feedback/pattern",
    owner: "foundation",
    responsibility:
      "Render a Nuxt UI action control whose label, icon, tone and live state remain coherent across idle, pending, success and error.",
    nonResponsibilities: [
      "executing mutations",
      "locale catalogs",
      "toast feedback",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/action-feedback-button.test.ts"],
      consumers: ["js/conformance/ui"],
      accessibility: ["test/action-feedback-button.test.ts"],
    },
  },
  {
    id: "back-to-top",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/navigation/back-to-top",
    owner: "foundation",
    responsibility:
      "Own scroll threshold, window or container scrolling, focus return, reduced motion and overlay/dock avoidance for one accessible floating control.",
    nonResponsibilities: [
      "page layout",
      "locale catalogs",
      "overlay state management",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/back-to-top.test.ts"],
      consumers: ["js/conformance/ui"],
      accessibility: ["test/back-to-top.test.ts"],
    },
  },
  {
    id: "reading-table-of-contents",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/navigation/table-of-contents",
    owner: "foundation",
    responsibility:
      "Own heading filtering, hierarchy, fragment navigation, active-section tracking and accessible visual states for in-page reading navigation.",
    nonResponsibilities: [
      "article rendering",
      "page column layout",
      "mobile disclosure placement",
      "product color values",
    ],
    runtimeDependencies: ["@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/reading-table-of-contents.test.ts"],
      consumers: ["docs/web", "blog/web"],
      accessibility: ["test/reading-table-of-contents.test.ts"],
    },
  },
  {
    id: "content-share-actions",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/sharing/content-share",
    owner: "foundation",
    responsibility:
      "Own bounded social targets, system sharing, resilient clipboard copying and original-action copy feedback for public content surfaces.",
    nonResponsibilities: [
      "popover placement",
      "page action layout",
      "content canonical URL policy",
      "locale catalogs",
    ],
    runtimeDependencies: ["@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/content-share-actions.test.ts"],
      consumers: ["blog/web", "docs/web"],
      accessibility: ["test/content-share-actions.test.ts"],
    },
  },
  {
    id: "account-menu-pattern",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/account-menu/pattern",
    owner: "foundation",
    responsibility:
      "Own provider-neutral identity fallback, account and appearance action grouping, inline/sidebar/collapsed trigger anatomy and the async logout command boundary.",
    nonResponsibilities: [
      "identity providers",
      "session state",
      "application navigation",
      "locale catalogs",
      "color-mode state or persistence",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/account-menu.test.ts", "scripts/test-pack.mjs"],
      consumers: ["js/conformance/ui"],
      accessibility: ["test/account-menu.test.ts"],
    },
  },
  {
    id: "admin-template",
    lifecycle: {
      state: "active",
      migration:
        "From 0.8.0-preview.20261009.ai-discovery.5, AdminRowActions defaults to auto. Review constrained action cells and menus. Set presentation='inline' to preserve fixed inline controls; keep accessible labels and existing callbacks. Validate narrow/wide containers, keyboard activation and disabled/loading actions.",
    },
    discovery: {
      aliases: [
        "行操作",
        "手机操作菜单",
        "自适应操作",
        "responsive row actions",
      ],
      capabilities: [
        {
          id: "container-responsive-row-actions",
          supported: true,
          introducedIn: "0.8.0-preview.20261009.ai-discovery.5",
          reason:
            "AdminRowActions.presentation exposes auto, inline and overflow; auto responds to action count and CSS container width.",
        },
      ],
    },
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/admin",
    owner: "foundation",
    responsibility:
      "Own the reusable admin-console shell, sidebar search/navigation, route bar, semantic canvas, page headers, tabbed surfaces, editor inspectors and collection-toolbar anatomy with caller-owned brand content, routes and domain data.",
    nonResponsibilities: [
      "business dashboard regions",
      "application routes",
      "authorization",
      "brand assets",
      "editor business fields or persistence",
      "locale catalogs",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: [
        "test/admin-navigation.test.ts",
        "test/admin-template.test.ts",
        "scripts/test-pack.mjs",
      ],
      consumers: [
        "js/apps/ui-lab",
        "js/conformance/ui",
        "yueli-official/blog/web",
        "yueli-official/docs/web",
        "yueli-official/identity/account",
      ],
      accessibility: ["test/admin-template.test.ts"],
    },
  },
  {
    id: "remote-select",
    lifecycle: {
      state: "active",
      migration:
        "From 0.8.0-preview.20261009.ai-discovery.5, default rows use native Nuxt UI label/description/icon/selected indication. An explicit item slot still replaces the row. Prefer item-leading/item-label/item-description/item-trailing for partial customization; trailingIcon is decorative and does not create a separate action. Verify selection, keyboard and async cancellation.",
    },
    discovery: {
      aliases: [
        "远程选择器",
        "辅助标题",
        "下拉图标",
        "remote searchable select",
      ],
      capabilities: [
        {
          id: "description",
          supported: true,
          contract: "RemoteSelectOption.description",
        },
        {
          id: "leading-icon",
          supported: true,
          contract: "RemoteSelectOption.icon",
        },
        {
          id: "trailing-icon",
          supported: true,
          introducedIn: "0.8.0-preview.20261009.ai-discovery.5",
          contract: "RemoteSelectOption.trailingIcon",
          reason:
            "The item-trailing slot allows custom presentation; the icon is decorative, not a nested action.",
        },
        {
          id: "trailing-action",
          supported: false,
          reason:
            "Icons are decorative; option activation uses the native selection contract.",
        },
      ],
    },
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/remote-select",
    owner: "foundation",
    responsibility:
      "Own debounced, abortable, latest-wins remote option loading, per-instance query caching and retry around Nuxt UI SelectMenu.",
    nonResponsibilities: [
      "business HTTP clients",
      "local option filtering",
      "multi-select",
      "creating domain entities",
      "locale catalogs",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/remote-select.test.ts", "scripts/test-pack.mjs"],
      consumers: ["js/apps/ui-lab", "js/conformance/ui"],
      accessibility: ["test/remote-select.test.ts"],
    },
  },
  {
    id: "dashboard-patterns",
    lifecycle: {
      state: "deprecated",
      reason:
        "Legacy dashboard entrypoint. PageHeader and TabbedSurface share the active admin implementation; DashboardLayout requires explicit composition migration.",
      migration:
        "Import PageHeader and TabbedSurface from @yueli/ui/admin. Replace DashboardLayout with caller-owned regions composed with ManagePage/AdminOverview; there is no drop-in replacement.",
    },
    symbols: [
      {
        name: "DashboardLayout",
        lifecycle: {
          state: "deprecated",
          reason:
            "Legacy dashboard region layout duplicates the newer admin composition model.",
          migration:
            "Compose product-owned dashboard regions using ManagePage and AdminOverview; adapt region slots and messages explicitly.",
        },
      },
      {
        name: "PageHeader",
        canonicalEntrypoint: "@yueli/ui/admin",
        lifecycle: { state: "active" },
      },
      {
        name: "TabbedSurface",
        canonicalEntrypoint: "@yueli/ui/admin",
        lifecycle: { state: "active" },
      },
    ],
    kind: "pattern",
    status: "deprecated",
    entrypoint: "@yueli/ui/dashboard/pattern",
    owner: "foundation",
    responsibility:
      "Own responsive page-heading anatomy and the accessible decision order for caller-provided dashboard regions.",
    nonResponsibilities: [
      "business metrics",
      "business actions",
      "locale catalogs",
      "application navigation",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    replacement: "@yueli/ui/admin",
    evidence: {
      docs: ["README.md"],
      tests: ["test/dashboard-patterns.test.ts", "scripts/test-pack.mjs"],
      consumers: ["js/conformance/ui"],
      accessibility: ["test/dashboard-patterns.test.ts"],
    },
  },
  {
    id: "settings-workflow",
    kind: "headless-workflow",
    status: "experimental",
    entrypoint: "@yueli/ui/settings",
    owner: "foundation",
    responsibility:
      "Own JSON-safe settings baseline cloning, structural dirty comparison, capture, discard and revision semantics.",
    nonResponsibilities: [
      "business persistence",
      "Vue rendering",
      "browser navigation",
      "locale catalogs",
    ],
    runtimeDependencies: [],
    evidence: {
      docs: ["README.md"],
      tests: ["test/settings-workflow.test.ts", "scripts/test-pack.mjs"],
      consumers: ["js/conformance/ui"],
      accessibility: [],
    },
  },
  {
    id: "settings-adapters",
    kind: "adapter",
    status: "experimental",
    entrypoint: "@yueli/ui/settings/vue",
    owner: "foundation",
    responsibility:
      "Bind a caller-owned settings form to Vue reactivity and opt-in browser or Router leave protection.",
    nonResponsibilities: [
      "confirmation copy",
      "persistence",
      "route query semantics",
      "global window policy",
    ],
    runtimeDependencies: ["vue", "vue-router"],
    evidence: {
      docs: ["README.md"],
      tests: [
        "test/settings-vue.test.ts",
        "test/settings-browser.test.ts",
        "test/settings-vue-router.test.ts",
      ],
      consumers: ["js/conformance/ui"],
      accessibility: [],
    },
  },
  {
    id: "settings-patterns",
    discovery: {
      aliases: ["设置导航", "自适应设置", "responsive settings"],
      capabilities: [
        {
          id: "container-responsive-navigation",
          supported: true,
          introducedIn: "0.8.0-preview.20261009.ai-discovery.5",
          reason:
            "SettingsLayout uses container width for section dropdown, wrapping tabs and sidebar; navigationLayout keeps auto/sidebar/tabs choices.",
        },
      ],
    },
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/settings/pattern",
    owner: "foundation",
    responsibility:
      "Own responsive settings navigation, section anatomy and a safe-area-aware save lifecycle dock.",
    nonResponsibilities: [
      "settings fields",
      "business persistence",
      "permissions",
      "locale catalogs",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/settings-patterns.test.ts", "scripts/test-pack.mjs"],
      consumers: ["js/conformance/ui"],
      accessibility: ["test/settings-patterns.test.ts"],
    },
  },
  {
    id: "collection-frame",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/collection/pattern",
    owner: "foundation",
    responsibility:
      "Own the integrated collection frame anatomy, responsive controls disclosure, in-flow bulk region and accessible structural defaults.",
    nonResponsibilities: [
      "filter and sort semantics",
      "domain columns and items",
      "business actions",
      "pagination primitives",
      "translated copy",
      "data-table column sizing and alignment owned by Nuxt UI Table",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: [
        "js/conformance/ui/test/e2e/collection.spec.ts",
        "scripts/test-pack.mjs",
      ],
      consumers: ["js/conformance/ui"],
      accessibility: ["js/conformance/ui/test/e2e/collection.spec.ts"],
    },
  },
  {
    id: "collection-table-toolbar",
    symbols: [
      {
        name: "CollectionToolbar",
        lifecycle: {
          state: "deprecated",
          deprecatedIn: "0.8.0-preview.20261009.ai-discovery.2",
          reason:
            "Legacy wrapping filter layout and openFilters event overlap the canonical collection toolbar but do not satisfy the current toolbar anatomy and caller-owned copy contract.",
          replacement: {
            entrypoint: "@yueli/ui/collection/pattern",
            symbol: "CollectionTableToolbar",
          },
          migration:
            "Migrate to CollectionTableToolbar: adapt required label/filterLabel, filter popover slots, search submission and IME handling; do not rename the import without adapting the event contract.",
        },
      },
    ],
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/collection/pattern",
    owner: "foundation",
    responsibility:
      "Own one responsive default toolbar, stable filter popover and in-place selection mode around a caller-owned Nuxt UI Table.",
    nonResponsibilities: [
      "data-table rendering and column alignment",
      "filter and sort semantics",
      "business bulk actions",
      "business HTTP",
      "locale catalogs",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md", "src/collection/toolbar-standard.md"],
      tests: ["test/collection-table-toolbar.test.ts", "scripts/test-pack.mjs"],
      consumers: ["yueli-official/platform/products/docs/web"],
      accessibility: ["test/collection-table-toolbar.test.ts"],
    },
  },
  {
    id: "collection-pagination",
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/collection/pattern",
    owner: "foundation",
    responsibility:
      "Own container-responsive pagination: auto switches to previous/status/next at 24rem, compact always minimizes controls, full retains numbered pages.",
    nonResponsibilities: [
      "server query",
      "total record calculation",
      "product dependency upgrades",
    ],
    runtimeDependencies: ["vue", "@nuxt/ui"],
    discovery: {
      aliases: [
        "分页",
        "手机分页",
        "自适应分页",
        "responsive pagination",
        "pagination layout",
      ],
      capabilities: [
        {
          id: "container-responsive-pagination",
          supported: true,
          introducedIn: "0.8.0-preview.20261009.ai-discovery.3",
          reason:
            "CollectionPagination.layout and CollectionPanel.paginationLayout expose auto/compact/full; the default uses CSS container queries.",
        },
      ],
    },
    evidence: {
      docs: ["README.md"],
      tests: ["scripts/test-pack.mjs", "test/design-tokens.test.ts"],
      consumers: ["js/conformance/ui"],
      accessibility: ["scripts/test-pack.mjs"],
    },
  },
  {
    id: "collection-panel",
    discovery: {
      aliases: [
        "集合面板",
        "搜索筛选",
        "多级选择器",
        "版块筛选",
        "collection controls",
        "searchable select",
      ],
      capabilities: [
        {
          id: "option-label",
          supported: true,
          contract: "CollectionControlOption.label",
        },
        {
          id: "leading-icon",
          supported: true,
          contract: "CollectionControlOption.icon",
        },
        {
          id: "description",
          supported: true,
          introducedIn: "0.8.0-preview.20261009.ai-discovery.5",
          contract: "CollectionControlOption.description",
        },
        {
          id: "trailing-icon",
          supported: true,
          introducedIn: "0.8.0-preview.20261009.ai-discovery.5",
          contract: "CollectionControlOption.trailingIcon",
          reason:
            "The icon is decorative; activation uses native option selection.",
        },
        {
          id: "trailing-action",
          supported: false,
          reason:
            "The public option contract does not expose an action, event or focus contract.",
        },
      ],
    },
    kind: "pattern",
    status: "experimental",
    entrypoint: "@yueli/ui/collection/pattern",
    owner: "foundation",
    responsibility:
      "Own complete responsive search, configured controls, in-flow selection and bulk actions, loading/error/empty states, row/grid containers and pagination for remote collections.",
    nonResponsibilities: [
      "business HTTP",
      "domain item fields",
      "strict data-table column alignment",
      "business bulk actions",
      "locale catalogs",
    ],
    runtimeDependencies: ["nuxt", "@nuxt/ui", "tailwindcss", "vue"],
    evidence: {
      docs: ["README.md"],
      tests: [
        "test/collection-panel.test.ts",
        "js/conformance/ui/test/e2e/collection.spec.ts",
        "scripts/test-pack.mjs",
      ],
      consumers: ["js/conformance/ui", "js/apps/ui-lab"],
      accessibility: ["js/conformance/ui/test/e2e/collection.spec.ts"],
    },
  },
  {
    id: "collection-vue-adapter",
    kind: "adapter",
    status: "experimental",
    entrypoint: "@yueli/ui/collection/vue",
    owner: "foundation",
    responsibility:
      "Bind a client-mounted collection Workflow to Vue setup lifecycle, reactive snapshots and data-query invalidation.",
    nonResponsibilities: [
      "SSR data fetching",
      "business HTTP",
      "search input policy",
      "Vue rendering",
      "domain feedback",
    ],
    runtimeDependencies: ["vue"],
    evidence: {
      docs: ["README.md"],
      tests: ["test/vue-collection-workflow.test.ts", "scripts/test-pack.mjs"],
      consumers: [
        "js/conformance/ui",
        "yueli-official/platform/products/resource/web",
        "yueli-official/platform/products/blog/web",
      ],
      accessibility: [],
    },
  },
  {
    id: "collection-vue-router-adapter",
    kind: "adapter",
    status: "experimental",
    entrypoint: "@yueli/ui/collection/vue-router",
    owner: "foundation",
    responsibility:
      "Synchronize an owned collection query subset with Vue Router while preserving unrelated query keys.",
    nonResponsibilities: [
      "query semantics",
      "business HTTP",
      "route registration",
    ],
    runtimeDependencies: ["vue", "vue-router"],
    evidence: {
      docs: ["README.md"],
      tests: [
        "test/vue-router-query-sync.test.ts",
        "js/conformance/ui/test/e2e/collection.spec.ts",
        "scripts/test-pack.mjs",
      ],
      consumers: [
        "js/conformance/ui",
        "yueli-official/platform/products/resource/web",
        "yueli-official/platform/products/blog/web",
      ],
      accessibility: [],
    },
  },
] as const satisfies readonly PublicUiManifestEntry[];
